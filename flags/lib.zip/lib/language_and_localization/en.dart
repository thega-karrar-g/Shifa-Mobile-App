import 'app_strings.dart';

Map<String, String> en = {


  AppStrings.appTitle: 'GlobCare',
  AppStrings.welcome: 'Welcome\nBack',
  AppStrings.country: 'Country',
  AppStrings.logIn: "Login",
  AppStrings.signOut: "Sign out",
  AppStrings.signUp: "Sign up",
  AppStrings.save: "Save",
  AppStrings.doNotHaveAccount: "Don't have an account?",
  AppStrings.haveAccount: "Have an account?",
  AppStrings.accountCreated: AppStrings.accountCreated,
  AppStrings.successfully: AppStrings.successfully,
  AppStrings.almostDone: AppStrings.almostDone,
  AppStrings.fillRequiredInformation: AppStrings.fillRequiredInformation,

  AppStrings.dob: AppStrings.dob,
  AppStrings.age: 'Age',
  AppStrings.gender: 'Gender',
  AppStrings.email: 'Email',

  AppStrings.fullName: 'Full Name',
  AppStrings.firstName: 'First Name',
  AppStrings.midName: 'Middle Name',
  AppStrings.lastName: 'Last Name',
  AppStrings.idNo: 'Id Number',
  AppStrings.male: 'Male',
  AppStrings.female: 'Female',
  AppStrings.location: AppStrings.location,
  AppStrings.phoneNum: AppStrings.phoneNum,
  AppStrings.passwordLengthHint: AppStrings.passwordLengthHint,
  AppStrings.phoneNumHint: "777 777 777 ",
  AppStrings.mustNotEmpty: " must not be empty",


  //  appointment

  AppStrings.scheduled: 'Under Review',
  AppStrings.scheduleType: AppStrings.scheduleType,
  AppStrings.time: AppStrings.time,
  AppStrings.morning: 'Morning',
  AppStrings.afterNoon: 'After Noon',
  AppStrings.evening: 'Evening',
  AppStrings.timePM: AppStrings.timePM,
  AppStrings.timeAM: AppStrings.timeAM,



  AppStrings.name: "Name",
  AppStrings.nameHint: "Enter your name",
  AppStrings.currentEmail: "Your Email",
  AppStrings.currentEmailHint: "Enter Your Email",
  AppStrings.newEmail: "New Email",
  AppStrings.newEmailHint: "Enter your new email",
  AppStrings.fillAllField: "*Please fill in all required fields",
  AppStrings.invalidNum: "*Invalid number",
  AppStrings.didNotReceiveCode: "Didn't receive the code?",
  AppStrings.resend: "Resend",
  AppStrings.retry: "Retry",
  AppStrings.clear: "Clear",
  AppStrings.password: "Password",
  AppStrings.forgetPassword: "Forgot password ?",
  AppStrings.resetPassword: "Reset password",
  AppStrings.resetPasswordLinkSuccessfullySend:
      "Password reset email has been sent",
  AppStrings.sendResetEmail: "Send reset password email",
  AppStrings.newPassword: "New password",
  AppStrings.newPasswordHint: "Enter New password",
  AppStrings.passwordHint: "Enter your password",
  AppStrings.passwordConfirm: "Password confirmation",
  AppStrings.passwordConfirmHint: "Confirm your password",
  AppStrings.newPasswordConfirm: "New Password confirmation",
  AppStrings.newPasswordConfirmHint: "Confirm your new password",
  AppStrings.currentPassword: "Current password",
  AppStrings.currentPasswordHint: "Enter current password",
  AppStrings.requiredField: "This field can't be empty",
  AppStrings.submit: "Submit info",
  AppStrings.continueText: "Continue",
  AppStrings.about: "About us",
  AppStrings.setting: "Settings",
  AppStrings.home: "Home",

  AppStrings.selectTypeHint: "Sign in as",
  AppStrings.searchHint: "Search new club to join",
  AppStrings.seeAll: "See All",
  AppStrings.doubleClickToExitApp: "Double click to exit app",
  //-------------
  AppStrings.changeUserName: "Change user name",
  AppStrings.changePhoneNum: "Change phone number",
  AppStrings.changeLanguage: "Change language",
  AppStrings.changeTheme: "Change Theme",
  AppStrings.delete: "Delete",
  AppStrings.edit: "Edit",
  AppStrings.checkInternet: "Please check your internet connection",
  AppStrings.unexpectedError: "Oops unexpected error occurred.",
  AppStrings.error: "Error",
  AppStrings.close: "Close",
  AppStrings.skip: "Skip",
  AppStrings.next: 'Next',

  AppStrings.introCall: AppStrings.introCall,
  AppStrings.introVisit: AppStrings.introVisit,
  AppStrings.introCheck: AppStrings.introCheck,
  AppStrings.introBook: AppStrings.introBook,
  AppStrings.introReview: AppStrings.introReview,
  AppStrings.introBody1: AppStrings.introBody1,
  AppStrings.introBody2: AppStrings.introBody3,
  AppStrings.introBody3: AppStrings.introBody3,
  AppStrings.introBody4: AppStrings.introBody4,
  AppStrings.introBody5: AppStrings.introBody5,


  AppStrings.showMore: "Show more",
  AppStrings.showLess: "Show less",
  AppStrings.yes: 'Yes',
  AppStrings.no: 'No',
  AppStrings.noDataFound: AppStrings.noDataFound,
  AppStrings.back: 'Back',
  AppStrings.add: 'Add',
  AppStrings.addMore: 'Add more',
  AppStrings.ok: 'OK',
  AppStrings.from: AppStrings.from,
  AppStrings.to: AppStrings.to,
  AppStrings.deletedSuccessfully: 'Successfully deleted',
  AppStrings.failedToDelete: 'Failed to delete',
  AppStrings.cancel: 'Cancel',
  AppStrings.search: 'Search',
  AppStrings.noMoreItem: 'No more items',
  AppStrings.noItemsYet: 'No items here yet',
  AppStrings.emergency: 'Emergency',
  AppStrings.emergencyContacts: AppStrings.emergencyContacts,
  AppStrings.myEmergencyContacts: AppStrings.myEmergencyContacts,
  AppStrings.emergencySubHeading: 'Call ambulance nearby you - 24*7',



  ///  home screen


  AppStrings.appointments:AppStrings.appointments,
  AppStrings.myProfile:AppStrings.myProfile,
  AppStrings.medicalFile:AppStrings.medicalFile,
  AppStrings.bookNow:AppStrings.bookNow,




  AppStrings.doctors:'Doctors',
  AppStrings.prescriptionList:'Prescription List',
  AppStrings.appointmentList:'Appointment List',
  AppStrings.labTestDivided:'Lab Tests',
  AppStrings.radiology:AppStrings.radiology,



  /// drawer

  AppStrings.profile: 'Profile',
  AppStrings.editProfile: AppStrings.editProfile,
  AppStrings.language: 'Language',
  AppStrings.themeMode: 'Theme',
  AppStrings.help: 'Help & FAQ',
  AppStrings.privacyPolicy: 'Privacy Policy',
  AppStrings.logout: 'Logout',


  AppStrings.applicationPreferences: 'Application Preferences',
  AppStrings.helpAndSupport: 'Help & Support',
  AppStrings.pages: 'Pages',

  AppStrings.langAr: 'العربية',
  AppStrings.langEn: 'English',

  AppStrings.completed: AppStrings.completed,
  AppStrings.upcoming: AppStrings.upcoming,

  AppStrings.emergencyMessage: 'It\'s not required to fill the form below. You may call the ambulance right away.',



  //  family members
  AppStrings.familyMember:AppStrings.familyMember,
  AppStrings.myFamilyMember:AppStrings.myFamilyMember,
  AppStrings.relation:AppStrings.relation,
  AppStrings.address:AppStrings.address,
  AppStrings.dead:AppStrings.dead,
  AppStrings.alive:AppStrings.alive,



  /// stepcounter
  AppStrings.stepController:AppStrings.stepController,
  AppStrings.pedestrian:AppStrings.pedestrian,
  AppStrings.stepTaken:AppStrings.stepTaken,
  AppStrings.walking:AppStrings.walking,
  AppStrings.stopped:AppStrings.stopped,
  AppStrings.today:AppStrings.today,
  AppStrings.calories:AppStrings.calories,
  AppStrings.distance:AppStrings.distance,
  AppStrings.speedAvg:AppStrings.speedAvg,





  AppStrings.pleaseWait:AppStrings.pleaseWait,
  AppStrings.martialStatus:AppStrings.martialStatus,




  /// doctor
  AppStrings.topDoctors: AppStrings.topDoctors,
  AppStrings.doctorDetails: AppStrings.doctorDetails,
  AppStrings.map: AppStrings.map,
  AppStrings.aboutDr: AppStrings.aboutDr,
  AppStrings.rating:AppStrings.rating,
  AppStrings.experience: AppStrings.experience,
  AppStrings.bookAppointment: AppStrings.bookAppointment,
  AppStrings.confirmAppointment: AppStrings.confirmAppointment,



  /// labtests

  AppStrings.labTestDetails: AppStrings.labTestDetails,
  AppStrings.checkItOut: AppStrings.checkItOut,
  AppStrings.recentTests: AppStrings.recentTests,
  AppStrings.test: AppStrings.test,
  AppStrings.result: AppStrings.result,
  AppStrings.normalRange: AppStrings.normalRange,
  AppStrings.unit: AppStrings.unit,




  ////
  AppStrings.bookingServices: AppStrings.bookingServices,
  AppStrings.covidPCR: AppStrings.covidPCR,
  AppStrings.telemedicineDoctors: AppStrings.telemedicineDoctors,
  AppStrings.labTechnician: AppStrings.labTechnician,
  AppStrings.nurse: AppStrings.nurse,
  AppStrings.physiotherapist: AppStrings.physiotherapist,
  AppStrings.homeVisitDoctor: AppStrings.homeVisitDoctor,
  AppStrings.homeRadiology: AppStrings.homeRadiology,
  AppStrings.vaccination: AppStrings.vaccination,
  AppStrings.vitaminIVDrips: AppStrings.vitaminIVDrips,



  AppStrings.nurseService: AppStrings.nurseService,
  AppStrings.physiotherapistServices: AppStrings.physiotherapistServices,
  AppStrings.continueTo: AppStrings.continueTo,
  AppStrings.payment: AppStrings.payment,
  AppStrings.appointmentCreated: AppStrings.appointmentCreated,
  AppStrings.insurance: AppStrings.insurance,
  AppStrings.confirm: AppStrings.confirm,
  AppStrings.send: AppStrings.send,
  AppStrings.cash: AppStrings.cash,
  AppStrings.selectMsg: AppStrings.selectMsg,
  AppStrings.patientData: AppStrings.patientData,
  AppStrings.selectLocation: AppStrings.selectLocation,
  AppStrings.getBestHealthCareMsg: AppStrings.getBestHealthCareMsg,
  AppStrings.specialties: AppStrings.specialties,
  AppStrings.taskDetails: AppStrings.taskDetails,
  AppStrings.currency: AppStrings.currency,




  AppStrings.editPhoneNum: AppStrings.editPhoneNum,
  AppStrings.editPassword: AppStrings.editPassword,
  AppStrings.getStarted: AppStrings.getStarted,
  AppStrings.openMapMsg: AppStrings.openMapMsg,
  AppStrings.aboutMsg: AppStrings.aboutMsg,
  AppStrings.fillAllRequiredFields: AppStrings.fillAllRequiredFields,







};
