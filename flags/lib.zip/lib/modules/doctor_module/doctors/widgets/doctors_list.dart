import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/shared_in_ui/shared/no_data.dart';

import 'doctor_item.dart';

class DoctorsList extends StatelessWidget {
   DoctorsList({this.doctors,this.isTopItem=false, Key? key}) : super(key: key);

  final List<Doctor>? doctors;

 final bool  isTopItem;

  @override
  Widget build(BuildContext context) {
    return (doctors!.isEmpty&&!isTopItem)? NoDataFound() :ListView.builder(
      itemCount: doctors?.length,
      scrollDirection: isTopItem?Axis.horizontal:Axis.vertical,
      shrinkWrap: true,
      physics: isTopItem?AlwaysScrollableScrollPhysics():NeverScrollableScrollPhysics(),
      itemBuilder: (bc, index) => Container(
     //   height: 90,
        width: isTopItem? Get.width*.6:Get.width*.8,
        padding: EdgeInsets.symmetric(vertical: 10),
        child: DoctorItem(

          doctor: doctors?[index],
          isTopItem: isTopItem,
        ),
      ),
    );
  }
}
