import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/booking_home_modules/book_doctor_period/week_item_period.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/modules/doctor_module/doctor_schedule/widgets/doctor_details.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_column.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_list.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/no_data.dart';
import 'package:sehati_app/shared_in_ui/shared/tab_item.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import '../../../shared_in_ui/shared/loading.dart';
import 'doctor_schedule_logic.dart';

class DoctorSchedulePage extends StatelessWidget {
  final DoctorScheduleLogic logic = Get.put(DoctorScheduleLogic());

  GlobalKey globalKey=GlobalKey();

  DoctorSchedulePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final ar=Get.locale.toString()=='ar';
    return Ui.myScaffold(child: SingleChildScrollView(
      child: Column(

        children: [

          myAppBar2(title: AppStrings.doctorDetails),
          UiHelper.verticalSpaceMedium,

          Row(children: [
            Expanded(child: Text(AppStrings.doctorInfo.tr,style: AppStyles.primaryStyle(size: 16,bold: true),)),

          ],),
          UiHelper.verticalSpaceSmall,

          Container(
            height: 145,
            decoration: BoxDecoration(
            ),


            child: Stack(


              children: [
                // Positioned.fill(
                //     bottom: 20,
                //     child: Align(
                //         alignment:ar?Alignment.bottomRight: Alignment.bottomLeft,
                //         child: Container(
                //           margin: EdgeInsets.symmetric(horizontal: 20),
                //           width: Get.width*.4,
                //           height: 5,
                //           decoration: BoxDecoration(
                //               color: AppColors.primaryColor,
                //               borderRadius: BorderRadius.circular(15)
                //           ),
                //         )
                //     )),

                Row(
                  children: [


                    Column(children: [

                      Expanded(child:

                      Container(
                        child:    Ui.circluarImgRadiusBase64(url:logic. doctor.image,margin: 0,errorImg: AppImages.doctor,rTL: ar?0:20,rTR: ar?0:20,size: 0,h: 130,w: 100),

                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(ar?20: 0),
                            topLeft: Radius.circular(ar?0:20),
                            bottomRight: Radius.circular(20),
                            bottomLeft: Radius.circular(20),
                          ),
                          // boxShadow: kElevationToShadow[1],
                        ),

                      ),



                      ),

                      SizedBox(height: 20,)



                    ],),
                    Expanded(
                      child: Column(children: [

                        Container(
                          margin: EdgeInsets.zero,
                          padding: EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                              color: AppColors.primaryColorOpacity,
                              borderRadius: BorderRadius.only(
                                topRight: Radius.circular(ar?0:15),
                                bottomRight: Radius.circular(ar?0:15),


                                topLeft: Radius.circular(ar?15:0),
                                bottomLeft: Radius.circular(ar?15:0),

                              )
                          ),

                          child: Row(children: [

                            Expanded(child: Container(
                              height: 100,
                              padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                              child: Column(

                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [

                                  Row(
                                    children: [
                                      Expanded(child: Text(ar?logic.doctor.nameAr!:logic.doctor.name!,maxLines: 2,overflow: TextOverflow.ellipsis,style: AppStyles.primaryStyle(bold: true,size: 12),)),
                                    ],
                                  ),
                                  UiHelper.verticalSpace(5),
                                  Row(
                                    children: [
                                      Expanded(child: Text(  ' ${ar? logic.doctor.jobTitleAr! :  logic.doctor.jobTitle!} ',maxLines: 3,overflow: TextOverflow.ellipsis,style: AppStyles.subTitleStyle(bold: true,size: 11),)),
                                    ],
                                  ),
                                  UiHelper.verticalSpace(5),

                                  Row(
                                    children: [
                                      Expanded(child: Text(  ar?logic. doctor.specialityAr!:  logic.doctor.speciality!,maxLines: 2,overflow: TextOverflow.ellipsis,style: AppStyles.subTitleStyle(bold: true,size: 10),)),
                                    ],
                                  ),
                                  UiHelper.verticalSpace(5),
                                  Row(
                                    children: [
                                      Expanded(child: Text('${ar?logic.doctor.employerAr :  logic.doctor.employer!}   '  ,maxLines: 1,overflow: TextOverflow.ellipsis,style: AppStyles.primaryStyle(bold: false,size: 10),)),
                                    ],
                                  ),

                                ],),
                            )),
                            UiHelper.horizontalSpace(5),

                            Container(
                              padding: EdgeInsets.symmetric(vertical: 10,horizontal: 10),
                              decoration: BoxDecoration(color: AppColors.primaryColorGreen,

                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(ar?0:10),
                                    bottomLeft: Radius.circular(ar?0:10),


                                    bottomRight: Radius.circular(ar?10:0),
                                    topRight: Radius.circular(ar?10:0),

                                  )
                              ),
                              child: Text( '${PatientDataLogic.price}'+AppStrings.currency.tr,style: AppStyles.whiteStyle(bold: true),),

                            )


                          ],),
                        ),
                        UiHelper.verticalSpace(20)

                      ],),
                    ),
                  ],
                ),
              ],
            ),

          ),





          GetBuilder<DoctorScheduleLogic>(builder: (logic){

            return
          Column(
            children: [
              Row(
                children: [

                  TabItem(name: AppStrings.doctorSchedule,selected: logic.infoIndex==0, onTab: (){
                    logic.changeInfoIndex(0);
                  }),

                  UiHelper.horizontalSpaceMedium,

                  TabItem(name: AppStrings.moreDetails,selected: logic.infoIndex==1, onTab: (){
                    logic.changeInfoIndex(1);
                  }),

                  Spacer()
                ],
              ),


              UiHelper.verticalSpaceMedium,

              Visibility(

                visible:logic.infoIndex==0 ,
                child:  logic.busy?MyLoadingWidget():


                (logic.scheduleList.isNotEmpty)?

                DynamicColumn(children: [

                  Row(children: [
                    Text(DateFormat('MMMM',Get.locale.toString()).format(logic.selectedDay),style: AppStyles.primaryStyle(bold: true,size: 18),),

                    UiHelper.horizontalSpaceSmall,
                    Text(DateFormat('yyyy').format(logic.selectedDay),style: AppStyles.subTitleStyle(bold: true,size: 15),),
                  ],),

                  SizedBox(
                    height: 100,
                    child: ListView.builder(
                      itemCount: logic.scheduleList.length,
                      scrollDirection: Axis.horizontal,

                      itemBuilder: (bc, index) =>
                          SizedBox(
                            height: 200,
                            child: WeekItemPeriod(weekName: DateFormat('E',Get.locale.toString()).format(logic.scheduleList[index].date,),

                              weekNo: '${logic.scheduleList[index].date.day}',

                              onTab: () {
                                logic.changeDay(index);
                              },
                              selected: logic.scheduleList[index].date ==
                                  logic.selectedDay,
                            ),
                          ),

                    ),
                  ),


                  SizedBox(
                    height: 30,
                    child:   DynamicListView(

                       key: globalKey,
                        axis: Axis.horizontal,data:
                    logic.scheduleList[logic.currentIndex].times!, itemBuilder: (item){
                      var time=item as String;
                      return
                        GestureDetector(
                          onTap: (){

                            logic.changeSlot(time);
                          },
                          child: Container(
                            margin: EdgeInsets.symmetric(horizontal: 10),
                            padding: EdgeInsets.symmetric(horizontal: 15,vertical: 5),

                            decoration: BoxDecoration(

                                borderRadius: BorderRadius.circular(10),
                                color: logic.checkSlot(time,logic.scheduleList[logic.currentIndex].date)?AppColors.primaryColor:AppColors.white,

                                border: Border.all(color: AppColors.primaryColor)

                            ),

                            child: Text(time,style:
                            logic.checkSlot(time,logic.scheduleList[logic.currentIndex].date)?  AppStyles.whiteStyle(bold: true) :     AppStyles.subTitleStyle(bold: true),

                            ),

                          ),
                        );}

                    ),
                  ),


                  UiHelper.verticalSpaceSmall,

                  Ui.primaryButton(title: AppStrings.bookDoctor,marginH: 0,onTab: (){

                    logic.navToPatientData();
                  },color: AppColors.primaryColor)

                ],)
                    :

                Center(child: NoDataFound(),),),
              Visibility(

                  visible:logic.infoIndex==1 ,
                  child:




                  DoctorDetails(doctor: logic.doctor,)

              ),
            ],
          )
            ;})

          ,




        ],

      ),
    ));
  }
}
