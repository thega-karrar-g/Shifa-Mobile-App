import 'package:flutter/material.dart';
import '../../../core/language_and_localization/app_strings.dart';
import '../../../data/models/home_service.dart';
import '../../../data/models/m_appointment.dart';
import '../../../global_widgets/shared/dynamic_list.dart';
import '../../../global_widgets/shared/no_data.dart';
import '../../../utils/constants/app_anim.dart';
import 'appointment_item2.dart';

class AppointmentList extends StatelessWidget {
  const AppointmentList({this.appointments, this.homeService, Key? key})
      : super(key: key);

  final List<Appointment>? appointments;

  final HomeService? homeService;

  @override
  Widget build(BuildContext context) {
    return appointments!.isNotEmpty
        ? DynamicListView(
            data: appointments!,
            itemBuilder: (
              item,
            ) {
              return AppointmentItem2(
                appointment: item as Appointment,
                homeService: homeService,
              );
            },
          )
        : NoDataFound(
            animation: AppAnim.noAppointmentFound,
            msg: AppStrings.noAvailableBookings,
          );

    // appointments!.isNotEmpty ? ListView.builder(
    //   itemCount: appointments?.length,
    //   itemBuilder: (bc,index)=>AppointmentItem2(appointment: appointments?[index],)):NoDataFound();
    //
    //
  }
}
