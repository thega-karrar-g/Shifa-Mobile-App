
import 'package:flutter/material.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_fonts.dart';

class AppStyles{


  AppStyles._();


  static primaryStyle({bool bold=false, double size=13,double opacity=1.0,double height=0.0}){return TextStyle(fontSize: size,color: AppColors.primaryColor.withOpacity(opacity),fontWeight: bold?FontWeight.bold:FontWeight.normal,fontFamily: AppFonts.mainFontFamily,height: height>0 ?height:null); }
  static primaryStyleGreen({bool bold=false, double size=13,double height=0.0}){return TextStyle(fontSize: size,color: AppColors.primaryColorGreen,fontWeight: bold?FontWeight.bold:FontWeight.normal,height:  height>0 ?height:null); }
  static whiteStyle({bool bold=false,double size=13,double opacity =1.0,double height=0.0}){return TextStyle(fontSize: size,color: AppColors.white.withOpacity(opacity),fontWeight: bold?FontWeight.bold:FontWeight.normal,height: height>0 ?height:null); }
  static subTitleStyle({bool bold=false,double size=13,double height=0.0}){return TextStyle(fontSize: size,color: AppColors.subTitleColor,fontFamily: AppFonts.mainFontFamily,fontWeight: bold?FontWeight.bold:FontWeight.normal,height: height>0 ?height:null); }
  static weekStyle({bool bold=false,double size=13}){return TextStyle(fontSize: size,color: AppColors.subTitleColor,fontWeight: bold?FontWeight.bold:FontWeight.normal); }


}