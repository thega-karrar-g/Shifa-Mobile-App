
class AppAnim{



  static const loader='assets/anim/loader.json';
  static const loaderGetData='assets/anim/loader_get_data.json';
  static const lottieProgress='assets/anim/heart_progress.json';
  static const lottieLoading='assets/anim/loading.json';
  static const lottieLoading2='assets/anim/loading3.json';
  static const lottieLoading3='assets/anim/loading3.json';
  static const search='assets/anim/search.json';
  static const success='assets/anim/success.json';
  static const success2='assets/anim/success2.json';
  static const paymentSuccess='assets/anim/payment_success.json';
  static const paymentFailed='assets/anim/payment_failed.json';
  static const paymentLoading='assets/anim/payment_loading.json';


}