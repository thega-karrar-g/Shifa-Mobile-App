import 'package:get/get.dart';
import 'package:logger/logger.dart';

import '../../services/session_service.dart';
import '../models/user_model.dart';
import 'api.dart';

class BaseApi {
  Api api = Api();
  var authService = Get.find<SessionService>();

  AppUser? get currentUser {
    return Get.find<SessionService>().currentUser;
  }

  final logger = Logger();
}
