import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jitsi_meet/jitsi_meet.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'meeting_logic.dart';

class MeetingPage extends StatelessWidget {
  final MeetingLogic logic = Get.put(MeetingLogic());

  MeetingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return
      Ui.myScaffold(child: SingleChildScrollView(
        child: Column(
          children: [

            myAppBar2(title: AppStrings.meetTelemedicine),

            Container(
              child: kIsWeb
                  ? Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: Get.width * 0.30,
                    child: meetConfig(),
                  ),
                  SizedBox(
                      width: Get.width * 0.60,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Card(
                            color: Colors.white54,
                            child: SizedBox(
                              width: Get.width * 0.60 * 0.70,
                              height: Get.width * 0.60 * 0.70,
                              child: JitsiMeetConferencing(
                                extraJS: const [
                                  // extraJs setup example
                                  '<script>function echo(){console.log("echo!!!")};</script>',
                                  '<script src="https://code.jquery.com/jquery-3.5.1.slim.js" integrity="sha256-DrT5NfxfbHvMHux31Lkhxg42LY6of8TaYyK50jnxRnM=" crossorigin="anonymous"></script>'
                                ],
                              ),
                            )),
                      ))
                ],
              )
                  : meetConfig(),
            ),
          ],
        ),
      ));
  }


  Widget meetConfig() {
    return SingleChildScrollView(
      child: GetBuilder<MeetingLogic>(builder: (logic) {
        return Theme(
          data: ThemeData(unselectedWidgetColor: AppColors.subTitleColor),

          child: Column(
            children: <Widget>[
              SizedBox(
                height: 16.0,
              ),
              // TextField(
              //   controller: serverText,
              //   decoration: InputDecoration(
              //       border: OutlineInputBorder(),
              //       labelText: "Server URL",
              //       hintText: "Hint: Leave empty for meet.jitsi.si"),
              // ),
              // SizedBox(
              //   height: 14.0,
              // ),
              // TextField(
              //   controller: roomText,
              //   decoration: InputDecoration(
              //     border: OutlineInputBorder(),
              //     labelText: "Room",
              //   ),
              // ),
              // SizedBox(
              //   height: 14.0,
              // ),
              // TextField(
              //   controller: subjectText,
              //   decoration: InputDecoration(
              //     border: OutlineInputBorder(),
              //     labelText: "Subject",
              //   ),
              // ),
              // SizedBox(
              //   height: 14.0,
              // ),
              // TextField(
              //   controller:logic. nameText,
              //   decoration: InputDecoration(
              //     border: OutlineInputBorder(),
              //     labelText: "Display Name",
              //   ),
              // ),
              // SizedBox(
              //   height: 14.0,
              // ),
              // TextField(
              //   controller: emailText,
              //   decoration: InputDecoration(
              //     border: OutlineInputBorder(),
              //     labelText: "Email",
              //   ),
              // ),
              SizedBox(
                height: 14.0,
              ),
              SizedBox(
                height: 14.0,
              ),
              CheckboxListTile(
                title: Text(
                  AppStrings.audioOnly.tr, style: AppStyles.primaryStyle(),),
                value: logic.isAudioOnly,
                onChanged: logic.onAudioOnlyChanged,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50))
              ),
              SizedBox(
                height: 14.0,
              ),
              CheckboxListTile(
                title: Text(
                  AppStrings.muteAudio.tr, style: AppStyles.primaryStyle(),),
                value: logic.isAudioMuted,
                onChanged: logic.onAudioMutedChanged,
              ),
              SizedBox(
                height: 14.0,
              ),
              CheckboxListTile(
                title: Text(
                  AppStrings.muteVideo.tr, style: AppStyles.primaryStyle(),),
                value: logic.isVideoMuted,
                onChanged: logic.onVideoMutedChanged,
              ),
              Divider(
                height: 48.0,
                thickness: 2.0,
              ),
              Ui.primaryButton(
                title: AppStrings.startMeeting,
                onTab: () {
                  logic.joinMeeting();
                },

              ),
              SizedBox(
                height: 48.0,
              ),
            ],
          ),
        );
      }),
    );
  }

}
