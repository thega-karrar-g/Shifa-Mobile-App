import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:persian_datepicker/persian_datepicker.dart';
// import 'package:persian_datepicker/persian_datepicker.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:intl/intl.dart' as intl;
import 'package:sehati_app/shared_in_ui/form_widgets/reactive_text_form.dart';
import 'package:sehati_app/utils/constants/reg_exp.dart';
import '../../../language_and_localization/app_strings.dart';
import '../../../shared_in_ui/shared/dynamic_column.dart';
import '../../../shared_in_ui/shared/ui_helpers.dart';
import '../../../shared_in_ui/ui.dart';
import '../../../utils/helpers/theme_helper/app_colors.dart';
import '../../../utils/helpers/theme_helper/app_fonts.dart';
import '../../../utils/helpers/theme_helper/app_styles.dart';
import '../auth_controller.dart';

class ReactiveRegisterForm extends StatelessWidget {
  ReactiveRegisterForm({Key? key}) : super(key: key);


 static TextEditingController textEditingController=TextEditingController();
  String idNumberKey = 'ssn';
  String ageKey = 'age';
  String passwordKey = 'password';
  String confirmPasswordKey = 'confirm_password';
  String nameKey = 'name';
  String mobileKey = 'mobile';
  String genderKey = 'gender';
  String dobKey = 'dob';

  final double paddingHeight = 15.0;

  var requiredFields = ' '
      '${AppStrings.phoneNum.tr} *\n'
      '${AppStrings.password.tr} *\n'
      ''
      '';


  FormGroup buildForm() => fb.group(<String, Object>{
        nameKey: FormControl<String>(
          validators: [
            Validators.required,
          ],
        ),
        mobileKey: FormControl<String>(
          validators: [
            Validators.required,
          ],
        ),
        ageKey: FormControl<String>(
          validators: [
            Validators.required,
          ],
        ),
        passwordKey: ['', Validators.required, Validators.minLength(6)],
        confirmPasswordKey: ['', Validators.required, Validators.minLength(6)],
        idNumberKey: [
          '',
          Validators.required,

        ],
      });

  @override
  Widget build(BuildContext context) {

    return GetBuilder<AuthController>(builder: (logic) {

      var yes=logic.nationality.answer !=null&&logic.nationality.answer==true;
      var noChecked=logic.nationality.answer !=null&&logic.nationality.answer==false;
      var d=logic.dob!;
      var max=DateTime.now();
      var duration =Duration(milliseconds: 200);
logic.      persianDatePicker = PersianDatePicker(
        controller:logic. dobTextEditingController,
        showGregorianDays: true,
        locale: Get.locale.toString(),

        currentDayBackgroundColor: AppColors.primaryColorOpacity,
        selectedDayBackgroundColor: AppColors.primaryColor,
        selectedDayTextStyle: AppStyles.whiteStyle(bold: true),
        headerTodayTextStyle: AppStyles.whiteStyle(bold: true),
        headerTodayIcon: Icon(FontAwesomeIcons.calendarDay,color: AppColors.white,),
        weekCaptionsBackgroundColor: AppColors.primaryColor,
        headerTodayBackgroundColor: AppColors.primaryColorGreen,
        monthSelectionBackgroundColor: AppColors.primaryColorOpacity,
        monthSelectionHighlightBackgroundColor: AppColors.primaryColorGreen,
        monthSelectionTextStyle: AppStyles.primaryStyle(),
        monthSelectionHighlightTextStyle: AppStyles.whiteStyle(),
        weekCaptionsTextStyle: AppStyles.whiteStyle(size:Get.locale.toString()=='ar'?10:13),

        yearSelectionBackgroundColor: AppColors.primaryColorOpacity,
        yearSelectionHighlightBackgroundColor: AppColors.primaryColorGreen,
        yearSelectionTextStyle: AppStyles.primaryStyle(),
        yearSelectionHighlightTextStyle: AppStyles.whiteStyle(),
        changePageDuration: duration,
        monthSelectionAnimationDuration: duration,
        yearSelectionAnimationDuration: duration,

fontFamily: AppFonts.mainFontFamily,
        maxDatetime: '${max.year}/${max.month}/${max.day}',
        // finishDatetime: '${d.year}/${d.month}/${d.day}',
        // gregorianDatetime: '${d.year}-${d.month}-${d.day}',
        // minDatetime: '${min.year}/${min.month}/${min.day}',
rangeDatePicker: false,
datetime: '${d.year}/${d.month}/${d.day}',
        outputFormat: 'YYYY/M/D',
// maxSpan: Duration(days: 1),
// minSpan: Duration(days: 0),
        farsiDigits: false,
        headerTodayCaption: AppStrings.today.tr,
        weekCaptions: [AppStrings.sat.tr,AppStrings.sun.tr,AppStrings.mon.tr,
          AppStrings.tue.tr,AppStrings.wed.tr,AppStrings.thu.tr,AppStrings.fri.tr],
// datetime: DateFormat('yyyy/MM/dd').format(DateTime.now()),
// finishDatetime: DateFormat('yyyy/MM/dd').format(DateTime.now().add(Duration(days: 0))),
//         gregorianFinishDatetime: DateFormat('yyyy-MM-dd').format(DateTime.now().add(Duration(days: 0))),
// gregorianDatetime: DateFormat('yyyy-MM-dd').format(DateTime.now().add(Duration(days: 0))),
        onChange: (String oldText, String newText) {

          print(newText);
          try {
            var list=newText.split('/');
            var dt=DateTime(int.parse(list[0]),int.parse(list[1]),int.parse(list[2]));
            //var dd = DateFormat('yyyy-MM-d').format(dt);
        logic.    updateDateTime(dt);

          }catch(e){
            print(e.toString());
          }
        },


//      datetime: '1397/06/09',
      ).init()!;

      return SingleChildScrollView(
        child: ReactiveFormBuilder(
          form: buildForm,
          builder: (context, form, child) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    children: [

Ui.titleGreenUnderLine(AppStrings.createAccount.tr.capitalize!,fontSize: 28),
                      UiHelper.horizontalSpace(Get.width * .3)
                    ],
                  ),

                  Row(
                    children: [
                      Expanded(
                          child: Text(
                        AppStrings.fillRequiredInformation.tr,
                        style: AppStyles.subTitleStyle(),
                      )),
                      UiHelper.horizontalSpace(120),
                    ],
                  ),

                  // Row(
                  //   children: [
                  //     GestureDetector(
                  //       onTap: () {
                  //         logic.updateStep(0);
                  //       },
                  //       child: Padding(
                  //         padding: const EdgeInsets.symmetric(vertical: 20),
                  //         child: Row(
                  //           children: [
                  //             Ui.greenLine(
                  //                 opacity: logic.step == 0 ? 1.0 : 0.3),
                  //             UiHelper.horizontalSpace(5),
                  //             CircleAvatar(
                  //               radius: 12,
                  //               backgroundColor: logic.step == 0
                  //                   ? AppColors.primaryColor
                  //                   : AppColors.primaryColorOpacity,
                  //               child: Text(
                  //                 '1',
                  //                 style: logic.step == 0
                  //                     ? AppStyles.whiteStyle(
                  //                         size: 15, bold: true)
                  //                     : AppStyles.primaryStyle(
                  //                         opacity: .7, size: 15, bold: true),
                  //               ),
                  //             )
                  //           ],
                  //         ),
                  //       ),
                  //     ),
                  //     UiHelper.horizontalSpaceSmall,
                  //     GestureDetector(
                  //       onTap: () {
                  //         logic.updateStep(1);
                  //       },
                  //       child: Padding(
                  //         padding: const EdgeInsets.symmetric(vertical: 20),
                  //         child: Row(
                  //           children: [
                  //             Ui.greenLine(
                  //                 opacity: logic.step == 1 ? 1.0 : 0.3),
                  //             UiHelper.horizontalSpace(5),
                  //             CircleAvatar(
                  //               radius: 12,
                  //               backgroundColor: logic.step == 1
                  //                   ? AppColors.primaryColor
                  //                   : AppColors.primaryColorOpacity,
                  //               child: Text(
                  //                 '2',
                  //                 style: logic.step == 1
                  //                     ? AppStyles.whiteStyle(
                  //                         size: 15, bold: true)
                  //                     : AppStyles.primaryStyle(
                  //                         opacity: .7, size: 15, bold: true),
                  //               ),
                  //             )
                  //           ],
                  //         ),
                  //       ),
                  //     ),
                  //   ],
                  // ),
UiHelper.verticalSpaceMedium,
                  Visibility(
                    visible: true,
                    child: DynamicColumn(
                      children: [
                        ReactiveTextForm.reactiveRegisterTextField(
                            formControlName: nameKey,
                            label: AppStrings.fullName,
                            length: 30,
                          isName: true


                        ),                        const SizedBox(height: 15.0),
                        ReactiveTextForm.reactiveRegisterTextField(
                            formControlName: idNumberKey,
                            label: AppStrings.idNo,
                            isSSN: true,
                            length: 10


                        ),
                        UiHelper.verticalSpaceMedium,
                        ReactiveTextForm.reactiveRegisterTextField(
                            formControlName: mobileKey,
                            label: AppStrings.phoneNum,
                            isNumber: true,
                            length: 12


                        ),


//                         UiHelper.verticalSpaceMedium,
//
//                         Container(
//                           margin: EdgeInsets.symmetric(vertical: 5),
//                           decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)
//                               ,
//                               color: AppColors.primaryColorOpacity
//                           ),
//                           padding: EdgeInsets.symmetric(horizontal: 10,vertical: 15),
//                           child: Column(
//                             children: [
//                               Row(children: [
//
//                                 Expanded(child: Text(logic.nationality.question.tr,style: AppStyles.primaryStyle(bold: true,size: 13,height: 1.5),))
//                                 ,
//
//                                 UiHelper.horizontalSpaceMedium,
//
//                                 Row(
//
//
//                                   children: [
//
//
//
//                                     GestureDetector(
//                                       onTap: (){
//                                         logic.updateNationality(true);
//                                       },
//                                       child: SizedBox(
//                                         height: 30,
//                                         child: Row(
//                                           children: [
//
//                                             Text(AppStrings.saudi.tr,style: AppStyles.primaryStyleGreen(),),
//                                             SizedBox(width: 5,),
//                                             Container(
//                                               padding: EdgeInsets.all(3),
//                                               width: 20,height: 20,
//                                               decoration: BoxDecoration(
//                                                   color: yes?AppColors.primaryColorGreen:AppColors.primaryColorOpacity,
//                                                   borderRadius: BorderRadius.circular(5),
//                                                   border: Border.all(width: yes?0:2,color: AppColors.subTitleColor)
//
//                                               ),
//                                               child:yes? Icon(Icons.check,color: AppColors.white,size: 15,):Container(),
//                                             ),
//                                           ],
//                                         ),
//                                       ),
//                                     ),
//                                     UiHelper.horizontalSpaceMedium,
//                                     GestureDetector(
//                                       onTap: (){
//                                         logic.updateNationality(false);
//
//                                       },
//                                       child: SizedBox(
//                                         height: 30,
//                                         child: Row(
//                                           children: [
//
//                                             Text(AppStrings.nonSaudi.tr,style: AppStyles.primaryStyleGreen(),),
//                                             SizedBox(width: 10),
//                                             Container(
//                                               padding: EdgeInsets.all(3),
//                                               width: 20,height: 20,
//                                               decoration: BoxDecoration(
//                                                   color: noChecked?AppColors.primaryColorGreen:AppColors.primaryColorOpacity,
//                                                   borderRadius: BorderRadius.circular(5),
//                                                   border: Border.all(width: noChecked?0:2,color: AppColors.subTitleColor)
//
//                                               ),
//                                               child:noChecked? Icon(Icons.check,color: AppColors.white,size: 15,):Container(),
//                                             ),
//                                           ],
//                                         ),
//                                       ),
//                                     ),
//                                     UiHelper.verticalSpaceMedium,
// //Spacer()
//
// //         Expanded(
// //           child: IntrinsicWidth(
// //     child: Row(
// //     children: [
// //
// //     Text(AppStrings.other.tr,style: AppStyles.primaryStyleGreen(),),
// // UiHelper.horizontalSpaceMedium,
// //     Container(
// //     padding: EdgeInsets.all(3),
// //     width: 20,height: 20,
// //     decoration: BoxDecoration(
// //     color: !questionnaire.answer?AppColors.primaryColorGreen:AppColors.primaryColorOpacity,
// //     borderRadius: BorderRadius.circular(5),
// //     border: Border.all(width: !questionnaire.answer?0:2,color: AppColors.subTitleColor)
// //
// //     ),
// //     child:!questionnaire.answer? Icon(Icons.check,color: AppColors.white,size: 15,):Container(),
// //     ),
// //     ],
// //     ),
// //     ),
// //         ),
//                                   ],
//                                 ),
//
//                               ],),
//
//
//
//                             ],
//                           ),
//                         ),

                        UiHelper.verticalSpaceMedium,

                        Row(
                          children: [
                            Expanded(
                              flex: 3,
                              child:
                              ReactiveTextForm.reactiveRegisterTextField(
                                formControlName: ageKey,
                                label: AppStrings.age,
isNumber: true,
                                length: 3


                              ),
                            ),
                            UiHelper.horizontalSpaceMedium,
                            Expanded(
                              flex: 5,
                              child: Container(

                                decoration: Ui.getBoxDecorationLogin(),
                                padding: EdgeInsets.symmetric(horizontal: 10,vertical: 7),
                                child: Row(
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          AppStrings.gender.tr.capitalizeFirst!,
                                          style: AppStyles.primaryStyle(
                                              bold: true, size: 13),
                                        ),
                                      ],
                                    ),

                                    UiHelper.horizontalSpaceMedium,
                                    Row(
                                      children: [
                                        Ui.genderButton(
                                            title: AppStrings.male,
                                            selected: logic.gender == 0,
                                            onTab: () {
                                              logic.updateGender(0);
                                            }),
                                        UiHelper.horizontalSpaceMedium,
                                        Ui.genderButton(
                                            title: AppStrings.female,
                                            selected: logic.gender == 1,
                                            onTab: () {
                                              logic.updateGender(1);
                                            }),
                                        // UiHelper.horizontalSpaceLarge,
                                        // Icon(
                                        //   FontAwesomeIcons.male,
                                        //   color: logic.gender == 0
                                        //       ? AppColors.primaryColor
                                        //       : AppColors.subTitleColor,
                                        // ),
                                        // Icon(
                                        //   FontAwesomeIcons.female,
                                        //   color: logic.gender == 1
                                        //       ? AppColors.primaryColor
                                        //       : AppColors.subTitleColor,
                                        // ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),


                        const SizedBox(height: 15.0),
                        Row(
                          children: [
                            Expanded(
                              child:
                              ReactiveTextForm.reactiveRegisterPasswordTextField(
                                formControlName: passwordKey,
                                logic: logic,
                                label: AppStrings.password,


                              ),
                            ),



                            const SizedBox(width: 15.0),
                            Expanded(
                              child: ReactiveTextForm.reactiveRegisterPasswordTextField(
                                formControlName: confirmPasswordKey,
                                logic: logic,
                                label: AppStrings.passwordConfirm,


                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  ),

                  Visibility(
                    visible: false,
                    child: DynamicColumn(
                      children: [
                        IntrinsicHeight(
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  height: 70,
                                  decoration: Ui.getBoxDecorationLogin(),
                                  child: ReactiveTextField<String>(
                                    formControlName: mobileKey,
                                    validationMessages: (control) => {
                                      ValidationMessage.required:
                                          AppStrings.phoneNum.tr +
                                              ' ' +
                                              AppStrings.mustNotEmpty.tr,
                                    },
                                    inputFormatters: [
                                      FilteringTextInputFormatter.digitsOnly,
                                      LengthLimitingTextInputFormatter(10),
                                    ],
                                    keyboardType: TextInputType.number,
                                    textInputAction: TextInputAction.next,
                                    style: AppStyles.primaryStyleGreen(),
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      focusedErrorBorder: InputBorder.none,
                                      errorBorder: InputBorder.none,
                                      disabledBorder: InputBorder.none,
                                      enabledBorder: InputBorder.none,
                                      focusedBorder: InputBorder.none,

                                      labelText: AppStrings.phoneNum.tr,
                                      labelStyle: AppStyles.subTitleStyle(),
                                      // filled: true,

                                      //  fillColor: AppColors.filedBg ,
                                      contentPadding: EdgeInsets.symmetric(
                                          horizontal: 12,
                                          vertical: paddingHeight),
                                      hintText: AppStrings.phoneNum.tr,
                                      errorStyle: TextStyle(
                                          color: Colors.white.withOpacity(0.7)),
                                      hintStyle: TextStyle(
                                          color: Colors.white.withOpacity(0.7)),
                                      // prefixIcon: Icon(Icons.call,
                                      //
                                      //     color: Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                              // UiHelper.horizontalSpaceSmall,
                              // Column(
                              //   children: [
                              //     Expanded(
                              //       child: Container(
                              //         alignment: Alignment.center,
                              //         padding: EdgeInsets.all(10),
                              //         decoration: Ui.getBoxDecorationLogin(),
                              //         child: Text(
                              //           '966+',
                              //           style:
                              //               AppStyles.subTitleStyle(bold: true),
                              //         ),
                              //       ),
                              //     ),
                              //   ],
                              // ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 15.0),
                        Container(
                          // height: 80,
                          decoration: Ui.getBoxDecorationLogin(),
                          child: ReactiveTextField<String>(
                            formControlName: ageKey,
                            validationMessages: (control) => {
                              ValidationMessage.required:
                              AppStrings.age.tr +
                                  ' ' +
                                  AppStrings.mustNotEmpty.tr,
                            },

                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,

                              LengthLimitingTextInputFormatter(3),
                              //FilteringTextInputFormatter.allow(RegExp('^[0-9]{3}-[0-9]{2}-[0-9]{4}')),
                             // FilteringTextInputFormatter.allow(RegExp(r'^[12][0-9]*$')),

                              //WhitelistingTextInputFormatter(RegExp(r"[\d.]"))

                              // FilteringTextInputFormatter.allow(
                              //     RegExp(
                              //         r"^(?!666|000|9\\d{2})\\d{3}"
                              //         + "-(?!00)\\d{2}-"
                              //         +"(?!0{4})\\d{4}")),
                            ],
                            keyboardType: TextInputType.number,
                            textInputAction: TextInputAction.next,
                            style: AppStyles.primaryStyleGreen(),
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              focusedErrorBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              focusedBorder: InputBorder.none,

                              labelText: AppStrings.age.tr.capitalizeFirst.toString() ,
                              labelStyle: AppStyles.subTitleStyle(),
                              // filled: true,

                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 12, vertical: paddingHeight),
                              hintText: AppStrings.age.tr,
                              errorStyle: TextStyle(
                                  color: Colors.white.withOpacity(0.7)),
                              hintStyle: TextStyle(
                                  color: Colors.white.withOpacity(0.7)),
                              // prefixIcon: Icon(Icons.call,
                              //
                              //     color: Colors.white),
                            ),
                          ),
                        ),



                        UiHelper.verticalSpaceMedium,

                        Container(
                          margin: EdgeInsets.symmetric(vertical: 5),
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)
                              ,
                              color: AppColors.primaryColorOpacity
                          ),
                          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 15),
                          child: Column(
                            children: [
                              Row(children: [

                                Expanded(child: Text(logic.nationality.question.tr,style: AppStyles.primaryStyle(bold: true,size: 13,height: 1.5),))
                                ,

                                UiHelper.horizontalSpaceMedium,

                                Row(


                                  children: [



                                    GestureDetector(
                                      onTap: (){
                                        logic.updateNationality(true);
                                      },
                                      child: SizedBox(
                                        height: 30,
                                        child: Row(
                                          children: [

                                            Text(AppStrings.saudi.tr,style: AppStyles.primaryStyleGreen(),),
                                            SizedBox(width: 5,),
                                            Container(
                                              padding: EdgeInsets.all(3),
                                              width: 20,height: 20,
                                              decoration: BoxDecoration(
                                                  color: yes?AppColors.primaryColorGreen:AppColors.primaryColorOpacity,
                                                  borderRadius: BorderRadius.circular(5),
                                                  border: Border.all(width: yes?0:2,color: AppColors.subTitleColor)

                                              ),
                                              child:yes? Icon(Icons.check,color: AppColors.white,size: 15,):Container(),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    UiHelper.horizontalSpaceMedium,
                                    GestureDetector(
                                      onTap: (){
                                        logic.updateNationality(false);

                                      },
                                      child: SizedBox(
                                        height: 30,
                                        child: Row(
                                          children: [

                                            Text(AppStrings.nonSaudi.tr,style: AppStyles.primaryStyleGreen(),),
                                            SizedBox(width: 10),
                                            Container(
                                              padding: EdgeInsets.all(3),
                                              width: 20,height: 20,
                                              decoration: BoxDecoration(
                                                  color: noChecked?AppColors.primaryColorGreen:AppColors.primaryColorOpacity,
                                                  borderRadius: BorderRadius.circular(5),
                                                  border: Border.all(width: noChecked?0:2,color: AppColors.subTitleColor)

                                              ),
                                              child:noChecked? Icon(Icons.check,color: AppColors.white,size: 15,):Container(),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    UiHelper.verticalSpaceMedium,
//Spacer()

//         Expanded(
//           child: IntrinsicWidth(
//     child: Row(
//     children: [
//
//     Text(AppStrings.other.tr,style: AppStyles.primaryStyleGreen(),),
// UiHelper.horizontalSpaceMedium,
//     Container(
//     padding: EdgeInsets.all(3),
//     width: 20,height: 20,
//     decoration: BoxDecoration(
//     color: !questionnaire.answer?AppColors.primaryColorGreen:AppColors.primaryColorOpacity,
//     borderRadius: BorderRadius.circular(5),
//     border: Border.all(width: !questionnaire.answer?0:2,color: AppColors.subTitleColor)
//
//     ),
//     child:!questionnaire.answer? Icon(Icons.check,color: AppColors.white,size: 15,):Container(),
//     ),
//     ],
//     ),
//     ),
//         ),
                                  ],
                                ),

                              ],),



                            ],
                          ),
                        ),

                        UiHelper.verticalSpaceMedium,

                       Container(
                         decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)
                             ,
                             color: AppColors.primaryColorOpacity
                         ),
                         padding: EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                         child: Row(
                            children: [
                              Expanded(
                                child: Row(
                                  children: [
                                    Text(
                                      AppStrings.gender.tr.capitalizeFirst!,
                                      style: AppStyles.primaryStyle(
                                          bold: true, size: 13),
                                    ),
                                  ],
                                ),
                              ),

                              UiHelper.horizontalSpaceLarge,
                              Row(
                                children: [
                                  Ui.genderButton(
                                      title: AppStrings.male,
                                      selected: logic.gender == 0,
                                      onTab: () {
                                        logic.updateGender(0);
                                      }),
                                  UiHelper.horizontalSpaceMedium,
                                  Ui.genderButton(
                                      title: AppStrings.female,
                                      selected: logic.gender == 1,
                                      onTab: () {
                                        logic.updateGender(1);
                                      }),
                                  UiHelper.horizontalSpaceLarge,
                                  Icon(
                                    FontAwesomeIcons.male,
                                    color: logic.gender == 0
                                        ? AppColors.primaryColor
                                        : AppColors.subTitleColor,
                                  ),
                                  Icon(
                                    FontAwesomeIcons.female,
                                    color: logic.gender == 1
                                        ? AppColors.primaryColor
                                        : AppColors.subTitleColor,
                                  ),
                                ],
                              )
                            ],
                          ),
                       ),
                     //   UiHelper.verticalSpaceMedium,
                      ],
                    ),
                  ),

                  Ui.primaryButton(
                      title:
                           AppStrings.signUp ,
                      marginH: 0,
                      onTab: () {
                        if (true) {
                          print(form.value);
                          print(logic.dob);
                          if (form.valid ) {

                            var age=form.value[ageKey].toString();
                            var dob=DateTime(DateTime.now().year-int.parse(age),1,1);

                            var nationality= form.value[idNumberKey].toString().startsWith('1')?'KSA':'';
                            Map<String, dynamic> data = {
                              'gender': logic.genderType,
                              'ksa_nationality': nationality,
                              'dob':intl. DateFormat('yyyy-M-d').format(dob),

                            };
                            data.addAll(form.value);

                            if(form.value[passwordKey]==form.value[confirmPasswordKey]){

                            logic.register(data);

                            }
                            else{
                              logic.buildFailedSnackBar(msg:AppStrings.passwordMatch.tr );
                            }

                          } else {
                            // print(form.errors.toString());
                            //  form.markAllAsTouched();
                            logic.buildFailedSnackBar(
                                msg: AppStrings.fillAllRequiredFields.tr +
                                    '\n\n' +
                                    requiredFields +
                                    '\n' +
                                    AppStrings.passwordLengthHint.tr);
                          }
                        }
                      }),


                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: () {


                          //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                        },

                        child: Text(AppStrings.haveAccount.tr,style: AppStyles.subTitleStyle(bold: true,size: 15),),
                      ),
                      UiHelper.horizontalSpace(5),
                      GestureDetector(
                        onTap: () {
                          Get.back();
                          // Get.offAllNamed(AppRouteNames.login);


                          //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                        },

                        child: Text(AppStrings.logIn.tr,style: AppStyles.primaryStyle(bold: true,size: 15),),
                      ),
                    ],
                  ),

                  SizedBox(
                    height: 32,
                  ),

                  //  SizedBox(height: 50),
                ],
              ),
            );
          },
        ),
      );
    });
  }
}
