import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:globcare/app/utils/constants/booking_vars.dart';
import 'package:intl/intl.dart';

import '../../../core/language_and_localization/app_strings.dart';
import '../../../core/theme_helper/app_colors.dart';
import '../../../core/theme_helper/app_styles.dart';
import '../../../data/models/home_service.dart';
import '../../../data/models/m_appointment.dart';
import '../../../global_widgets/shared/ui_helpers.dart';
import '../../../global_widgets/ui.dart';
import '../../../routes/app_route_names.dart';
import '../../../utils/constants/app_images.dart';
import '../../booking_home_modules/appointment_base_controllers/appointment_base_controller.dart';

class AppointmentItem2 extends StatelessWidget {
  AppointmentItem2({this.appointment, this.homeService, Key? key})
      : super(key: key);
  bool ar = Get.locale.toString() == 'ar';
  List<String> status = [
    'scheduled',
    'completed',
    'visit_done',
    'canceled',
  ];

  HomeService? homeService;
  final Appointment? appointment;
  final DateFormat dateFormat = DateFormat("dd MMM yyyy HH:mm a");

  bool isMeetPossible(String currentStatus) {
    return status.contains(currentStatus.toLowerCase());
  }

  @override
  Widget build(BuildContext context) {
    var h = ((!isMeetPossible(appointment!.state)) &&
            appointment!.state.toLowerCase() != 'start'
        ? 100.0
        : 75.0);
    var imageW = ((!isMeetPossible(appointment!.state) &&
            appointment!.state.toLowerCase() != 'start')
        ? 90.0
        : 75.0);
    double radius = 15;
    String time = appointment!.period.isNotEmpty
        ? appointment!.period.capitalizeFirst!
        : DateFormat('HH:mm a', Get.locale.toString())
            .format((appointment!.appointmentDate));

    return ListTile(
      contentPadding:
          EdgeInsets.only(left: 0.0, right: 0.0, top: 5.h, bottom: 5.h),
      title: SizedBox(
        height: h.h,
        child: GestureDetector(
          onTap: () async {
            if (!isMeetPossible(appointment!.state.toLowerCase()) &&
                appointment!.state.toLowerCase() == 'start' &&
                homeService!.icon == AppImages.iconTeleMed) {
              Get.toNamed(AppRouteNames.meetingPage, arguments: appointment);
            }
          },
          child: Container(
            decoration: BoxDecoration(
                color: AppColors.primaryColorOpacity,
                borderRadius: BorderRadius.circular(radius.h)),
            child: Row(
              children: [
                Container(
                  width: imageW.w,
                  height: h.h,
                  decoration: BoxDecoration(
                    color: AppColors.iconAppointmentColor,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(ar ? 0 : radius.h),
                      topRight: Radius.circular(ar ? radius.h : 0),
                      bottomRight: Radius.circular(radius.h),
                      bottomLeft: Radius.circular(radius.h),
                    ),
                  ),
                  padding:
                      EdgeInsets.symmetric(horizontal: 10.w, vertical: 10.h),
                  child: Image.asset(
                    homeService!.icon,
                  ),
                ),
                Expanded(
                    child: Container(
                  height: h,
                  padding:
                      EdgeInsets.symmetric(vertical: 5.h, horizontal: 15.w),
                  decoration: BoxDecoration(
                    color: AppColors.primaryColorOpacity,
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(ar ? 0 : radius.h),
                      bottomRight: Radius.circular(ar ? 0 : radius.h),
                      topLeft: Radius.circular(ar ? radius.h : 0),
                      bottomLeft: Radius.circular(ar ? radius.h : 0),
                    ),
                  ),
                  child: Column(
                    children: [
                      UiHelper.verticalSpaceTiny,
                      Row(
                        children: [
                          Expanded(
                              child: Text(
                            '${appointment!.name}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppStyles.primaryStyle(bold: true, size: 13),
                          )),
                          UiHelper.horizontalSpaceSmall,
                        ],
                      ),
                      UiHelper.verticalSpaceTiny,
                      Row(
                        children: [
                          Expanded(
                              child: Text(
                            '${appointment!.doctor}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style:
                                AppStyles.subTitleStyle(bold: true, size: 12),
                          ))
                        ],
                      ),
                      UiHelper.verticalSpaceTiny,
                      Row(
                        children: [
                          Text(
                            DateFormat(' d ', Get.locale.toString())
                                .format((appointment!.appointmentDate)),
                            style: AppStyles.primaryStyleGreen(
                                bold: true, size: 11),
                          ),
                          Text(
                            DateFormat(' MMM ', Get.locale.toString())
                                .format((appointment!.appointmentDate)),
                            style: AppStyles.primaryStyleGreen(
                                bold: true, size: 11),
                          ),
                          Text(
                            DateFormat(' yyyy ', Get.locale.toString())
                                .format((appointment!.appointmentDate)),
                            style:
                                AppStyles.subTitleStyle(bold: true, size: 11),
                          ),
                          Text(
                            '  $time',
                            style: AppStyles.primaryStyle(
                                opacity: .8, bold: true, size: 11),
                          ),
                          UiHelper.horizontalSpaceMedium,
                          SvgPicture.asset(
                            AppImages.calendar,
                            color: AppColors.primaryColorGreen,
                            width: 18.w,
                            height: 18.h,
                          ),
                        ],
                      ),
                      UiHelper.verticalSpaceTiny,
                      if (!isMeetPossible(appointment!.state) &&
                          appointment!.state.toLowerCase() != 'start')
                        Row(
                          children: [
                            GestureDetector(
                              onTap: () {
                                Get.bottomSheet(
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        vertical: 50.h, horizontal: 30.w),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        children: [
                                          Text(
                                            AppStrings.sendCancelAppointment.tr,
                                            textAlign: TextAlign.center,
                                            style: AppStyles.primaryStyle(
                                                bold: true, size: 16),
                                          ),
                                          Ui.primaryButton(
                                              title: AppStrings.sendRequest,
                                              onTab: () {
                                                BookingVars.patient=AppointmentBaseController().currentUser;
                                                Map<String, String> data = {
                                                  'appointment_id':
                                                      '${appointment!.id}',
                                                  'type': homeService!.code,
                                                };

                                                AppointmentBaseController()
                                                    .requestCancelAppointment(
                                                        data);
                                              })
                                        ],
                                      ),
                                    ),
                                  ),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(10.h),
                                          topLeft: Radius.circular(10.h))),
                                  backgroundColor: AppColors.white,
                                );
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    vertical: 2.h, horizontal: 5.w),
                                decoration: BoxDecoration(
                                    color: AppColors.primaryColorGreen,
                                    borderRadius: BorderRadius.circular(5.h)),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.clear,
                                      color: AppColors.white,
                                      size: 18.w,
                                    ),
                                    UiHelper.horizontalSpaceTiny,
                                    Text(
                                      AppStrings.cancelRequest.tr,
                                      style: AppStyles.primaryStyle(
                                          color: AppColors.white,
                                          bold: true,
                                          size: 10),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                )),
                if ((appointment!.state.toLowerCase() == 'start') &&
                    homeService!.icon == AppImages.iconTeleMed)
                  Container(
                    width: 25.w,
                    height: h,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: AppColors.primaryColor,
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(ar ? 0 : radius.h),
                        bottomRight: Radius.circular(ar ? 0 : radius.h),
                        topLeft: Radius.circular(ar ? radius.h : 0),
                        bottomLeft: Radius.circular(ar ? radius.h : 0),
                      ),
                    ),
                    padding: EdgeInsets.all(0),
                    child: RotatedBox(
                        quarterTurns: ar ? 3 : 1,
                        child: Text(
                          AppStrings.startMeeting.tr,
                          style: AppStyles.primaryStyle(
                              size: 11, color: AppColors.white),
                        )),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
