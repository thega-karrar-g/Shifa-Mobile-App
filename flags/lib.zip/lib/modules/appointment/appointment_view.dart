import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/appointment/widgets/appointment_list.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/tab_item.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';

import '../../shared_in_ui/shared/loading.dart';
import 'appointment_controller.dart';

class AppointmentPage extends GetView<AppointmentController> {
  @override
  final controller = Get.put(AppointmentController());

  AppointmentPage({Key? key}) : super(key: key);

  @override

  Widget build(BuildContext context) {
    return Ui.myScaffold(child: GetBuilder<AppointmentController>(builder: (controller) {
      return Column(
        children: [
          myAppBar2(title: controller.arg.name,showAll: true),


          UiHelper.verticalSpaceMedium,
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Container(
              height: 60,
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [

                  TabItem(name: AppStrings.scheduled,fontSize: 13,selected: controller.index.value==0, onTab: (){
                    controller.updateIndex(0);

                  }),

                UiHelper.horizontalSpaceMedium,
                  TabItem(name: AppStrings.confirmed,fontSize: 13,selected: controller.index.value==1, onTab: (){
                    controller.updateIndex(1);

                  }),

                UiHelper.horizontalSpaceMedium,
                TabItem(name: AppStrings.completed,fontSize: 13,selected: controller.index.value==2, onTab: (){
                  controller.updateIndex(2);

                }),
                UiHelper.horizontalSpaceMedium,
                TabItem(name: AppStrings.canceled,fontSize: 13,selected: controller.index.value==3, onTab: (){
                  controller.updateIndex(3);

                }),

              ],),
            ),
          ),

          //    myAppBar(title: AppStrings.appointment.tr.capitalize!),
          Expanded(
              child: (!controller.busy)
                  ? RefreshIndicator(
                onRefresh: ()=>controller.getAppointments(),
                child: AppointmentList(
                  homeService: controller.arg,
                  appointments:  controller.currentAppointments,
                ),
              )
                  : Center(child: MyLoadingWidget())
          ),
        ],
      );
    }));
  }
}
