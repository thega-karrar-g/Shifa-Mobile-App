import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/utils/constants/app_anim.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
class NoDataFound extends StatelessWidget {
  const NoDataFound({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(



      child: SingleChildScrollView(
        child: Column(
       // mainAxisAlignment: MainAxisAlignment.center,
        //crossAxisAlignment: CrossAxisAlignment.center,
        children: [

        Padding(
          padding: const EdgeInsets.symmetric(vertical: 1),
          child: Lottie.asset(AppAnim.search,width: Get.width*.7,height: Get.height*.3,),
        ),
          Text(AppStrings.noDataFound.tr,style: AppStyles.primaryStyle(size: 16),),


    ],),
      ),);
  }
}
