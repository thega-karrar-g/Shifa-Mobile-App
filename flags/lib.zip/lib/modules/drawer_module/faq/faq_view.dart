import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/about_model.dart';
import 'package:sehati_app/modules/aboutus/widgets/about_item.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';

import 'faq_logic.dart';

class FAQPage extends StatelessWidget {
  final FAQLogic logic = Get.put(FAQLogic());

   FAQPage({Key? key}) : super(key: key);



  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: Column(children: [

      myAppBar2(title: AppStrings.faq),

      Expanded(child: SingleChildScrollView(
        child: Wrap(
          children: [
            ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: AboutModel.faqList.length,
                itemBuilder: (bc,index)=>AnimationConfiguration.staggeredList(
                    position: index,
                    duration: Duration(milliseconds:500 ),

                    child: SlideAnimation(
                        verticalOffset: 100,
                        duration: Duration(milliseconds: 500),
                        child: AboutItem(aboutModel: AboutModel.faqList[index],))
                )),

          ],
        ),
      )),


    ],))
    ;
  }
}
