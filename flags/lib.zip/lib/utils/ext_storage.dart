import 'dart:io';

import 'package:dio/dio.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';

class  ExtStorage{





 static Future<Directory> getDir()async {
   Directory? ex, directory;

 ex =  Platform.isAndroid
     ? await getExternalStorageDirectory() //FOR ANDROID
     : await getApplicationSupportDirectory();

    //directory=Directory(ex!.path+'/Globcare');
    directory=ex!;

    if (! await ex.exists()) {

      directory =
      await Directory(directory.path).create(recursive: true,);
      return directory;

    }
    else{

      return directory;
    }

  }

static Future<bool> checkGranted()async {

  return (await Permission.storage
      .request()
      .isGranted);
}



static Future<bool> fileExist(String path)async{

var exist=false;
   var d=  Directory((await getDir()).path+'/'+ path);

var s= await getDir() ;
var ss=s.listSync();
for (var element in ss) {
if(element.path==d.path){


  exist=true;
  break;
}
}
   return exist;


 }


static Future<String> savePathFile(fileName)async{
   var dir=await getDir();
   return dir.path + "/$fileName";
 }


 static downloadFile({String url='',String fileName=''})async{

var savePath=await savePathFile(fileName);

   try {

     print('*********************   $savePath');

     await Dio().download(
         url,
         savePath,
         onReceiveProgress: (received, total) {
           if (total != -1) {
             print((received / total * 100).toStringAsFixed(0) + "%");
             //you can build progressbar feature too
           }
         });
     print("File is saved to download folder.");
   } on DioError catch (e) {
     print(e.message);
   }

 }

static openFile(String filePath)async{

   var d=await getDir();
   OpenFile.open("${d.path}/$filePath");


 }


}