// import 'package:auto_size_text/auto_size_text.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:sehati_app/language_and_localization/app_strings.dart';
//
//
// class DrawerWidget extends StatelessWidget {
//   const DrawerWidget({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Drawer(
//       elevation: 0,
//       child: ListView(
//         children: <Widget>[
//           ListTile(
//             onTap: () {},
//             leading: Icon(
//               Icons.home,
//               color: Theme.of(context).focusColor.withOpacity(1),
//             ),
//             title: AutoSizeText(
//               AppStrings.home.tr.capitalizeFirst,
//               style: Theme.of(context).textTheme.subtitle1,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
