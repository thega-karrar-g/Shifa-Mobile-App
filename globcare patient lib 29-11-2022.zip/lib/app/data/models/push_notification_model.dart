class PushNotification {
  String? title;
  String? body;

  PushNotification({
    this.title,
    this.body,
  });

  factory PushNotification.fromMap(Map<String, dynamic> map) {
    return PushNotification(
      title: map['title'] as String,
      body: map['body'] as String,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'body': body,
    };
  }
}
