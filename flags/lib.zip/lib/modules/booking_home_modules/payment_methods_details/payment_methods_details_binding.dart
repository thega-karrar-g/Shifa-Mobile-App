import 'package:get/get.dart';

import 'payment_methods_details_logic.dart';

class PaymentMethodDetailsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => PaymentMethodDetailsLogic());
  }
}
