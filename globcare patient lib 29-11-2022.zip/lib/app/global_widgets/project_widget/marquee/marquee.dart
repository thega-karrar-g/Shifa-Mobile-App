library marquee;

export 'alternatemarquee.dart' show AlternateMarquee;
export 'scrollmarquee.dart' show ScrollMarquee;
export 'speed.dart';
