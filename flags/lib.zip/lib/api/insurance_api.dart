import 'package:dio/dio.dart';
import 'package:sehati_app/utils/constants/app_urls.dart';
import 'base_api.dart';
import 'package:http/http.dart' as http;

class InsuranceApi extends BaseApi {
  static final _insuranceApi = InsuranceApi._internal();

  factory InsuranceApi() => _insuranceApi;

  InsuranceApi._internal();

  Future<http.Response?> getInsuranceCompanies() async {
    try {
      var response = await api.httpGet(AppUrls.insurance,);
      return response;
    } on DioError catch (_) {
      //
      return null;
    }
  }
}
