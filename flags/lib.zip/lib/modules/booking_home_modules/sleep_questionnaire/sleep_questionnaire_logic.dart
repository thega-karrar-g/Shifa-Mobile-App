
import 'package:get/get.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/api/appointment_api.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/questionnaire.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';

import '../../../language_and_localization/app_strings.dart';
import '../../../shared_in_ui/shared/different_dialogs.dart';

class SleepQuestionnaireLogic extends BaseController {


 final AppointmentApi _appointmentApi=AppointmentApi();

  List<Questionnaire> questions=[

    Questionnaire(id: 1,question: 'Do you snore?',questionAr: 'هل تشخّر؟'),
    Questionnaire(id: 2,question: "Do you wake up feeling lite he/she hasn't slept, and feeling fatigued during the day? ",questionAr: 'هل تستيقظ من النوم ولديك شعور بأنك لم تنام وتشعر بالتعب أثناء النهار؟'),
    Questionnaire(id: 3,question: 'Have you been told that you stop breathing at night? Do you gasp for air or choke while sleeping?',questionAr: 'هل قيل لك أن تنفسك يتوقف أثناء الليل وتشعر بصعوبة في التنفس أو الاختناق أثناء النوم؟'),
    Questionnaire(id: 4,question: 'Do you have high blood pressure or on medication to control high blood pressure?',questionAr: 'هل ضفط الدم لديك مرتفع؟ أو تستخدم أدوية للتحكم بارتفاع الضغط؟'),
    Questionnaire(id: 5,question: 'Are you male?',questionAr: 'هل أنت ذكر؟'),
    Questionnaire(id: 6,question: 'Are you 50 years old or older?',questionAr: 'هل عمرك 50 أو أكثر؟'),


  ];

  Questionnaire nationality=Questionnaire(answer: true,questionAr: 'الجنسية: سعودي',question: AppStrings.saudiNationality);


  updateNationality(){

   // nationality.answer=! nationality.answer;
    update();

  }
  updateQuestion(Questionnaire q){

    q.answer=! q.answer!;
    update();

  }

 final  nameKey='patient';
 final  contactKey='mobile';

 final  neckKey='neck_circ';
  final  heightKey='height';
  final  weightKey='weight';

  late FormGroup form;

@override
  void onInit() {
    // TODO: implement onInit
    super.onInit();

    form=FormGroup({
      // nameKey: FormControl<String>(
      //     validators: [Validators.required]
      //
      // ),
      // neckKey: FormControl<String>(
      //     validators: [Validators.required]
      //
      // ),
      // contactKey: FormControl<String>(
      //     validators: [Validators.required]
      //
      //
      // ),


      weightKey: FormControl<String>(
validators: [Validators.required]
      ),
      heightKey: FormControl<String>(
          validators: [Validators.required]


      ),
    }) ;

  }



  void send() async {
    Map<String, dynamic> data={};

//if(form.valid){


  data.addAll(form.value);
  data.addAll(
      {
        nameKey:currentUser!.id.toString(),
        contactKey:currentUser!.phone.toString(),
        'location':PatientDataLogic.location,
    'service_id':PatientDataLogic.service.id,
    'ksa_nationality':nationality.answer!?'KSA':'',
    neckKey:'1',

      });


  for (var e in questions) {

    data.addAll ({'question${e.id}':e.answer!=null? (e.answer!?'yes':'no'):''});

  }
  print(data);
  if(!noInternetConnection()) {

    DifferentDialog.showProgressDialog();

    _appointmentApi.requestSleepMedicine(data).then((value) async {
      try {
        var respo = value!.data;

        Get.back();
        if (respo['success'] == 1) {
                   //    buildSuccessSnackBar(msg: respo['data']['message']);
                       print( respo['data']['message']);








          //   await DifferentDialog.hideProgressDialog();
          DifferentDialog.showRequestServiceSuccessDialog();

          // Get.toNamed(AppRouteNames.successRegister);

        } else {
          buildFailedSnackBar(msg: respo['message']);
        }

      } catch (_) {
      }
    });
  }else{
    buildFailedSnackBar(msg: AppStrings.checkInternet.tr);
  }


//}
// else{
//            buildFailedSnackBar(msg: AppStrings.fillHWFields.tr);
//
// }



  }


}
