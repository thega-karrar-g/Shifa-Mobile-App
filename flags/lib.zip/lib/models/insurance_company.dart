

class  InsuranceCompany{

  int id=0;
  String name='',image='';

  InsuranceCompany({this.id=0,this.name='',this.image=''});


}