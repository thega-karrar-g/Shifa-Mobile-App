import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/widgets/reactive_register_form.dart';

import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';

import '../auth_controller.dart';

class Register2Page extends GetView<AuthController> {
  // final controller = Get.find<DoctorsController>();
  @override
  final controller = Get.put(AuthController());
final  double  paddingHeight=15.0;


 String  idNumberKey='ssn';
 String  passwordKey='password';
 String  nameKey='name';
 String  mobileKey='mobile';
 String  genderKey='gender';
 String  dobKey='dob';

  Register2Page({Key? key}) : super(key: key);


  var requiredFields=' '

      '${AppStrings.phoneNum.tr} *\n'
      '${AppStrings.password.tr} *\n'
      ''
      '';

  FormGroup buildForm() => fb.group(<String, Object>{
        nameKey: FormControl<String>(
          validators: [
            Validators.required,


          ],
        ),
        mobileKey: FormControl<String>(
          validators: [
            Validators.required,


          ],
        ),
        passwordKey: ['', Validators.required, Validators.minLength(6)],
        idNumberKey: ['', Validators.required, Validators.minLength(10),Validators.maxLength(10)],
      });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,

      body: GetBuilder<AuthController>(builder: (logic) {

  return SafeArea(
    minimum: UiHelper.safeAreaPadding,
    child: Stack(
      children: [
        Column(
          children: [
            UiHelper.verticalSpaceMassive,

            Expanded(child: ReactiveRegisterForm()),


          ],
        ),

        SizedBox(

        ),
      // if(logic.busy)
      //   Positioned.fill(
      //   // top: Get.height*.1,
      //
      //   //   right: Get.width*.5,
      //     child: Align(
      //       alignment: Alignment.center,
      //       child: Column(
      //         children: [
      //           DifferentDialog.loadingDialog()                                    ],
      //       ),
      //     ))

      ],
    ),
  );
})
    );
  }
}
