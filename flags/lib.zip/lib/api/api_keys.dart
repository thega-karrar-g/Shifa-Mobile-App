class ApiKeys{



  static const mapKey='AIzaSyDVGNZKy1QWwhMMa0HFMyUUOtXW3lP0NgM';
  static const cash='';
  static const insurance='';
  static const doctorTD='';
  static const doctorHHCD='';
  static const profileImage='ufile';



}