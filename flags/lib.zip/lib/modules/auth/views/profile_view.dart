import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/widgets/profile_form.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

import '../auth_controller.dart';

class ProfilePage extends GetView<AuthController> {
  // final controller = Get.find<DoctorsController>();
  @override
  final controller = Get.put(AuthController());

  ProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(
                //color: AppColors.primaryColor

                // color: AppColors.extraGrey
                ),
            child: SizedBox(
              width: MediaQuery.of(context).size.width * (88),
              child: SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                child: Container(
                  margin: EdgeInsets.symmetric(vertical: 10),
                  padding: EdgeInsets.only(right: 27, left: 27),
                  child: Column(
                    children: <Widget>[
                      SizedBox(height: Get.height*.08),
                      Row(children: [

                        SizedBox(width: 1,),

                        GestureDetector(
                            onTap: ()=>Get.back(),
                            child: Icon(Icons.arrow_back_ios_outlined,color: AppColors.primaryColor,)),
                        SizedBox(width: Get.width/4,),

                        Text(AppStrings.editProfile.tr,style: Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.primaryColor,fontWeight: FontWeight.bold)),),


                      ],),
                      SizedBox(height: Get.height*.05),


                      Stack(
                        clipBehavior: Clip.none, // This is what you need.
                        children: [
                        Ui.circluarImg(url: '',size: 120,errorImg: AppImages.doctorImg,margin: 0),
                        Positioned(
                          bottom: -13,
                          right: 47,
                          child: GestureDetector(child:
                          Container(
                              width: 30,
                              height: 30,
                              padding: EdgeInsets.zero,
                              decoration: BoxDecoration(
                                //  borderRadius: BorderRadius.circular(20),
                                  shape: BoxShape.circle,
                                  color: AppColors.primaryColor
                              ),
                              child: Icon(Icons.add,size: 25,color: AppColors.white,)),

                          ),)

                      ],),

                      Column(
                     //   mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: EdgeInsets.only(bottom: 10.0),
                            width: Get.width * (84),
                            child: Center(
                                // child: Text(
                                //   'lets_start_with_login',
                                //   style: Theme.of(context).textTheme.bodyText1!.merge(TextStyle(fontSize: 12, color: Colors.white)),
                                // ),
                                ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      ProfileForm(
                      ),
                      SizedBox(height: 30),
                      SizedBox(height: 20),
                      SizedBox(
                          height: MediaQuery.of(context).size.height * 0.04),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
