import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'receipt_payment_logic.dart';

class ReceiptPaymentPage extends StatelessWidget {
  final logic = Get.put(ReceiptPaymentLogic());

   ReceiptPaymentPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
