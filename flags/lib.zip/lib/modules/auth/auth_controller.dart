import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:persian_datepicker/persian_datepicker.dart';
import 'package:sehati_app/api/api.dart';
import 'package:sehati_app/api/login_api.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/questionnaire.dart';
import 'package:sehati_app/models/user_model.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/shared_in_ui/shared/different_dialogs.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/constants/app_urls.dart';

import '../../utils/helpers/theme_helper/app_colors.dart';
import '../../utils/helpers/theme_helper/app_fonts.dart';
import '../../utils/helpers/theme_helper/app_styles.dart';

class AuthController extends BaseController {
  final AuthApi _loginApi = AuthApi();
  bool hidePassword = true;
  bool isLoading = false;
TextEditingController dobTextEditingController=TextEditingController();
  int profileIndex=0;
  RxInt genderIndex=0.obs;

  int step=0;


   DateTime? dob=DateTime.now();
  late PersianDatePickerWidget persianDatePicker;

   updateDateTime(DateTime dateTime){

     dob=dateTime;
     update();
   }
  var mapUser={};
  var resultLocation='';

  String genderType='Male';
  final Questionnaire nationality=Questionnaire(question: AppStrings.nationality,);


  int gender=0;


  updateNationality(bool value){

    nationality.answer=value;
    update();
  }

  updateGender(int index){

    gender=index;
    genderType=  gender==0?'Male':'Female';

    update();
  }

  updateStep(int st){

    step=st;
    update();

  }

  updateLocation(String? txt){


    if(txt!=null&&txt.isNotEmpty){
    resultLocation=txt;}
    else
      {buildFailedSnackBar(msg: AppStrings.selectLocationMsg.tr);}

    update();
  }



  updateGenderIndex(int selected){

    genderIndex.value=selected;
    update();
  }
  updateProfileIndex(int selected){

    profileIndex=selected;
    update();
  }

  updatePassword(bool hide){
    hidePassword=hide;
    update();
  }
  updateLoading(bool load){
    isLoading=load;
    update();
  }

  void login(Map<String, dynamic> allValues) async {
    DifferentDialog.showProgressDialog();
    var data = {
      'username': allValues[AppStrings.emailKey],
      'password': allValues[AppStrings.passwordKey],
      'db':'bitnami_odoo',
    };
    _loginApi.getLoginHttp(data).then((value) {
      var jsonResponse = (value!.data);
      print(jsonResponse);

      if (jsonResponse['success'] == 1) {
         var userMap = jsonResponse['data'];
             LoginModel model = LoginModel.fromMap(userMap);



         _loginApi.getProfile(AppUrls.userDetails+'/${model.userType}/${model.uid}',model.token).then((details) {

          var res = json.decode(details!.body);

          var  map=res['data'][0];
AppUser user=AppUser.fromMap(map);

user.token=model.token;
user.userType=model.userType.toString();


          authService.saveUserInfoToHive(user);

          Get.offAllNamed(AppRouteNames.home);

        });



      } else {
        buildFailedSnackBar(msg: jsonResponse['message']);
      }
    });

    // var result = await _userRepository.loginWithEmailThenGetUserData(user);
    await DifferentDialog.hideProgressDialog();
  }
  void login2(Map<String, dynamic> allValues) async {

if(!noInternetConnection()) {
  setBusy(true);

  await DifferentDialog.showProgressDialog();

  var data = {
    'username': allValues['username'],
    'password': allValues[AppStrings.passwordKey],
    'db': 'shifa_server_db',
  };
  _loginApi.getLoginHttp(data).then((value) async {


    try {
      var jsonResponse = (value!.data);


      Get.back();

      if (jsonResponse['success'] == 1) {
        var userMap = jsonResponse['data'];

        AppUser user = AppUser.fromMap(userMap);
        user.token = Api.token;
        user.userType = '1';

        authService.saveUserInfoToHive(user);

        if(PatientDataLogic.fromPatientData!=null) {
          Get.back();
         // Get.offNamedUntil(AppRouteNames.patientData,ModalRoute.withName(AppRouteNames.patientData));
        }
        else{
          Get.offAllNamed(AppRouteNames.home);

        }


      }
      else if (jsonResponse['success'] == 0) {

        buildFailedSnackBar(msg: AppStrings.invalidData.tr);
//Get.back();
      }


      setBusy(false);
    } catch (e) {
      setBusy(false);
      print(e.toString());
    }
  });
}
else{
  buildFailedSnackBar(msg: AppStrings.checkInternet.tr);
}
  }
  void getUserDetails({String id='0'}) async {

if(!noInternetConnection()) {
  setBusy(true);




  _loginApi.getUserDetailsHttp(id: id).then((value) async {


    try {
      var jsonResponse = json.decode(value!.body);

      if (jsonResponse['success'] == 1) {
        var userMap = jsonResponse['data'] as List;

        AppUser user = AppUser.fromMap(userMap[0]);
        user.token = Api.token;
        user.userType = '1';

        authService.saveUserInfoToHive(user);


        // if(PatientDataLogic.fromPatientData !=null){
        //
        //   Get.back();
        // }
        // else{
        //   Get.offAllNamed(AppRouteNames.home);
        // }



      }
      else if (jsonResponse['success'] == 0) {
        setBusy(false);

      }


      setBusy(false);
    } catch (e) {
      setBusy(false);
    }
  });
}
else{
}
  }

  void register(Map<String, dynamic> data) async {

    if(!noInternetConnection()) {
      setBusy(true);

        DifferentDialog.showProgressDialog();

      _loginApi.getRegisterHttp(data).then((value) async {
        try {
          var respo = json.decode(value!.body.toString());

          Get.back();
          if (respo['success'] == 1) {
           // print('id:************************* ${respo['data']['id']} ');
           // login2({'username':data['ssn'],'password':data['password']});
          //  buildSuccessSnackBar(msg: respo['data']['message']);


            var userMap = respo['data'] ;

            AppUser user = AppUser.fromMap(userMap);
            user.token = Api.token;
            user.userType = '1';

            authService.saveUserInfoToHive(user);


            if(PatientDataLogic.fromPatientData !=null){

              Get.back();
            }
            else{
              Get.offAllNamed(AppRouteNames.home);
            }



            setBusy(false);



            //   await DifferentDialog.hideProgressDialog();
          //  DifferentDialog.showRegisterSuccessDialog2();

            // Get.toNamed(AppRouteNames.successRegister);

          } else {
            buildFailedSnackBar(msg: respo['message']);
          }

          setBusy(false);
        } catch (e) {
          setBusy(false);
        }
      });
    }else{
      buildFailedSnackBar(msg: AppStrings.checkInternet.tr);
    }

  }
  void registerGuest(Map<String, dynamic> data) async {

    if(!noInternetConnection()) {
      setBusy(true);

        DifferentDialog.showProgressDialog();
print(data);
      _loginApi.getRegisterGuestHttp(data).then((value) async {
        try {
          var respo = json.decode(value!.body.toString());

          Get.back();
          if (respo['success'] == 1) {
           // login2({'username':data['ssn'],'password':data['password']});
          //  buildSuccessSnackBar(msg: respo['data']['message']);


            var userMap = respo['data'] ;
userMap['mobile']=data['mobile'];
userMap['dob']='2022-1-1';
            AppUser user = AppUser.fromMapGuest(userMap);
            user.token = Api.token;
            user.userType = '2';
            user.dob='2022-1-1';

          authService.saveUserGuestInfoToHive(user);

            if(PatientDataLogic.fromPatientData !=null){

              Get.back();
            }
            else{
              Get.offAllNamed(AppRouteNames.home);
            }



            setBusy(false);



            //   await DifferentDialog.hideProgressDialog();
          //  DifferentDialog.showRegisterSuccessDialog2();

            // Get.toNamed(AppRouteNames.successRegister);

          } else {
            buildFailedSnackBar(msg: respo['message']);
          }

          setBusy(false);
        } catch (e) {
          setBusy(false);
        }
      });
    }else{
      buildFailedSnackBar(msg: AppStrings.checkInternet.tr);
    }

  }


  void editProfile(Map<String, dynamic> data) async {
  //  var dob = DateFormat('yyyy-MM-dd').format(data['dob']);
    var myData = {
      'login': data['login'],
      'name': data['name'],
      'password': data['password'],

    };


    DifferentDialog.showProgressDialog();

    _loginApi.register(myData).then((value) {

      if (value!.data!['success'] == 1) {
      } else {
        buildFailedSnackBar(msg: value.data['message']);
      }
    });

    // var result = await _userRepository.loginWithEmailThenGetUserData(user);
    await DifferentDialog.hideProgressDialog();

    //  Get.toNamed(AppRouteNames.home);
  }


  late Position _currentPosition;
  String? _currentAddress;
  final addressController = TextEditingController(text: '');

  getCurrentLocation() async {
    await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
        .then((Position position) async {
      _currentPosition = position;
      await _getAddress();
      update();
    }).catchError((e) {

//
    });
  }

  // Method for retrieving the current address
  _getAddress() async {
    try {
      List<Placemark> p = await placemarkFromCoordinates(
          _currentPosition.latitude, _currentPosition.longitude);
      Placemark place = p[0];
      _currentAddress =
      "${place.street}, ${place.subLocality ?? ''}, ${place.locality ?? ''} , ${place.administrativeArea ?? ''}, ${place.country}";
     // addressController.text = _currentAddress!;
      resultLocation = _currentAddress!;

      update();
    } catch (e) {

//
    }
  }


  changePassword(query)async{





    DifferentDialog.showProgressDialog();


    var edit=await  _loginApi.changePasswordHttp(query);

    var jsonRes=json.decode(edit!.body.toString());

    Get.back();

    if(jsonRes['success']==1) {


      var res= await  DifferentDialog.showEditProfileSuccessDialog(msg: AppStrings.passwordUpdateSuccessfully);

      if(res){
        Get.back();

      }
    }
    else{
      buildFailedSnackBar(msg: jsonRes['message'].toString());
      return false;
    }


  }



  registerMap(map)=>{
    'name':map['fname']+'  '+ map['midname'] +'  '+map['lastname'],
    'username':map['mobile'],
    'password':map['password'],
    'email':map['login'],
    'mobile':map['mobile'],
    'street':map['location'],
    'ssn':map['ssn'],
    'gender':map['gender'],
    'dob': DateFormat('dd/MM/yyyy').format( DateTime.parse( map['dob'].toString().substring(0,10))),




  };

@override
  void onInit()async {
    // TODO: implement onInit
    super.onInit();
    var d=dob!;
    var max=DateTime.now();
    var duration =Duration(milliseconds: 200);
         persianDatePicker = PersianDatePicker(
      controller: dobTextEditingController,
      showGregorianDays: true,
      locale: Get.locale.toString(),

      currentDayBackgroundColor: AppColors.primaryColorOpacity,
      selectedDayBackgroundColor: AppColors.primaryColor,
      selectedDayTextStyle: AppStyles.whiteStyle(bold: true),
      headerTodayTextStyle: AppStyles.whiteStyle(bold: true),
      headerTodayIcon: Icon(FontAwesomeIcons.calendarDay,color: AppColors.white,),
      weekCaptionsBackgroundColor: AppColors.primaryColor,
      headerTodayBackgroundColor: AppColors.primaryColorGreen,
      monthSelectionBackgroundColor: AppColors.primaryColorOpacity,
      monthSelectionHighlightBackgroundColor: AppColors.primaryColorGreen,
      monthSelectionTextStyle: AppStyles.primaryStyle(),
      monthSelectionHighlightTextStyle: AppStyles.whiteStyle(),
      weekCaptionsTextStyle: AppStyles.whiteStyle(size:Get.locale.toString()=='ar'?10:13),

      yearSelectionBackgroundColor: AppColors.primaryColorOpacity,
      yearSelectionHighlightBackgroundColor: AppColors.primaryColorGreen,
      yearSelectionTextStyle: AppStyles.primaryStyle(),
      yearSelectionHighlightTextStyle: AppStyles.whiteStyle(),
      changePageDuration: duration,
      monthSelectionAnimationDuration: duration,
      yearSelectionAnimationDuration: duration,

      fontFamily: AppFonts.mainFontFamily,
      maxDatetime: '${max.year}/${max.month}/${max.day}',
      // finishDatetime: '${d.year}/${d.month}/${d.day}',
      // gregorianDatetime: '${d.year}-${d.month}-${d.day}',
      // minDatetime: '${min.year}/${min.month}/${min.day}',
      rangeDatePicker: false,
      datetime: '${d.year}/${d.month}/${d.day}',
      outputFormat: 'YYYY/M/D',
// maxSpan: Duration(days: 1),
// minSpan: Duration(days: 0),
      farsiDigits: false,
      headerTodayCaption: AppStrings.today.tr,
      weekCaptions: [AppStrings.sat.tr,AppStrings.sun.tr,AppStrings.mon.tr,
        AppStrings.tue.tr,AppStrings.wed.tr,AppStrings.thu.tr,AppStrings.fri.tr],
// datetime: DateFormat('yyyy/MM/dd').format(DateTime.now()),
// finishDatetime: DateFormat('yyyy/MM/dd').format(DateTime.now().add(Duration(days: 0))),
//         gregorianFinishDatetime: DateFormat('yyyy-MM-dd').format(DateTime.now().add(Duration(days: 0))),
// gregorianDatetime: DateFormat('yyyy-MM-dd').format(DateTime.now().add(Duration(days: 0))),
      onChange: (String oldText, String newText) {

        print(newText);
        try {
          var list=newText.split('/');
          var dt=DateTime(int.parse(list[0]),int.parse(list[1]),int.parse(list[2]));
          //var dd = DateFormat('yyyy-MM-d').format(dt);
              updateDateTime(dt);

        }catch(e){
          print(e.toString());
        }
      },


//      datetime: '1397/06/09',
    ).init()!;



}

}
