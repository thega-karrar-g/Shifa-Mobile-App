import 'dart:convert';
import 'dart:core';
import 'dart:io';
import 'dart:math';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:globcare/app/utils/constants/app_urls.dart';
import 'package:urwaypayment/urwaypayment.dart';

import '../../../base_controller/base_controller.dart';
import '../../../core/language_and_localization/app_strings.dart';
import '../../../data/models/request_model.dart';
import '../../../data/repositories/appointment_repository.dart';
import '../../../global_widgets/shared/different_dialogs.dart';
import '../../../routes/app_route_names.dart';
import '../../../services/push_notification_service.dart';
import '../../../utils/constants/api_keys.dart';
import '../../../utils/constants/app_images.dart';
import '../../../utils/constants/booking_vars.dart';

class AppointmentBaseController extends BaseController {
  PushNotificationService pushNotificationService=PushNotificationService();

  final AppointmentRepository _appointmentRepository = AppointmentRepository();

  TextEditingController queryMerchantIdentifier = TextEditingController();

  makeBookingWithFileDio({bool applePay = false}) async {
    BookingVars.paymentFromInstantCons = false;

    Map<String, String> data = {
      ApiKeys.patientId: BookingVars.patient!.id,
      ApiKeys.doctorId:
          '${BookingVars.doctorId != 0 ? BookingVars.doctorId : 28}',
      ApiKeys.appointmentDate: BookingVars.appointmentDate,
      // 'service_id':'10',
      ApiKeys.serviceId: '${BookingVars.service.id}',
      if (BookingVars.service2.id != 0)
        ApiKeys.serviceId2: '${BookingVars.service2.id}',
      if (BookingVars.service3.id != 0)
        ApiKeys.serviceId3: '${BookingVars.service3.id}',
      ApiKeys.formType: BookingVars.serviceType,

      ApiKeys.location: BookingVars.location,
      //ApiKeys.consultancyType:BookingVars.consultancyType,
      ApiKeys.consultancyPrice: '${BookingVars.price}',
      ApiKeys.period: BookingVars.period.toLowerCase(),
      ApiKeys.hour: BookingVars.hour.toLowerCase().split(':')[0].trim(),
      ApiKeys.gender: BookingVars.doctorGender,
      ApiKeys.patientFollowers: BookingVars.patientFollowers,
      ApiKeys.patientComment: BookingVars.patientComment.text.toString(),
      //'payment_type':BookingVars.paymentType
      ApiKeys.paymentType: ApiKeys.payValue,
      'app_version': '1'
    };

    try {
      setBusy(true);
      DifferentDialog.showProgressDialog();
      var result = await _appointmentRepository.makeBookingWithFileDio(data);
      // buildSuccessSnackBar(msg: result);
      Get.back();

      var jsonData = (result);
      var msg = '';
      var success = jsonData[ApiKeys.responseSuccess] as int;

      if (success == 1) {
        //  msg = '${jsonData![ApiKeys.responseSuccess][ApiKeys.responseMessage]}';
        var id = '${jsonData![ApiKeys.responseData]['id']}';

        BookingVars.audioFile = null;
        BookingVars.attachFile = null;
        BookingVars.cameraFile = null;
        BookingVars.serviceCode = '';
        BookingVars.service2.id = 0;
        BookingVars.service3.id = 0;
        BookingVars.patientComment.clear();


        if (Platform.isIOS && applePay) {
          performtrxn(transType: 'applepay', orderId: id);
        } else {
          DifferentDialog.showPaymentLoading();

          performtrxn(orderId: id);
        }
      } else {
        msg = '${jsonData[ApiKeys.responseMessage]}';
        buildFailedSnackBar(msg: msg);
      }

      setBusy(false);
    } catch (er) {

      setBusy(false);
    }
  }

  requestCareGiver(Map<String, String> data) async {
    // try {
    DifferentDialog.showProgressDialog();
    var result = await _appointmentRepository.makeBookingWithFileDio(data);
    // buildSuccessSnackBar(msg: result);
    Get.back();

    var jsonData = (result);

    var msg = '';
    var success = jsonData[ApiKeys.responseSuccess] as int;

    if (success == 1) {
      msg = '${jsonData![ApiKeys.responseData][ApiKeys.responseMessage]}';

      BookingVars.audioFile = null;
      BookingVars.serviceCode = '';
      BookingVars.service2.id = 0;
      BookingVars.service3.id = 0;
      DifferentDialog.showRequestServiceSuccessDialog(
          msg: AppStrings.appointmentSendSuccess);
    } else {
      msg = '${jsonData[ApiKeys.responseMessage]}';
      buildFailedSnackBar(msg: AppStrings.errorMsg.tr);
    }

    // }
    // catch(_){
    // }
  }

  requestCancelAppointment(Map<String, String> data1) async {
    var data = {
      ApiKeys.patientId: BookingVars.patient!.id,
    };
    data.addAll(data1);

    // try {
    DifferentDialog.showProgressDialog();
    var result = await _appointmentRepository.requestCancelAppointment(data);
    // buildSuccessSnackBar(msg: result);
    Get.back();

    var jsonData = (result);

    var msg = '';
    var success = jsonData[ApiKeys.responseSuccess] as int;

    if (success == 1) {
      DifferentDialog.showRequestServiceSuccessDialog(
          msg: AppStrings.appointmentCancelRequestSuccess);
    } else {
      msg = '${jsonData[ApiKeys.responseMessage]}';
      buildFailedSnackBar(msg: msg);
    }

    // }
    // catch(_){
    // }
  }

  cancelAppointment(String appointmentId,
      {String route = AppRouteNames.home}) async {
    var data = {
      ApiKeys.appointmentType:
          BookingVars.paymentAppointmentType.toString().split('.')[1],
      ApiKeys.appointmentId: appointmentId,
      ApiKeys.paymentReference: '0'
    };

    //  DifferentDialog.showProgressDialog();
    await _appointmentRepository.setPaymentStatus(data);

    if (route == AppRouteNames.home) {
      Get.offAllNamed(AppRouteNames.home);
    } else {
      Get.toNamed(route);
    }
  }

  Future<void> performtrxn(
      {String transType = 'hosted',
      String orderId = '0',
      String redirectPage = AppRouteNames.receiptPage,
      String failRoute = AppRouteNames.invoicePage,
      RequestModel? requestModel}) async {
    var udf = 'https://glob-care.com/';

    queryMerchantIdentifier.text = "merchant.com.globcare.app";

    var lastResult = "";
    var act = '1';
    var carOper = '';
    var tokenTy = '1';
    if (transType == "hosted") {
      // on Apple Click call other method  check with if else
      lastResult = await Payment.makepaymentService(
          context: Get.context!,
          country: 'SA',
          action: act,
          currency: 'SAR',
          //   amt: '100.0',
          amt: BookingVars.price.toString(),
          customerEmail: 'info@glob-care.com',
          trackid: orderId,
          udf1: udf,
          // udf2: 'https://glob-care.com/',
          udf2: 'https://glob-care.com/test.html',
          udf3: Get.locale.toString(),
          udf4: '',
          udf5: '',
          cardToken: '',
          address: '',
          city: '',
          state: '',
          tokenizationType: tokenTy,
          zipCode: '',
          tokenOperation: carOper,
          onBack: () {
            DifferentDialog.showBackPaymentDialog(onYes: () {
              cancelAppointment(orderId);
            });
          },
          title: AppStrings.paymentDetails.tr,
          ar: Get.locale.toString() == 'ar',
          appBar: Transform(
            transform:
                Matrix4.rotationY(Get.locale.toString() == 'ar' ? math.pi : 0),
            alignment: Alignment.center,
            child: SvgPicture.asset(
              AppImages.back,
              // fit: BoxFit.fill,
              //    width: 50,height:80,
              // colorBlendMode: BlendMode.color,
            ),
          ));

      print('Result in Main is $lastResult');
    } else if (transType == "applepay") {
      print("In apple pay");
      lastResult = await Payment.makeapplepaypaymentService(
        context: Get.context!,
        country: 'SA',
        action: act,
        currency: 'SAR',
        //   amt: '100.0',
        amt: BookingVars.price.toString(),
        customerEmail: 'info@glob-care.com',
        trackid: orderId,
        udf1: udf,
        // udf2: 'https://glob-care.com/',
        udf2: 'https://glob-care.com/test.html',
        udf3: Get.locale.toString(),
        udf4: '',
        udf5: '',
        tokenizationType: tokenTy,
        merchantIdentifier: queryMerchantIdentifier.text,
        shippingCharge: '0.0',
        companyName: 'globcare',
      );
      print('Result on Apple Pay in Main is $lastResult');
    }

// if (xyz != null )
//    {h
//      lastResult=xyz;
    Map<String, dynamic> decodedJSON;
    var decodeSucceeded = false;
    try {
      decodedJSON = json.decode(lastResult) as Map<String, dynamic>;
      decodeSucceeded = true;
    } on FormatException catch (e) {
      print('${e.message.toString()} The provided string is not valid JSON');
    }
    if (decodeSucceeded) {
      var responseData = json.decode(lastResult);
      print('RESP $responseData');
      var trnsId = responseData["TranId"] as String;
      var respCode = responseData["ResponseCode"] as String;
      if(BookingVars.paymentFromInstantCons&&respCode=='000'){
        if(requestModel!=null) {
          pushNotificationService.sendPushMessage(title: 'Consultation is ready',body: '${requestModel.patient} is wait you to start meeting',token:requestModel.doctorToken,isIos: requestModel.doctorDeviceType=='ios' );
        }

      }





      // var result = responseData["result"] as String;
      // var amount = responseData["amount"] as String;
      // var cardToken = responseData["cardToken"] as String;
      // var cardBrand = responseData["cardBrand"] as String;
      // var maskedPanNo = responseData["maskedPanNo"] as String;

//     String trnsid=responseData.TranId;

      if(respCode !='000'){

        cancelAppointment(orderId);
      }

      else {
        var data = {
          'transId': trnsId,
          'respCode': respCode,
          'orderId': orderId,
          'failRoute': failRoute
        };
        Get.toNamed(redirectPage, arguments: data);
      }
      // Navigator.of(context).push(MaterialPageRoute(builder: (context) => ReceiptPage(trnsid,result,amount,cardToken,respCode)));
    } else {
      if (lastResult.isNotEmpty) {
        print('Show');
      } else {
        print('Show Blank Data');
        cancelAppointment(orderId);

      }
    }
    print('Payment $lastResult');
  }

  String getRandString(int len) {
    var random = Random.secure();
    var values = random.nextInt(10000000);
    // return base64UrlEncode(values);
    return values.toString();
  }
}
