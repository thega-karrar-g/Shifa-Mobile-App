import 'package:flutter/material.dart';

class DetailsItemCard extends StatelessWidget {
  const DetailsItemCard({this.title, this.desc, Key? key}) : super(key: key);

  final String? title, desc;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 5, vertical: 10),
        child: Column(
          children: [
            Text(
              '$title',
              style: Theme.of(context).textTheme.bodyText1,
            ),
            Text(
              '$desc',
              style: Theme.of(context).textTheme.bodyText2,
            ),
          ],
        ),
      ),
    );
  }
}
