import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_multi_formatter/flutter_multi_formatter.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/payment_method.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/enums.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'payment_methods_details_logic.dart';

class PaymentMethodDetailsPage extends StatelessWidget {
  final logic = Get.find<PaymentMethodDetailsLogic>();

  var paymentMethod=Get.arguments as PaymentMethod;

  PaymentMethodDetailsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: Column(
      children: [

        myAppBar2(title: AppStrings.cardDetails),

        Expanded(
          child: SingleChildScrollView(child: Wrap(children: [








            Stack(
              children: [
                Container(height: Get.height*.3,

                  padding: EdgeInsets.all(20),

                  decoration: BoxDecoration(

                      borderRadius: BorderRadius.circular(10),

                      color: AppColors.primaryColor



                  ),



                  child: Row(children: [

                    Expanded(child: Column(

                      children: [

                        Row(children: [



                          Expanded(child: Text('${PatientDataLogic.price} ${AppStrings.currency.tr}',style: AppStyles.whiteStyle(bold: true,size: 25),)),



                          // SvgPicture.asset(paymentMethod.logo),
                          ConstrainedBox(
                              constraints: BoxConstraints(
                                  maxHeight: 60,
                                  maxWidth: 60
                              ),
                              child: CircleAvatar(
                                  radius: 25,
                                  backgroundColor: AppColors.white,
                                  child: Padding(
                                    padding:  EdgeInsets.all( paymentMethod.logo==AppImages.mada?5: 1.0),
                                    child: SvgPicture.asset(paymentMethod.logo,width: 50,height: 50,),
                                  ))),






                        ],)
                        ,
                        Container(height: 20,),

                        Row(
                          children: [
                            Expanded(child: Text(logic.currentUser!.name,style: AppStyles.whiteStyle(size: 20),)),
                          ],
                        ),

                        Container(height: 20,),

                        Row(
                          children: [
                            Expanded(child: Text(AppStrings.cardNumber.tr,style: AppStyles.whiteStyle(size: 16),)),
                          ],
                        ),
                        Container(height: 5,),

                        Row(
                          children: [
                            Expanded(child: Text('****  ****  ****  ****',style: AppStyles.whiteStyle(size: 25),)),
                          ],
                        ),




                      ],

                    ))



                  ],),



                ),
                Positioned.fill(child: Align(
                    alignment: Alignment.bottomRight, child: SvgPicture.asset(AppImages.paymentPath,
                )))
              ],
            ),

            Container(height: 20,),


            textItem(AppStrings.cardNumber, '0000-1111-2222-3333', Icons.credit_card,cardType: CardType.card,),

            textItem(AppStrings.expDate, '01 \\ 22', FontAwesomeIcons.calendarAlt,maxLength: 5,cardType: CardType.date),

            textItem(AppStrings.cvv, '123', FontAwesomeIcons.eyeSlash,maxLength: 3,cardType: CardType.cvc),
            Container(height: 20,),


            Row(
              children: [
                Expanded(
                    child:
                    GestureDetector(
                        onTap: (){
                          Get.back();
                        },
                        child: Text(AppStrings.cancel.tr,style: AppStyles.subTitleStyle(size: 20,bold: true),))

                ),
                SizedBox(width: 20,),
                Expanded(
                  child: Ui.primaryButton(title: AppStrings.confirm.tr,color: AppColors.primaryColorGreen,marginH: 0,marginV: 10,onTab: (){
                    //   Get.toNamed(AppRouteNames.termsOfService);
                    logic.makeBooking();

                    //   Get.back();

                  }),
                ),
              ],
            )
            ,




            Container(height: 40,),





          ],),),
        ),
      ],
    ));
  }

  textItem(String title,String hint,IconData iconData,{maxLength=19, CardType cardType=CardType.card,TextEditingController? textEditingController}){

    return             Container(

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.subTitleColor,width: 2)
      ),

      margin: EdgeInsets.symmetric(vertical: 7,),
      padding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
      child: Column(
        children: [

          TextFormField(
            onChanged: (txt){

              if(cardType==CardType.card){
                logic.setCardNumber(txt);
              }

              else if(cardType==CardType.cvc){
                logic.setCvc(txt);
              }
              else if(cardType==CardType.date){
                logic.setExpDate(txt);
              }

            },



            decoration: InputDecoration(
                border: InputBorder.none,
                suffixIcon: Icon(iconData,color: AppColors.subTitleColor,size: 20,),
                hintText: title.tr,
              hintStyle: AppStyles.subTitleStyle(bold: true,size: 14),
            ),
            style: AppStyles.subTitleStyle(bold: true,size: 14),
            keyboardType: TextInputType.number,
            inputFormatters: [
              LengthLimitingTextInputFormatter(maxLength),

              FilteringTextInputFormatter.digitsOnly,
              if(cardType==CardType.card)
              // CreditCardNumberInputFormatter()
                MaskedInputFormatter(
                  "####-####-####-####",
                  allowedCharMatcher: RegExp(r'[0-9]+'),


                )
              else  if(cardType==CardType.date)
                CreditCardExpirationDateFormatter()
              else
                CreditCardCvcInputFormatter()



            ],

          ),
        ],
      ),
    );

  }


}
