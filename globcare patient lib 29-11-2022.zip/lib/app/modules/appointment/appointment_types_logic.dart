import 'package:get/get.dart';

import '../../base_controller/base_controller.dart';
import '../../core/language_and_localization/app_strings.dart';
import '../../data/models/count.dart';
import '../../data/models/home_service.dart';
import '../../data/models/user_model.dart';
import '../../data/repositories/appointment_repository.dart';
import '../../data/repositories/profile_repository.dart';
import '../../utils/constants/app_images.dart';
import 'appointment_controller.dart';

class AppointmentTypesLogic extends BaseController {
  final AppointmentRepository _appointmentRepository = AppointmentRepository();

  var count = Count();

  List<HomeService> appointmentTypes = [];

  final ProfileRepository _profileRepository = ProfileRepository();
  List<AppUser> members = [];

  AppUser? selectedPatient;

  fetch() async {
    members.clear();
    members.add(currentUser!);
    setBusy(true);
    var list = await _profileRepository.getMemberList();
    members.addAll(list);
    setBusy(false);
    update();
  }

  updateSelectedPatient(AppUser user) {
    selectedPatient = user;
    AppointmentController.user = selectedPatient;
    getCount();
    update();
  }

  selectPatientClick() {
    if (selectedPatient != null) {
      //  Get.toNamed(AppRouteNames.instantConsultation,);

    } else {
      buildFailedSnackBar(msg: AppStrings.selectPatientMsg.tr);
    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();

    if(currentUser !=null) {
      fetch();
      updateSelectedPatient(currentUser!);
      getCount();
    }

  }

  getCount() async {
    // AppointmentController.patientId=selectedPatient!.id;
    AppointmentController.user = selectedPatient;

    setBusy(true);
    count = await _appointmentRepository.getAppointmentTypesCount(
        patientId: selectedPatient!.id);

    appointmentTypes.clear();

    if (count.tele > 0) {
      appointmentTypes.add(
        HomeService(
            id: 1,
            name: AppStrings.telemedicineAppointments,
            description: AppStrings.telemedicineAppointments,
            icon: AppImages.iconTeleMed,
            code: 'tele'),
      );
    }

    if (count.phys > 0) {
      appointmentTypes.add(HomeService(
          id: 1,
          name: AppStrings.physiotherapistAppointments,
          description: AppStrings.physiotherapistAppointments,
          icon: AppImages.iconPhys,
          code: 'phy'));
    }

    if (count.hhc > 0) {
      appointmentTypes.add(
        HomeService(
            id: 1,
            name: AppStrings.nurseAppointments,
            description: AppStrings.nurseAppointments,
            icon: AppImages.iconNurse,
            code: 'hhc'),
      );
    }

    if (count.pcr > 0) {
      appointmentTypes.add(
        HomeService(
            id: 1,
            name: AppStrings.pcrAppointments,
            description: AppStrings.pcrAppointments,
            icon: AppImages.iconPcr,
            code: 'pcr'),
      );
    }

    if (count.hvd > 0) {
      appointmentTypes.add(HomeService(
          id: 1,
          name: AppStrings.homeVisitAppointments,
          description: AppStrings.homeVisitAppointments,
          icon: AppImages.iconHVD,
          code: 'hvd'));
    }
    setBusy(false);
  }
}
