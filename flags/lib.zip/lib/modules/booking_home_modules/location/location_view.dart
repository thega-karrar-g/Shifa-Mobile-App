

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/drawer_module/drawer_widget/main_drawer_widget.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'location_logic.dart';

class LocationPage extends StatelessWidget {
  final LocationLogic logic = Get.put(LocationLogic());

  LocationPage({Key? key}) : super(key: key);

 

  @override
  Widget build(BuildContext context) {
    return GetBuilder<LocationLogic>(builder: (logic) {
      return Scaffold(
        drawer: MainDrawerWidget(),
        endDrawerEnableOpenDragGesture: false,
        drawerEnableOpenDragGesture: false,
        body: SafeArea(
          // minimum: UiHelper.safeAreaPadding,
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.only(left: 30, right: 30),
                child: Column(
                  children: [
                    myAppBar2(title: AppStrings.selectLocation.tr),



                    Row(
                      children: [
                        Expanded(
                          child: Container(
                              decoration: BoxDecoration(
                                  color: AppColors.primaryColorOpacity,
                                  borderRadius: BorderRadius.circular(10)),
                              padding: const EdgeInsets.symmetric(
                                  vertical: 15, horizontal: 20),
                              child: TextFormField(
                                controller: LocationLogic.addressController,
                                textAlign: TextAlign.start,
                                style: AppStyles.primaryStyle(),
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  disabledBorder: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  errorBorder: InputBorder.none,
                                  focusedErrorBorder: InputBorder.none,
                                ),
                              )

                              //  Text(LocationLogic.addressController.text,textAlign: TextAlign.start,style: AppStyles.primaryStyle(),),
                              ),
                        ),
                      ],
                    ),
                    UiHelper.verticalSpaceMedium,
                  ],
                ),
              ),


              Expanded(
                child:!logic.busy ? Container(
                  constraints: BoxConstraints(minHeight: 100,minWidth: 100),
                  child: GoogleMap(
                    mapType: MapType.normal,
                    initialCameraPosition: logic.kGooglePlex,
                    markers: Set<Marker>.of(logic.markers.values),
                    onMapCreated: (GoogleMapController controller) {
                     // logic.mapController=controller;
                      logic.updateMapController(controller);
                      logic.controller.complete(controller);
                    },

                    onTap: (latLang) {
                      logic.getAddress(latLang);
                    },
                    buildingsEnabled: true,
                    indoorViewEnabled: true,
                    trafficEnabled: true,
                    compassEnabled: true,
                    onCameraMove: (position) {},
                    myLocationEnabled: true,
                  ),
                ):Container()
              ),
            ],
          ),
        ),
        floatingActionButton: Container(
            padding: EdgeInsets.symmetric(horizontal: 50),
            child: Ui.primaryButton(
                title: AppStrings.continueTo.tr,
                marginH: 20,
                color: LocationLogic.addressController.text.isNotEmpty
                    ? AppColors.primaryColor
                    : AppColors.extraGrey,
                onTab: () {
                  logic.navToNext();
                })),
      );
    });
  }
}
