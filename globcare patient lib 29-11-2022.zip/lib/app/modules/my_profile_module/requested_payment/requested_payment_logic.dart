import 'dart:io';

import 'package:get/get.dart';
import '../../../base_controller/base_controller.dart';
import '../../../data/models/requested_payment.dart';
import '../../../data/repositories/payment_repository.dart';
import '../../../global_widgets/shared/different_dialogs.dart';
import '../../../routes/app_route_names.dart';
import '../../../utils/constants/booking_vars.dart';
import '../../booking_home_modules/appointment_base_controllers/appointment_base_controller.dart';

class RequestedPaymentLogic extends BaseController {
  final PaymentRepository _paymentRepository = PaymentRepository();

  List<RequestdPayment> requests = [];

  static String details = '';
  static int requestId = 1;

  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
    getData();
  }

  getData() async {
    setBusy(true);
    requests = (await _paymentRepository.getRequestedPaymentList())
        .where((element) => element.state.toLowerCase() != 'reject')
        .toList();
    update();
    setBusy(false);
  }

  openPayment({bool applePay = false}) async {
    DifferentDialog.showPaymentLoading();

     await AppointmentBaseController().performtrxn(
        orderId: '$requestId',
        failRoute: AppRouteNames.requestedPaymentDetails,
        transType: Platform.isIOS && applePay ? 'applepay' : 'hosted');
  }

  Future<dynamic> setRequestedPaymentStatus(
      {String paymentReference = '', bool showDialog = false}) async {
    BookingVars.paymentFromInstantCons = false;

    if (showDialog) {
      DifferentDialog.showProgressDialog();
    }

   var result=  await _paymentRepository.setRequestedPaymentStatus(body: {
      'payment_id': '$requestId',
      'payment_reference': paymentReference,
      'consultancy_price': paymentReference.isNotEmpty? BookingVars.price.toString():'0',

    });

    print(result);
    if (showDialog) {
      Get.back();
    }
  }
}
