import 'package:get/get.dart';

import 'choose_date_logic.dart';

class ChooseDateBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ChooseDateLogic());
  }
}
