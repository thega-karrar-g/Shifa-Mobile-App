import 'package:dio/dio.dart';
import 'package:sehati_app/utils/constants/app_urls.dart';
import 'base_api.dart';
import 'package:http/http.dart' as http;

class PrescriptionApi  extends BaseApi{

  static final _prescriptionApi = PrescriptionApi._internal();
  factory PrescriptionApi() {
    return _prescriptionApi;

  }

  PrescriptionApi._internal();

  var prescriptions=AppUrls.getUrl(AppUrls.prescriptions,withExtension: true);


    Future<Response?> getPrescriptions() async {
      try {
        var response = await api.dioGet(prescriptions);

        return response;
      } catch (e) {
        return null;

        //
      }
    }
    Future<http. Response?> getPrescriptionsHttp() async {
      try {
        var response = await api.httpGet(prescriptions);

        return response;
      } catch (e) {
        return null;

        //
      }
    }



  }