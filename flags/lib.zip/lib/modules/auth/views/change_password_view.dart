import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/widgets/change_password_form.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';

import '../auth_controller.dart';

class ChangePasswordPage extends GetView<AuthController> {
  @override
  final controller = Get.put(AuthController());

  ChangePasswordPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child:
    SingleChildScrollView(
      physics: AlwaysScrollableScrollPhysics(),
      child: Stack(
        children: [
          Column(
            children: <Widget>[



              myAppBar2(title: AppStrings.changePassword),

              SizedBox(height: 30),

              ChangePasswordForm(
                controller: controller,
              ),



            ],
          ),
          // Positioned(
          //
          //     top: 50,
          //     left: 10,
          //     //   right: 20,
          //     child: GestureDetector(
          //         onTap: (){
          //           Get.back();
          //         },
          //         child: Icon(Icons.arrow_back_ios_outlined,color: AppColors.primaryColor,))),

        ],
      ),
    )    );
  }
}
