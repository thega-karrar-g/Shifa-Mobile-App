import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/modules/booking_home_modules/telemedicine/book_doctor/week_item.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'book_doctor_logic.dart';

class BookDoctorPage extends GetView<BookDoctorLogic> {
 // final logic = Get.find<BookDoctorLogic>();
  final doctor=Get.arguments as Doctor;
  bool ar=Get.locale.toString()=='ar';

  BookDoctorPage({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: SingleChildScrollView(
      child: Column(children: [

        myAppBar2(title: AppStrings.bookingDoctor),
        UiHelper.verticalSpaceMassive,


        Row(children: [
          Expanded(child: Text(AppStrings.doctorInfo.tr,style: AppStyles.primaryStyle(size: 16,bold: true),)),

        ],),
        UiHelper.verticalSpaceSmall,

        Container(
          height: 125,
          decoration: BoxDecoration(
          ),


          child: Stack(


            children: [
              Positioned.fill(
                  bottom: 20,
                  child: Align(
                      alignment:ar?Alignment.bottomRight: Alignment.bottomLeft,
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 20),
                        width: Get.width*.4,
                        height: 5,
                        decoration: BoxDecoration(
                            color: AppColors.primaryColor,
                            borderRadius: BorderRadius.circular(15)
                        ),
                      )
                  )),

              Row(
                children: [


                  Column(children: [

                    Expanded(child:

                    Container(
                      child:    Ui.circluarImgRadiusBase64(url: doctor.image,margin: 0,errorImg: AppImages.doctor,rTL: ar?0:20,rTR: ar?0:20,size: 0,h: 130,w: 100),

                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(ar?20: 0),
                          topLeft: Radius.circular(ar?0:20),
                          bottomRight: Radius.circular(20),
                          bottomLeft: Radius.circular(20),
                        ),
                        boxShadow: kElevationToShadow[1],
                      ),

                    ),



                    ),

                    SizedBox(height: 20,)



                  ],),
                  Expanded(
                    child: Column(children: [

                      Container(
                        margin: EdgeInsets.zero,
                        padding: EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                            color: AppColors.primaryColorOpacity,
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(ar?0:15),
                              bottomRight: Radius.circular(ar?0:15),


                              topLeft: Radius.circular(ar?15:0),
                              bottomLeft: Radius.circular(ar?15:0),

                            )
                        ),

                        child: Row(children: [

                          Expanded(child: Container(
                            height: 73,
                            padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
                            child: Column(

                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [

                                Row(
                                  children: [
                                    Expanded(child: Text(doctor.name!,maxLines: 2,overflow: TextOverflow.ellipsis,style: AppStyles.primaryStyle(bold: true,size: 14),)),
                                  ],
                                ),
                                UiHelper.verticalSpace(7),
                                Row(
                                  children: [
                                    Expanded(child: Text(doctor.speciality!,style: AppStyles.subTitleStyle(bold: true,size: 12),)),
                                  ],
                                ),

                              ],),
                          )),
                          UiHelper.horizontalSpace(15),

                          Container(
                            padding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
                            decoration: BoxDecoration(color: AppColors.primaryColorGreen,

                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(ar?0:10),
                                  bottomLeft: Radius.circular(ar?0:10),


                                  bottomRight: Radius.circular(ar?10:0),
                                  topRight: Radius.circular(ar?10:0),

                                )
                            ),
                            child: Text(doctor.price!+' '+AppStrings.currency.tr,style: AppStyles.whiteStyle(bold: true),),

                          )


                        ],),
                      ),
                      UiHelper.verticalSpace(20)

                    ],),
                  ),
                ],
              ),
            ],
          ),

        ),

        GetBuilder<BookDoctorLogic>(builder: (controller) {
          return Column(
            children: [
              Row(children: [
                Expanded(child: Column(
                  children: [
                    GestureDetector(

                        onTap: (){
                          controller.changeInfoIndex(0);

                        },
                        child: Row(
                          children: [
                            Expanded(child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 5),
                              child: Text(AppStrings.experience.tr,style:controller.infoIndex==0? AppStyles.primaryStyle(size: 16,bold: true):AppStyles.subTitleStyle(size: 14,bold: true),),
                            )),
                          ],
                        )),
                    Visibility(
                      visible: controller.infoIndex==0,
                      child: Container(
                        margin: EdgeInsets.only(top: 5),
                        height: 5,
                        width: Get.width*.3,
                        decoration: BoxDecoration(color: AppColors.primaryColorGreen,
                          borderRadius: BorderRadius.circular(20),

                        ),
                      ),
                    )

                  ],
                )),
                Expanded(child: Column(
                  children: [
                    GestureDetector(

                        onTap: (){
                          controller.changeInfoIndex(1);

                        },
                        child: Row(
                          children: [
                            Expanded(child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 5),
                              child: Text(AppStrings.moreDetails.tr,style:controller.infoIndex==1? AppStyles.primaryStyle(size: 16,bold: true):AppStyles.subTitleStyle(size: 14,bold: true),),
                            )),
                          ],
                        )),
                    Visibility(
                      visible: controller.infoIndex==1,
                      child: Container(
                        margin: EdgeInsets.only(top: 5),

                        height: 5,
                        width: Get.width*.3,
                        decoration: BoxDecoration(color: AppColors.primaryColorGreen,
                          borderRadius: BorderRadius.circular(20),

                        ),
                      ),
                    )

                  ],
                )),


                Container(
                  padding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
                  decoration: BoxDecoration(color: AppColors.primaryColorGreen,

                      borderRadius: BorderRadius.circular(10)
                  ),
                  child: Text(doctor.price!+'.00  '+AppStrings.currency.tr,style: AppStyles.whiteStyle(bold: true),),

                )


              ],),

              UiHelper.verticalSpaceMedium,

              Visibility(
                visible: controller.infoIndex==0,
                child: Row(children: [

                  Row(children: [
                    Text(' 4 ' ,style: TextStyle(color: AppColors.primaryColorGreen,fontSize: 20,fontWeight: FontWeight.bold),),
                    Text('Years' ,style: AppStyles.subTitleStyle(size: 20,bold: true),),

                  ],),
                  Container(),

                ],),
              ),
              Visibility(
                visible: controller.infoIndex==1,
                child: Row(children: [

                  Row(children: [
                    Text(' Best Dcotor  ' ,style: AppStyles.subTitleStyle(size: 16,bold: true),),

                  ],),
                  Container(),

                ],),
              ),
              UiHelper.verticalSpaceLarge,

              Container(
                color: AppColors.white,

                child: Column(children: [
                  UiHelper.verticalSpaceMedium,

                  Row(children: [
                    Text(DateFormat('MMMM').format(controller.selectedDay),style: AppStyles.primaryStyle(bold: true,size: 18),),

                    UiHelper.horizontalSpaceSmall,
                    Text(DateFormat('yyyy').format(controller.selectedDay),style: AppStyles.subTitleStyle(bold: true,size: 15),),
                  ],),

                  UiHelper.verticalSpaceMedium,

                  SizedBox(
                    height: 100,
                    child: ListView.builder(
                      itemCount: controller.weekDays.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (bc,index)=>WeekItem(weekName: DateFormat('EE').format(controller.weekDays[index],)
                        ,
                        weekNo:'${controller.weekDays[index].day}' ,

                        onTab: (){
                          controller.changeDay(controller.weekDays[index]);
                        },
                        selected:controller.weekDays[index]==controller.selectedDay ,
                      ),

                    ),
                  ),
                  UiHelper.verticalSpaceMedium,

                  SizedBox(
                    height: 30,
                    child:   ListView.builder( scrollDirection: Axis.horizontal,itemCount: controller.doctorSlots.length, itemBuilder: (bc,index)=>
                        GestureDetector(
                          onTap: (){

                            controller.updateAppointmentDate(controller.doctorSlots[index]);
                          },
                          child: Container(
                            margin: EdgeInsets.symmetric(horizontal: 10),
                            padding: EdgeInsets.symmetric(horizontal: 15,vertical: 5),

                            decoration: BoxDecoration(

                                borderRadius: BorderRadius.circular(10),
                                color: controller.checkTime(controller.doctorSlots[index])==controller.selectedTime?AppColors.primaryColor:AppColors.white,
                                border: Border.all(color: AppColors.primaryColor)

                            ),

                            child: Text(controller.doctorSlots[index],style:
                            controller.checkTime(controller.doctorSlots[index])==controller.selectedTime?  AppStyles.whiteStyle(bold: true) :     AppStyles.subTitleStyle(bold: true),

                            ),

                          ),
                        )),
                  ),



                ],),

              ),




            ],
          );
        })
        ,              UiHelper.verticalSpaceMassive,

        Ui.primaryButton(title: AppStrings.bookNow,radius: 20,marginH: 0,onTab: (){

          controller.navToPatientData();
        },color: AppColors.primaryColorGreen)


      ],),
    ));
  }



}
