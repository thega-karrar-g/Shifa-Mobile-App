import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/shared_in_ui/shared/drawer_link_widget.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/launcher.dart';
import 'package:showcaseview/showcaseview.dart';

import '../controllers/account_controller.dart';

class AccountView extends GetView<AccountController> {
  @override
  final controller = Get.put(AccountController());

  AccountView({Key? key}) : super(key: key);
  final GlobalKey one = GlobalKey();

  @override
  Widget build(BuildContext context) {




    return Scaffold(
      body: ShowCaseWidget(

        builder: Builder(builder: (context) {
          // if(controller.introBox!.get('about')==null){
          //   WidgetsBinding.instance!.addPostFrameCallback((_) =>
          //       ShowCaseWidget.of(context)!
          //           .startShowCase([one]));
         // }
          return  Stack(
            children: [
              Column(children: [

                Stack(
                  children: [

                    Get.locale.toString()=='ar'?
                    Positioned.fill(
                        top: -20,
                        right:-Get.width/3 ,
                        child: Align(
                            alignment: Alignment.topRight,
                            child: SvgPicture.asset(AppImages.appBarBg,))):
                    Positioned.fill(
                        top: -20,
                        left:-Get.width/3 ,
                        //  left:-10 ,
                        child: Align(
                            alignment: Alignment.topLeft,
                            child: RotationTransition(
                                turns:  AlwaysStoppedAnimation(20 / 360),

                                child: SvgPicture.asset(AppImages.appBarBg,)))),

                    SizedBox(
                      height: 230,
                      width: Get.width,
                      child: Column(children: [
                        SizedBox(height: 50,),

                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 50),
                              child: Showcase(
                                description: AppStrings.aboutMsg.tr,
                                descTextStyle:Ui. labelStyle,
                                radius: BorderRadius.circular(30),
                                overlayPadding: EdgeInsets.all(15),
                                key: one,
                                contentPadding: EdgeInsets.symmetric(horizontal: 30,vertical: 30),
                                child: GestureDetector(
                                  onTap: ()async{
                                    await Launcher.launchInBrowser(
                                        AppStrings.appWebUrl);
                                  },
                                  child: Column(
                                    children: [
                                      Image.asset(AppImages.logoPng,width: 80,height: 80,),
                                      Text(AppStrings.appTitle.tr,style: Get.textTheme.headline6,),
                                      SizedBox(height: 8,),

//                                      Text(AppStrings.appLogoName.tr,style: TextStyle(fontSize: 10,color: AppColors.primaryColor),)
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )

                      ],),
                    )
                    //homeAppBar(),
                  ],
                ),


                SizedBox(height: 20,),

                Expanded(
                  child: ListView(
                    children: [
                      ListTile(
                        //  dense: true,
                        title: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 5, vertical: 5),
                          child: Text(
                            AppStrings.pages.tr,
                            style: Get.textTheme.caption!.merge(
                                TextStyle(color: Get.theme.hintColor)),
                          ),
                        ),
                      ),

                      DrawerLinkWidget(
                        icon: AppImages.pPerson,
                        text: AppStrings.profile.tr,
                        subtitle: 'PROFILE_HINT'.tr,
                        onTap: () {
                          // Get.back();
                          Get.toNamed(AppRouteNames.profile);
                          //   Get.toNamed(Routes.PROFILE, arguments: authService.user.value);

                          //  Get.find<RootController>().changePage(1);
                        },
                      ),
                      // DrawerLinkWidget(
                      //   icon: AppImages.logout,
                      //   text: AppStrings.register.tr,
                      //   subtitle: 'LOGOUT_HINT'.tr,
                      //   onTap: () {
                      //     Get.toNamed(AppRouteNames.register);
                      //     // authService.signUserOut();
                      //   },
                      // ),
                      // DrawerLinkWidget(
                      //   icon: AppImages.pWalking,
                      //   text: AppStrings.stepController.tr,
                      //   subtitle: 'LOGOUT_HINT'.tr,
                      //   onTap: () {
                      //     Get.to(StepCounterPage());
                      //     // Get.offAndToNamed(Routes.LOGIN);
                      //     // authService.signUserOut();
                      //   },
                      // ),
                      DrawerLinkWidget(
                        icon: AppImages.pDefendFamily,
                        text: AppStrings.familyMember.tr,
                        subtitle: 'LOGOUT_HINT'.tr,
                        onTap: () {
                          Get.toNamed(AppRouteNames.myFamilyMembersPage);
                        },
                      ),
                      DrawerLinkWidget(
                        icon: AppImages.pEmergencyCall,
                        text: AppStrings.myEmergencyContacts.tr.capitalizeFirst!,
                        subtitle: 'LOGOUT_HINT'.tr,
                        onTap: (){
                          Get.toNamed(AppRouteNames.emergencyContactListView);

                        },
                      ),
                      // ListTile(
                      //   //   dense: true,
                      //   title: Text(
                      //     AppStrings.applicationPreferences.tr.capitalizeFirst!,
                      //     style: Get.textTheme.caption!.merge(
                      //         TextStyle(color: Get.theme.hintColor)),
                      //   ),
                      // ),
                      DrawerLinkWidget(
                        icon: AppImages.pGeography,
                        text: AppStrings.language,
                        subtitle: AppStrings.langHint.tr,
                        onTap: () {
                          Get.toNamed(AppRouteNames.language);
                        },
                      ),
                      // DrawerLinkWidget(
                      //   icon:AppImages.p_moon,
                      //   text: AppStrings.themeMode,
                      //   subtitle: 'THEME_HINT'.tr,
                      //   onTap: () {
                      //     Get.offAndToNamed(AppRouteNames.themeMode);
                      //   },
                      // ),



                      // ListTile(
                      //   dense: true,
                      //   title: Text(
                      //     AppStrings.helpAndPrivacy.tr,
                      //     style: Get.textTheme.caption!.merge(
                      //         TextStyle(color: Get.theme.hintColor)),
                      //   ),
                      //   // trailing: Icon(
                      //   //   Icons.remove,
                      //   //   color: Get.theme.hintColor.withOpacity(0.3),
                      //   // ),
                      // ),
                      DrawerLinkWidget(
                        icon: AppImages.pQuestionMark,
                        text: AppStrings.help,
                        subtitle: 'HELP_HINT'.tr,
                        onTap: ()async {
                          await Launcher.launchInBrowser(
                              AppStrings.appWebUrl);
                          //     Get.toNamed(AppRouteNames.register);
                          // Get.offAndToNamed(Routes.HELP);
                          //  Launcher.launchInBrowser(AppStrings.APP_WEB_URL);
                        },
                      ),
                      DrawerLinkWidget(
                        icon: AppImages.privacy,
                        text: AppStrings.privacyPolicy.tr,
                        subtitle: 'PRIVACY_HINT'.tr,
                        onTap: () async{
                          await Launcher.launchInBrowser(
                              AppStrings.appWebUrl);
                          //  Get.to(StepCounterPage());
                          // Get.offAndToNamed(Routes.PRIVACY);
                          //  Launcher.launchInBrowser(AppStrings.APP_WEB_URL);
                        },
                      ),
                      DrawerLinkWidget(
                        icon: AppImages.pExit,
                        text: AppStrings.logout.tr,
                        subtitle: 'LOGOUT_HINT'.tr,
                        onTap: controller.logUserOut,
                      ),
                    ],
                  ),
                ),


              ],),

              Get.locale.toString()=='ar'?
              Positioned.fill(
                  top: -20,
                  left:-Get.width*.7 ,
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: SvgPicture.asset(AppImages.appBarBg,))):
              Positioned.fill(
                // top: -20,
                  right:-Get.width*.7 ,
                  //  left:-10 ,
                  child: Align(
                      alignment: Alignment.centerRight,
                      child: RotationTransition(
                          turns:  AlwaysStoppedAnimation(1 / 360),

                          child: SvgPicture.asset(AppImages.appBarBg,)))),


            ],
          );}
        ),
        autoPlay: false,
        autoPlayDelay: Duration(seconds: 3),
        autoPlayLockEnable: false,
        onStart: (index, key) {
          print('onStart: $index, $key');
        },
        onComplete: (index, key) {

          print('onComplete: $index, $key');
        },
        blurValue: 1,

      ),
    );
  }
}
