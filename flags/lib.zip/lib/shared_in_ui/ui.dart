import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:sehati_app/modules/drawer_module/drawer_widget/main_drawer_widget.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

class Ui {


  static  myScaffold({required Widget child,})=>Scaffold(
    drawer: MainDrawerWidget(),
  drawerEnableOpenDragGesture: false,
  endDrawerEnableOpenDragGesture: false,
drawerDragStartBehavior: DragStartBehavior.start,
  body: SafeArea(
      minimum: UiHelper.safeAreaPadding,
      child: child),

  );

  static  OutlineInputBorder outlineInputBorder =OutlineInputBorder(
    borderRadius: BorderRadius.all(
        Radius.circular(20)),
    borderSide: BorderSide(
        color:
        AppColors.primaryColorOpacity)
    ,
  );


  static BoxDecoration getBoxDecorationLogin({Color color = Colors.white, double radius = 15, Border? border, Gradient? gradient}) {
    return BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: AppColors.subTitleColor,width: 1.5)
    );
  }
  static BoxDecoration getBoxDecorationPrescription({Color color = Colors.white, double radius = 10, Border? border, Gradient? gradient}) {
    return BoxDecoration(
        borderRadius: BorderRadius.circular(radius),

        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors:const[
            AppColors.gradientStartPre,
            AppColors.gradientEndPre,
          ]
          ,

        )
    );
  }



  static BoxDecoration getBoxDecorationTextForm({Color color = Colors.white, double radius = 10, Border? border, Gradient? gradient}) {
    return BoxDecoration(
        borderRadius: BorderRadius.circular(radius),

        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors:const[
            AppColors.gradientStart,
            AppColors.gradientEnd,
          ]
          ,

        )
    );
  }





  static BoxDecoration getBoxDecoration({Color color = Colors.white, double radius = 10, Border? border, Gradient? gradient}) {
    return BoxDecoration(
      color: color,
      borderRadius: BorderRadius.all(
        Radius.circular(radius),
      ),
      boxShadow: [
        BoxShadow(
          color: Get.theme.splashColor.withOpacity(0.5),
          blurRadius: 10,
          offset: Offset(0, 5),
        ),
      ],
      border:
      border ?? Border.all(color: Get.theme.focusColor.withOpacity(0.05)),
      gradient: gradient,
    );
  }

  static BoxDecoration getBoxDecoration2(
      {Color? color, double? radius, Border? border, Gradient? gradient}) {
    return BoxDecoration(
      color: color ?? Get.theme.primaryColor,
      borderRadius: BorderRadius.all(Radius.circular(radius ?? 10)),
      boxShadow: [
        BoxShadow(
            color: Get.theme.splashColor.withOpacity(0.5),
            blurRadius: 10,
            offset: Offset(0, 5)),
      ],
    );
  }

  static BoxDecoration getBoxDecoration4(
      {Color? color, double? radius, Border? border, Gradient? gradient}) {
    return BoxDecoration(
      color: color ?? Get.theme.primaryColor,
      borderRadius: BorderRadius.all(Radius.circular(radius ?? 10)),
      boxShadow: [
        BoxShadow(
            color: Get.theme.splashColor.withOpacity(0.5),
            blurRadius: 15,
            offset: Offset(0, 5)),
      ],
    );
  }

  static BoxDecoration getBoxDecoration3(
      {Color? color, double? radius, Border? border, Gradient? gradient}) {
    return BoxDecoration(
      color: Get.theme.primaryColor,
      borderRadius: BorderRadius.all(Radius.circular(radius ?? 10)),
      boxShadow: [
        BoxShadow(
            color: Get.theme.focusColor.withOpacity(0.1),
            blurRadius: 5,
            offset: Offset(0, 5)),
      ],
    );
  }


  static svgIcon(String icon) {
    return SvgPicture.asset(
      icon,
      width: 15,
      height: 15,
      color: Get.isDarkMode ? AppColors.accentColor : Get.theme.hintColor,
    );
  }


  static circluarImg( {@required url, double size=60,errorImg=AppImages.placeHolder,double margin=10}){

    return Container(
      margin: EdgeInsets.all( margin),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(100),
        child: CachedNetworkImage(
            height: size,
            width: size,
            fit: BoxFit.fill,
            imageUrl: url ,
            placeholder: (context, url) => Image.asset(
              AppImages.loadingSlides,
              fit: BoxFit.cover,
              width: size,
              height: size,
            ),
            errorWidget: (context, url, error) =>Image.asset(
              errorImg,
              fit: BoxFit.cover,
              width: size,
              height: size,
            )
        ),
      ),
    );


  }
  static circluarImgRadius( {@required url, double size=60,errorImg=AppImages.placeHolder,double margin=10,double rTR=15,double rTL=15,double rBR=15,double rBL=15,double h=100,double w=100}){

    return Container(
      margin: EdgeInsets.all( margin),
      child: ClipRRect(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(rTR),
          topLeft: Radius.circular(rTL),
          bottomRight: Radius.circular(rBR),
          bottomLeft: Radius.circular(rBL),

        ),
        child: CachedNetworkImage(
            height: size==0?h:size,
            width: size==0?w:size,
            fit: BoxFit.fill,
            imageUrl: url ,
            placeholder: (context, url) => Image.asset(
              AppImages.loadingSlides,
              fit: BoxFit.cover,
              height: size==0?h:size,
              width: size==0?w:size,
            ),
            errorWidget: (context, url, error) =>Image.asset(
              errorImg,
              fit: BoxFit.cover,
              height: size==0?h:size,
              width: size==0?w:size,
            )
        ),
      ),
    );


  }
  static circluarImgRadiusBase64( { String? url='', double size=60,errorImg=AppImages.placeHolder,double margin=10,double rTR=15,double rTL=15,double rBR=15,double rBL=15,double h=100,double w=100}){

try{

if(url!.isNotEmpty) {
// You can check if data is normal base64 - should return true


// Will returns your image as Uint8List

var  _bytesImage = Base64Decoder().convert(base64.normalize(url));
//var  _bytesImage = Base64Decoder().convert(url);
//var image=base64.normalize(_bytesImage);

  return

    Container(
      margin: EdgeInsets.all(margin),
      child: ClipRRect(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(rTR),
          topLeft: Radius.circular(rTL),
          bottomRight: Radius.circular(rBR),
          bottomLeft: Radius.circular(rBL),

        ),
        child: Image.memory(_bytesImage,width: size==0?w:size,height: size==0?h:size,),

      ),
    );
}


    else {
 return circluarImg(url: errorImg, margin: margin);
}
    }catch(e){
  return   circluarImg(url: errorImg, margin: margin);

}


  }
 static Widget image(String thumbnail,{double size=60}) {
    String placeholder = "iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg==";
    if (thumbnail.isEmpty ) {
      thumbnail = placeholder;
    } else {
      if (thumbnail.length % 4 > 0) {
      //  thumbnail += '=' * (4 - thumbnail .length % 4) ;// as suggested by Albert221
      }
    }
    final _byteImage = Base64Decoder().convert(thumbnail);
    Widget image = Image.memory(_byteImage,width: size,height: size,);
    return image;
  }

static  titleGreenUnderLine(String title,{double bottomPadding=15,double fontSize=14,double fontHeight=1.3}){


    return
      IntrinsicWidth(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title.tr,style: AppStyles.primaryStyle(bold: true,size: fontSize,height: fontHeight),),
            Row(
              children: [
                Expanded(
                  child: Container(
                    margin: EdgeInsets.only(top: 5),
                    height: 5,
                    //  width: Get.width*.3,
                    decoration: BoxDecoration(color: AppColors.primaryColorGreen,borderRadius: BorderRadius.circular(20)),
                  ),
                ),
              ],
            ),
            SizedBox(height: bottomPadding,),


          ],
        ),
      );


  }


  static    Widget primaryButton( {String  title='',VoidCallback? onTab,double fontSize=18,bool  hasIcon=false,IconData? icon,double marginH=0,double marginV=20,double radius=10,Color color=AppColors.primaryColor}  ){

    return                 Container(
      margin: EdgeInsets.symmetric(vertical: marginV,horizontal: marginH),

      child: GestureDetector(
        onTap: ()=>onTab!(),
        child: Row(
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(vertical: marginV,horizontal: 20),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(radius),
                    color: color
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [



                    Text(
                      title.tr.capitalizeFirst!,
                      textAlign: TextAlign.center,

                      style: TextStyle(
                          color: AppColors.white,
                          fontWeight: FontWeight.bold,fontSize: fontSize
                      ),
                    ),
                    if(icon!=null)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 7),
                        child: Icon(icon,color: AppColors.white,size: 40,),
                      ),

                    if(hasIcon)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Icon(Icons.arrow_forward_outlined,color: AppColors.white,),
                      )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );

  }
  static    Widget primaryButton2( {String  title='',VoidCallback? onTab,bool  icon=false,double marginH=0,double marginV=0,double radius=10,Color color=AppColors.primaryColorGreen}  ){

    return                 Container(
      margin: EdgeInsets.symmetric(vertical: marginV,horizontal: marginH),

      child: GestureDetector(
        onTap: ()=>onTab!(),
        child: Row(
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 3,horizontal: 16),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(radius),
                    color: color
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if(icon)
                      Container(width: 40,),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.all(3.0),
                        child: Text(
                          title.tr.capitalize!,
                          textAlign: TextAlign.center,

                          style: TextStyle(
                              color: AppColors.white,
                              fontWeight: FontWeight.bold,fontSize: 15
                          ),
                        ),
                      ),
                    ),

                    if(icon)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Icon(Icons.arrow_forward_outlined,color: AppColors.white,),
                      )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );

  }


  static const vSpace10=                SizedBox(height: 10,);
  static const hSpace10=                SizedBox(width: 10,);

  static final labelStyle = TextStyle(
      color: AppColors.subTitleColor, fontWeight: FontWeight.bold, fontSize: 13,height: 1.5);



 static  expandedText({String txt='',TextStyle style= const TextStyle(color: AppColors.primaryColor,fontSize: 12)}){


    return Row(children: [Expanded(child: Text(txt,style: style,))],);

  }

  static  greenLine({double opacity=1.0}){
   return         Row(
     children: [
       Container(
         margin: EdgeInsets.symmetric(vertical: 10),
         height: 5,
         width: Get.width*.2,
         decoration: BoxDecoration(color: AppColors.primaryColorGreen.withOpacity(opacity),borderRadius: BorderRadius.circular(20)),
       ),
     ],
   );

  }
 static genderButton({String title='',bool selected=false,Function? onTab}){


    return  GestureDetector(

      onTap: (){
        if(onTab!=null){

          onTab();

        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15,horizontal: 15),
        decoration: BoxDecoration(
            color: selected?AppColors.primaryColor:AppColors.primaryColor.withOpacity(.03),
            borderRadius: BorderRadius.circular(10)
        ),
        child: Text(title.tr,style: selected?AppStyles.whiteStyle(bold: true,size: 13):AppStyles.primaryStyle(size: 13,opacity: .8),),

      ),
    );

  }


}
