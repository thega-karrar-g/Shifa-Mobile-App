import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/widgets/register_form.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';

import '../auth_controller.dart';

class RegisterPage extends GetView<AuthController> {
  @override
  final controller = Get.put(AuthController());

  RegisterPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(
                //color: AppColors.primaryColor

                // color: AppColors.extraGrey
                ),
            child: SizedBox(
              width: MediaQuery.of(context).size.width * (88),
              child: SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                child: Container(
                  margin: EdgeInsets.symmetric(vertical: 10),
                  padding: EdgeInsets.only(right: 27, left: 27),
                  child: Stack(
                    children: [
                      Column(
                        children: <Widget>[
myAppBar(title: AppStrings.createAccount.tr),



                          SizedBox(height: 30),

                          RegisterForm(
                            controller: controller,
                          ),

                          // GestureDetector(
                          //   onTap: () {
                          //     Get.offAllNamed(AppRouteNames.login);
                          //     //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                          //   },
                          //
                          //   child: Text(AppStrings.haveAccount.tr,style: Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.primaryColor)),),
                          // ),


                          SizedBox(
                              height: MediaQuery.of(context).size.height * 0.04),
                        ],
                      ),
                      // Positioned(
                      //
                      //     top: 50,
                      //     left: 10,
                      //     //   right: 20,
                      //     child: GestureDetector(
                      //         onTap: (){
                      //           Get.back();
                      //         },
                      //         child: Icon(Icons.arrow_back_ios_outlined,color: AppColors.primaryColor,))),

                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
