import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import '../../core/language_and_localization/app_strings.dart';
import '../../core/theme_helper/app_styles.dart';
import '../../global_widgets/shared/my_appbar.dart';
import '../../global_widgets/shared/ui_helpers.dart';
import '../../utils/constants/app_anim.dart';
import '../drawer_module/drawer_widget/main_drawer_widget.dart';
import 'notifications_logic.dart';

class NotificationsPage extends StatelessWidget {
  final logic = Get.find<NotificationsLogic>();

  NotificationsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MainDrawerWidget(),
      body: SafeArea(
        minimum: UiHelper.safeAreaPadding,
        child: Column(
          children: [
            myAppBar2(title: AppStrings.notifications),

            UiHelper.verticalSpaceLarge,
            Stack(
              children: [
                LottieBuilder.asset(
                  AppAnim.noNotification,
                  width: Get.width * .7,
                  height: Get.height * .5,
                ),
                // UiHelper.verticalSpaceLarge,
                Positioned.fill(
                  right: 20,
                  bottom: 0,
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: SizedBox(
                      height: 120,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Spacer(),
                          Text(
                            AppStrings.oops.tr,
                            style: AppStyles.primaryStyle(bold: true, size: 25),
                          ),
                          UiHelper.verticalSpaceSmall,
                          Text(
                            AppStrings.noNotifications.tr,
                            style:
                                AppStyles.primaryStyle(bold: false, size: 18),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),

            // Expanded(child: ListView.builder(
            //     itemCount: NotificationModel.notifications.length,
            //     itemBuilder: (bc,index)=>Dismissible(
            //         direction: DismissDirection.horizontal,
            //         onDismissed: (b){
            //
            //         },
            //         dragStartBehavior: DragStartBehavior.start,
            //         key: UniqueKey(),
            //         child: Notificationitem(notificationModel: NotificationModel.notifications[index],))))
          ],
        ),
      ),
    );
  }
}
