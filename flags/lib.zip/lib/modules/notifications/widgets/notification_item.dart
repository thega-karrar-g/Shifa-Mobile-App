import 'package:flutter/material.dart';
import 'package:sehati_app/models/notification_model.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
class Notificationitem extends StatelessWidget {
  const Notificationitem({Key? key,this.notificationModel}) : super(key: key);
final NotificationModel? notificationModel;
  @override
  Widget build(BuildContext context) {
    return Container(
margin: EdgeInsets.symmetric(vertical: 5),

      child: Column(children: [

IntrinsicHeight(
  child:   Row(



    children: [



  Column(children: [

    Ui.circluarImg(url: '',margin: 0),

  Spacer()

  ],),

      UiHelper.horizontalSpaceMedium,



  Expanded(

    child:   Column(

      children: [

        Text.rich(TextSpan(text: notificationModel!.name,

        style: AppStyles.primaryStyle(bold: true,size: 14),



        children: [

          TextSpan(text: '\t'),
          TextSpan(text: notificationModel!.description,style: AppStyles.subTitleStyle())

        ]

        ),



        ),

        UiHelper.verticalSpaceSmall

        ,



        Row(
          children: [
            Text(notificationModel!.date,style: AppStyles.subTitleStyle(bold: true),),
          ],
        )



      ],

    ),

  )





    ],



  ),
),

        UiHelper.verticalSpaceSmall,

        Divider(color:notificationModel!.readed?AppColors.subTitleColor: AppColors.primaryColorGreen,thickness: 2,)


      ],),
    );
  }
}
