import 'dart:convert';
import 'package:sehati_app/api/appointment_api.dart';
import 'package:sehati_app/models/m_appointment.dart';
import 'package:sehati_app/models/period.dart';
import 'package:sehati_app/models/schedule_model.dart';
import 'package:sehati_app/utils/constants/app_urls.dart';
import 'package:sehati_app/utils/group_by.dart';
class AppointmentRepository {
  static final _appointmentRepository = AppointmentRepository._internal();

  factory AppointmentRepository() {
    return _appointmentRepository;
  }

  AppointmentRepository._internal();

  final AppointmentApi _appointmentService = AppointmentApi();

  Future<List<Appointment>> getAppointmentList() async {
    try {
       var response= await _appointmentService. getAppointments1() ;
       var d=response!.data['data'];
      var dd = d.map((dr) {
        return Appointment.fromJson((dr));
      }).toList();

      return dd;
     } catch (_) {
     }

    return [];
  }
  Future<List<Period>> getPeriodList({String url=''}) async {
    try {
       var response= await _appointmentService. getPeriods(url: url) ;
       var data=json.decode(response!.body.toString());

       var d=data['data'] as List;
      // print(d);
      var dd = d.map((dr) {
        return Period.fromJson((dr));
      }).toList();

      return dd;
     } catch (_) {
     }

    return [];
  }

  Future<List<Appointment>> getAppointmentList1({String type='tele'}) async {

    var response = await _appointmentService.getAppointments(type: type);

    try {

      var jsonData=json.decode(response!.body.toString());
      var d = jsonData['data'] as List;

      var dd = d.map((dr) {
        return Appointment.fromJson((dr));
      }).toList();

      return dd;
    } catch (_) {
      return [];

    }

  }

  Future<dynamic> makeBookingWithFileDio( Map<String,String> data) async {


    var response = await _appointmentService.makeBookingWithFileDio(data);

    try {


      return response!.data;
    }
    catch(_){
      return response!.data;

    }
  }


  Future<dynamic> setPaymentStatus( Map<String,String> data) async {
    var response = await _appointmentService.setPaymentStatus(data);

    try {


      return response!.data;
    }
    catch(_){
      return response!.data;

    }
  }



  Future<String> makeBookingWithFile(data) async {
    var response = await _appointmentService.makeBookingWithFile(data);
    var msg = '';

    try {
      var jsonData = json.decode(response!.body.toString());


      print(jsonData.toString());
      var success = jsonData['success'] as int;

      if (success == 1) {
        msg = '${jsonData!['data']['message']}';
      } else {
        msg = '${jsonData['message']}';
      }

      return msg;
    }
    catch(_){
      return msg;

    }
  }




  Future<String> makeBooking({Map<String, dynamic>? data,String type=''}) async {
    var response = await _appointmentService.makeBooking(data: data,type:type);
    print(response!.body.toString());
    var msg = '';

    try {
      var jsonData = json.decode(response.body.toString());
      var success = jsonData['success'] as int;

      if (success == 1) {
        msg = '${jsonData!['data']['message']}';
      } else {
        msg = '${jsonData['message']}';
      }

      return msg;
    }
    catch(e){
      print(e.toString());
      return msg;

    }
  }

  Future<String> requestSleepMedicine(data) async {
    var response = await _appointmentService.requestSleepMedicine(data);

    var success = response!.data!['success'] as int;

    var msg = '';
    if (success == 1) {
      msg = '${response.data!['data']['message']}';
    } else {
      msg = msg = '${response.data!['message']}';
    }

    return msg;
  }



  Future<List<ScheduleModel>> getPCRPeriodList({String url=''}) async {
    try {
      var response= await _appointmentService. getPeriods(url: AppUrls.periodsPCR) ;
      var data=json.decode(response!.body.toString());

      var d=data['data'] as List;
      final releaseDateMap = d.groupByDate((m) => m['date']);




      List<ScheduleModel> sch=[];

      for (var element in releaseDateMap.keys) {
var t=releaseDateMap[element]!.map((e) => e['hour'].toString().replaceAll('.0', ':00')).toList();

        sch.add(ScheduleModel(date: DateTime.parse(element),times: t));

      }



      return sch;
    } catch (_) {
    }

    return [];
  }



  var d = [

  ];
}
