import 'package:sehati_app/base_controller/base_controller.dart';

class ResponsibilityLogic extends BaseController {

}
