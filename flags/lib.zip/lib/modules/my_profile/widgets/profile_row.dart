import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
class ProfileRow extends StatelessWidget {
  const ProfileRow({Key? key,this.title,required this.iconData}) : super(key: key);
final String? title;
final String iconData;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [

        SvgPicture.asset(iconData,color: AppColors.primaryColorGreen,width: 15,height: 15,),UiHelper.horizontalSpaceSmall,
        Expanded(child: Text(title!,style: AppStyles.primaryStyle(),))



      ],),
    );
  }
}
