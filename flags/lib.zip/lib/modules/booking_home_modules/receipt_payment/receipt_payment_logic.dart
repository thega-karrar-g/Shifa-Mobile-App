import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';

import '../../../repositories/appointment_repository.dart';
import '../patient_data/patient_data_logic.dart';

class ReceiptPaymentLogic extends BaseController {

  late final String transId,responseCode,appointmentId;
  late final String result;
  final String amount='';

  final String cardToken='';
  final String cardBrand='';
  final String maskedPan='';

  final AppointmentRepository _appointmentRepository=AppointmentRepository();

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    appointmentId=Get.arguments['orderId'];
    responseCode=Get.arguments['respCode'];
    transId=Get.arguments['transId'];


    print('*******************************  code  $responseCode');
    print('******************************* trans id  $transId');

    payment();
    _visibleTokenDetails();
  }

payment()async{

  print('*******************************   payment start');
  print('*******************************   type ${PatientDataLogic.paymentAppointmentType.toString().split('.')[1]}');


  var data={'appointment_type':PatientDataLogic.paymentAppointmentType.toString().split('.')[1],'appointment_id':appointmentId,'payment_reference':transId};

if(responseCode !='000')
  {
     data={'appointment_type':PatientDataLogic.paymentAppointmentType.toString().split('.')[1],'appointment_id':appointmentId,'payment_reference':'0'};

  }
  setBusy(true);

  //  DifferentDialog.showProgressDialog();
 var res= await _appointmentRepository.setPaymentStatus(data);

    print('*******************************  data $res');

 //    if(res['success']==1){
 //
 //   buildSuccessSnackBar(msg: res['msg']);
 // }
 //    else{
 //      buildFailedSnackBar(msg: res['msg']);
 //
 //    }

  setBusy(false);
  // Get.back();


}

  bool visibilityToken = false;

  void _visibleTokenDetails() {


      var tok=cardToken;
      if(  tok == "" || tok == "null")
      {
        visibilityToken=false;
      }
      else
      {
        print('Token else$tok');
        visibilityToken=true;
      }

update();
  }


}
