import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/models/m_file.dart';
import 'package:sehati_app/utils/ext_storage.dart';

class RadiologyLabFilesLogic extends BaseController {

  var dir= '';

var title=(Get.arguments as HomeService).name;

  GlobalKey key=GlobalKey();

  List<MyFile> files=[

    // MyFile(name: 'First lab test lab testlab testlab testlab test 100k .pdf',date: '2022-5-12',url: 'https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_100KB_PDF.pdf'),
    // MyFile(name: 'sample.pdf',date: '2022-5-12',url: 'https://fluttercampus.com/sample.pdf'),
    // MyFile(name: 'Third lab test 500k .pdf',date: '2022-5-12',url: 'https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_500KB_PDF.pdf',isExist: true),
    // MyFile(name: 'Fourth lab test 1MB .pdf',date: '2022-5-12',url: 'https://freetestdata.com/wp-content/uploads/2021/09/Free_Test_Data_1MB_PDF.pdf'),

  ];
  var granted=false;

  @override
  void onInit() async{
    // TODO: implement onInit
    super.onInit();



    if (await ExtStorage.checkGranted()) {
setGranted(true) ;

 dir= (await ExtStorage.getDir()).path;

   // Either the permission was already granted before or the user just granted it.

    }
    else{
    setGranted(false);
    }



  }


  setGranted(bool status){
    granted=status;
    update();
  }

}
