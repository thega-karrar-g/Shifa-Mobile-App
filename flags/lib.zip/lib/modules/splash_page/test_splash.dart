import 'package:flutter/material.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';

import '../../utils/constants/app_images.dart';
import '../../utils/helpers/theme_helper/app_colors.dart';
class TestSplash extends StatefulWidget {
  const TestSplash({Key? key}) : super(key: key);

  @override
  State<TestSplash> createState() => _TestSplashState();
}

class _TestSplashState extends State<TestSplash>  with SingleTickerProviderStateMixin{

  bool  show=false;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();


    Future.delayed(Duration(milliseconds: 2000),(){
      setState(() {
        show=true;
      });
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
    );
  }
}
