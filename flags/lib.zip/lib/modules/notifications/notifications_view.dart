import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/notification_model.dart';
import 'package:sehati_app/modules/drawer_module/drawer_widget/main_drawer_widget.dart';
import 'package:sehati_app/modules/notifications/widgets/notification_item.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';

import 'notifications_logic.dart';

class NotificationsPage extends StatelessWidget {
  final logic = Get.find<NotificationsLogic>();

   NotificationsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MainDrawerWidget(),
      body: SafeArea(
        minimum: UiHelper.safeAreaPadding,
        child: Column(
          children: [
myAppBar2(title: AppStrings.notifications),


            Expanded(child: ListView.builder(
                itemCount: NotificationModel.notifications.length,
                itemBuilder: (bc,index)=>Dismissible(
                    direction: DismissDirection.horizontal,
                    onDismissed: (b){

                    },
                    dragStartBehavior: DragStartBehavior.start,
                    key: UniqueKey(),
                    child: Notificationitem(notificationModel: NotificationModel.notifications[index],))))


          ],
        ),
      ),
    );
  }
}
