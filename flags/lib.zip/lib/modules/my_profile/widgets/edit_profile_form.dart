import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:persian_datepicker/persian_datepicker.dart';

import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/my_profile/my_profile_logic.dart';
import 'package:sehati_app/shared_in_ui/form_widgets/reactive_text_form.dart';
import 'package:get/get.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import '../../../utils/helpers/theme_helper/app_fonts.dart';

class EditProfileForm extends StatelessWidget {
  EditProfileForm({Key? key,}) : super(key: key);
  final controller = Get.put(MyProfileLogic());

final String fullNameKey='name';
final String emailKey='email';
final String ssnKey='ssn';

  final  double  paddingHeight=25.0;
  final labelStyle=TextStyle(color: AppColors.black54,fontWeight: FontWeight.bold,fontSize: 13);
  final OutlineInputBorder outlineInputBorder =OutlineInputBorder(
    borderRadius: BorderRadius.all(
        Radius.circular(25)),
    borderSide: BorderSide(
        color:
        AppColors.registerFiled)
    ,
  );
  FormGroup buildForm() => fb.group(<String, Object>{
        fullNameKey: FormControl<String>(
          value: controller.currentUser!.name,
          validators: [
            Validators.required,
          ],
        ),

       emailKey : FormControl<String>(
          value: controller.currentUser!.email,

          validators: [
            Validators.required,
          ],
        ),


        ssnKey: FormControl<String>(
          value: controller.currentUser!.ssn,

          validators: [Validators.required, Validators.number],
        ),
    // 'dob': FormControl<DateTime>(),



  });

  final TextStyle style =
      Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.white));

  @override
  Widget build(BuildContext context) {
//controller.resultLocation=controller.currentUser!.location;
    return

      GetBuilder<MyProfileLogic>(builder: (logic) {


      var d=logic.dob!;
      var max=DateTime.now();
      var duration =Duration(milliseconds: 200);
      logic.      persianDatePicker = PersianDatePicker(
        controller:logic. dobTextEditingController,
        showGregorianDays: true,
        locale: Get.locale.toString(),

        currentDayBackgroundColor: AppColors.primaryColorOpacity,
        selectedDayBackgroundColor: AppColors.primaryColor,
        selectedDayTextStyle: AppStyles.whiteStyle(bold: true),
        headerTodayTextStyle: AppStyles.whiteStyle(bold: true),
        headerTodayIcon: Icon(FontAwesomeIcons.calendarDay,color: AppColors.white,),
        weekCaptionsBackgroundColor: AppColors.primaryColor,
        headerTodayBackgroundColor: AppColors.primaryColorGreen,
        monthSelectionBackgroundColor: AppColors.primaryColorOpacity,
        monthSelectionHighlightBackgroundColor: AppColors.primaryColorGreen,
        monthSelectionTextStyle: AppStyles.primaryStyle(),
        monthSelectionHighlightTextStyle: AppStyles.whiteStyle(),
        weekCaptionsTextStyle: AppStyles.whiteStyle(size:Get.locale.toString()=='ar'?10:13),

        yearSelectionBackgroundColor: AppColors.primaryColorOpacity,
        yearSelectionHighlightBackgroundColor: AppColors.primaryColorGreen,
        yearSelectionTextStyle: AppStyles.primaryStyle(),
        yearSelectionHighlightTextStyle: AppStyles.whiteStyle(),
        changePageDuration: duration,
        monthSelectionAnimationDuration: duration,
        yearSelectionAnimationDuration: duration,

        fontFamily: AppFonts.mainFontFamily,
        maxDatetime: '${max.year}/${max.month}/${max.day}',
        // finishDatetime: '${d.year}/${d.month}/${d.day}',
        // gregorianDatetime: '${d.year}-${d.month}-${d.day}',
        // minDatetime: '${min.year}/${min.month}/${min.day}',
        rangeDatePicker: false,
        datetime: '${d.year}/${d.month}/${d.day}',
        outputFormat: 'YYYY/M/D',
// maxSpan: Duration(days: 1),
// minSpan: Duration(days: 0),
        farsiDigits: false,
        headerTodayCaption: AppStrings.today.tr,
        weekCaptions: [AppStrings.sat.tr,AppStrings.sun.tr,AppStrings.mon.tr,
          AppStrings.tue.tr,AppStrings.wed.tr,AppStrings.thu.tr,AppStrings.fri.tr],
// datetime: DateFormat('yyyy/MM/dd').format(DateTime.now()),
// finishDatetime: DateFormat('yyyy/MM/dd').format(DateTime.now().add(Duration(days: 0))),
//         gregorianFinishDatetime: DateFormat('yyyy-MM-dd').format(DateTime.now().add(Duration(days: 0))),
// gregorianDatetime: DateFormat('yyyy-MM-dd').format(DateTime.now().add(Duration(days: 0))),
        onChange: (String oldText, String newText) {

          try {
            var list=newText.split('/');
            var dt=DateTime(int.parse(list[0]),int.parse(list[1]),int.parse(list[2]));
            //var dd = DateFormat('yyyy-MM-d').format(dt);
            logic.    updateDateTime(dt);

          }catch(e){
            print(e.toString());
          }
        },


//      datetime: '1397/06/09',
      ).init()!;


      return ReactiveFormBuilder(
    form: buildForm,
    builder: (context, form, child) {



      return Column(children: [


        ReactiveTextForm.reactiveTextFieldProfile(
            formControlName: fullNameKey,

            validationMessage: AppStrings.fNameHint.tr,
            lable: AppStrings.fullName.tr,
            lableStyle: labelStyle,

            outlineInputBorder: outlineInputBorder
        ),




        ReactiveTextForm.reactiveTextFieldProfile(
            formControlName: emailKey,

            validationMessage: 'The  Email must not be empty',
            lable: AppStrings.email.tr,
            iconData: Icons.email,
            lableStyle: labelStyle,

            outlineInputBorder: outlineInputBorder
        ),
        ReactiveTextForm.reactiveTextFieldProfile(
            formControlName: ssnKey,

            validationMessage: 'The  SSN must not be empty',
            lable: AppStrings.idNo.tr,
            iconData: Icons.email,
            lableStyle: labelStyle,

            outlineInputBorder: outlineInputBorder,
          isNumber: true
        ),

        Container(
          padding: EdgeInsets.symmetric(vertical: 5,horizontal: 2),
          child: IntrinsicHeight(
            child: Row(
              children: [

                Expanded(
                    flex: 5,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Spacer(),
                        Row(
                          children: [
                            Expanded(child: Row(
                              children: [
                                Text(AppStrings.dob.tr,style: AppStyles.subTitleStyle(),),
                              ],
                            )),
                          ],
                        ),
                        //  Spacer(),

                      ],
                    )),

                UiHelper.horizontalSpaceMedium,

                Expanded(
                  flex: 11,
                  child: Column(
                    children: [
                      GestureDetector(
                        onTap: (){
                                                        Get.bottomSheet(logic.persianDatePicker,
                              enterBottomSheetDuration: Duration(milliseconds: 900),
                              exitBottomSheetDuration: Duration(milliseconds: 500),
backgroundColor: AppColors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(5),
                                  topRight: Radius.circular(5),
                              ))

                              );
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 5),
                          child: Row(
                            children: [
                              Text(DateFormat('yyyy-M-d').format(logic.dob!),style: AppStyles.primaryStyle(size: 15),),
                            ],
                          ),

                        ),
                      ),
                      Container(
                        height: 2,
                        width: Get.width,
                        //margin: EdgeInsets.symmetric(horizontal: 20),
                        color: AppColors.primaryColorGreen,
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        )


        // Row(children: [
        //   Expanded(child:
        //
        //
        //
        //
        //   ReactiveTextForm.reactiveTextField(
        //       formControlName: 'location',
        //
        //       validationMessage: AppStrings.locationHint.tr,
        //       lable: AppStrings.location.tr,
        //       iconData: Icons.location_on,
        //       lableStyle: labelStyle,
        //
        //       outlineInputBorder: outlineInputBorder
        //   ),
        //   ),
        //
        //   SizedBox(width: 10,),
        //
        //   GestureDetector(
        //     onTap: ()async{
        //
        //       var    resultLocation=await  Get.toNamed(AppRouteNames.map,arguments: AppRouteNames.register);
        //
        //       controller.updateLocation(resultLocation);
        //
        //
        //
        //       //   controller.getCurrentLocation();
        //
        //
        //       //  form.value[AppStrings.location.toLowerCase()]= controller.addressController.text ;
        //
        //     },
        //
        //     child: Container(
        //       height: 50,
        //       width: 50,
        //       alignment: Alignment.center,
        //       decoration: BoxDecoration(
        //           borderRadius: BorderRadius.circular(20),
        //           color: AppColors.primaryColor
        //       ),
        //
        //       child: Icon(Icons.location_on, color: AppColors.white,),
        //
        //
        //     ),
        //   )
        //
        // ],),
,
        SizedBox(height: 10,),

              Column(
                children: [
Row(children: [
  Ui.titleGreenUnderLine(AppStrings.gender),

],),

Row(
  children: [

    genderButton(title: AppStrings.male,selected: logic.gender==0,onTab: (){logic.updateGender(0);}),
    UiHelper.horizontalSpaceMedium,
    genderButton(title: AppStrings.female,selected: logic.gender==1,onTab: (){logic.updateGender(1);}),
    UiHelper.horizontalSpaceMassive,

    Icon(FontAwesomeIcons.male,color: logic.gender==0?AppColors.primaryColor:AppColors.subTitleColor,),
    Icon(FontAwesomeIcons.female,color: logic.gender==1?AppColors.primaryColor:AppColors.subTitleColor,),

  ],
)
                ],
              ),


        Ui.primaryButton(title: AppStrings.save,marginH: 0,onTab: ()async{



Map<String,dynamic> formData ={'sex': logic.gender==0?'Male' :'Female'};
formData.addAll(form.value);
      var d=await    logic.updateProfile(formData);

      print('d:  ********************  $d');


        }),


      ],);
    },
  );
});
  }


  editItem({String title='',IconData iconData=Icons.call,String to=AppRouteNames.editPassword}){

    return  GestureDetector(
      onTap: (){

        Get.toNamed(to);

      },

      child: Container(

        padding: EdgeInsets.symmetric(horizontal: 15,vertical: 20),
        margin: EdgeInsets.symmetric(horizontal: 0,vertical: 10),
        decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: AppColors.registerFiled
      ),

      child: Row(children: [

Icon(iconData,color: AppColors.primaryColor,),

        SizedBox(width: 10,),
        Expanded(child: Text(title.tr,style: Get.textTheme.subtitle2!.merge(TextStyle(color: AppColors.primaryColor)),)),
        Container(
            padding: EdgeInsets.all(5),
            decoration: BoxDecoration(color: AppColors.primaryColor,
            shape: BoxShape.circle
            ),
            child: Icon(Icons.arrow_forward_ios_rounded,size: 20,color: AppColors.registerFiled,)),




      ],),

      ),
    );


  }





  genderButton({String title='',bool selected=false,Function? onTab}){


    return  GestureDetector(

      onTap: (){
        if(onTab!=null){

          onTab();

        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15,horizontal: 20),
        decoration: BoxDecoration(
          color: selected?AppColors.primaryColor:AppColors.primaryColorOpacity,
          borderRadius: BorderRadius.circular(10)
        ),
        child: Text(title.tr,style: selected?AppStyles.whiteStyle(bold: true,size: 15):AppStyles.primaryStyle(size: 15,opacity: .8),),

      ),
    );

  }


}
