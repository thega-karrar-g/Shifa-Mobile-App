import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/models/m_labtest.dart';
import 'package:intl/intl.dart';

import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
class LabTestItem2 extends StatelessWidget {
   LabTestItem2({this.labtest,Key? key}) : super(key: key);

 final LabTest? labtest;

 final df=DateFormat('yyyy,MMM dd',Get.locale.toString());

  @override
  Widget build(BuildContext context) {

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          // height: 200,
          margin: EdgeInsets.symmetric(horizontal: 20,vertical: 25),
          padding: EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
              boxShadow:  [BoxShadow(color: AppColors.labTestBg.withOpacity(1), blurRadius: 10)],
              color: Colors.white,
              borderRadius: BorderRadius.circular(
35
              )),

          child: Column(
            children: [
              //   Divider(),
              Container(
                padding: EdgeInsets.symmetric(vertical: 20,horizontal: 20),
                child: Column(
                  children: [

item(labtest!.testType!, ),
                    SizedBox(height: 20,),


item('${labtest!.requestor}', )


                  ],
                ),
              ),
            ],
          ),
        ),



      ],
    );
  }


  item(String title){
    return Stack(
      children: [
Row(children: [
  Expanded(
    child: Container(
      padding: EdgeInsets.symmetric(horizontal: 15,vertical: 15),
      //  margin: EdgeInsets.symmetric(horizontal: 0,vertical: 10),

      decoration: BoxDecoration(
        color: AppColors.registerFiled,

        borderRadius: BorderRadius.circular(20),
        //  border: Border.all(color: AppColors.primaryColor)
      ),
      child: Row(
        children: [


          Text(title,style: Get.textTheme.subtitle2,),
        ],
      ),

    ),
  ),

],)      ],
    );
  }


 String convertDate(String date){
    String d='';

    try{
     d= DateFormat('E,MMM yy').format(DateTime.parse(date));



    }catch(_){}

    return d;
 }


}
