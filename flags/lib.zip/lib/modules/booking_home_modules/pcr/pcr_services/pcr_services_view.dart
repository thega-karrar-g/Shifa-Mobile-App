import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_fonts.dart';

import '../../../../shared_in_ui/shared/loading.dart';
import 'pcr_services_logic.dart';

class PCRServicesPage extends StatelessWidget {
  final PCRServicesLogic logic = Get.put(PCRServicesLogic());


   PCRServicesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return GetBuilder<PCRServicesLogic>(builder: (logic) {
  return Ui.myScaffold(child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [

      myAppBar2(title: AppStrings.pcrService),

      logic.busy?Center(child: MyLoadingWidget(),):
      Expanded(
        child: ListView.builder(
            itemCount: logic.items.length,
            itemBuilder: (bc,index)=>GestureDetector(

                onTap: (){

                  //logic.updateItems(logic.items[index]);


                },
                // child: PCRItem(pcrModel: logic.items[index],logic: logic,selected: true,)
            )),
      ),

    ],
  ));
});
  }


 TextStyle customTStyle({double size=14,isBold=false,Color color=AppColors.black}){

    return   TextStyle(color: color.withOpacity(.8),fontSize: size,fontWeight: isBold?FontWeight.bold:FontWeight.normal,fontFamily: AppFonts.mainFontFamily);


 }

}
