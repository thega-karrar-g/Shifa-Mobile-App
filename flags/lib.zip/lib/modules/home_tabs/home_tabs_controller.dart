import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/appointment/appointment_types_view.dart';
import 'package:sehati_app/modules/home_screen/home_screen_view.dart';
import 'package:sehati_app/modules/medical_file_module/medical_file/medical_file_view.dart';
import 'package:sehati_app/modules/my_profile/my_profile_view.dart';
import 'package:sehati_app/utils/helpers/theme_helper/my_flutter_app_icons.dart';

class HomeTabsController extends BaseController with GetSingleTickerProviderStateMixin {
   DateTime? currentBackPressTime;


  int _currentPageIndex = 0;

  int get getCurrentIndex => _currentPageIndex;

  changePageIndex(int newValue) {

    //if(newValue!=2){
_currentPageIndex = newValue;

    update();
    //}
  }





   late PageController pageController;


   final autoSizeGroup = AutoSizeGroup();

   late AnimationController animationController;
   late Animation<double> animation;
   late CurvedAnimation curve;

   final iconList = <IconData>[
     MyFlutterApp.home,
     MyFlutterApp.appointment,
     MyFlutterApp.medicalFile,
     MyFlutterApp.person,

   ];

   final titles=[

     AppStrings.bookNow,
     AppStrings.appointments,
     AppStrings.medicalFile,
     AppStrings.myProfile,

   ];


   List<Widget> tabs=[];
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();

    if (checkUserSignIn) {
      tabs=[
        HomeScreenView(),
        //  AppointmentPage(),
        AppointmentTypesPage(),
        // Container(),
        MedicalFilePage(),
        MyProfilePage(),
      ];

    }

changePageIndex(Get.locale.toString()=='ar'?3:0);
pageController = PageController(initialPage: getCurrentIndex);


    animationController = AnimationController(
      duration: Duration(seconds: 2),
      vsync: this,
    );
    curve = CurvedAnimation(
      parent: animationController,
      curve: Interval(
        0.2,
        1.0,
        curve: Curves.fastOutSlowIn,
      ),
    );
    animation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(curve);

    Future.delayed(
      Duration(seconds: 2),
          () => animationController.forward(),
    );
  }


}
