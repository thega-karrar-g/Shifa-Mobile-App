import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:sehati_app/models/m_file.dart';
import 'package:sehati_app/modules/booking_home_modules/radiology_lab/radiology_lab_files/radiology_lab_files_logic.dart';
import 'package:sehati_app/shared_in_ui/shared/different_dialogs.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/download_controller.dart';
import 'package:sehati_app/utils/ext_storage.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

class LabRadiologyFileItem extends StatelessWidget {
  LabRadiologyFileItem({Key? key, required this.myFile, required this.dir,required this.logic})
      : super(key: key);
  final String dir;
final RadiologyLabFilesLogic logic;
  final MyFile myFile;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: ExtStorage.fileExist(myFile.name),
        initialData: false,
        builder: (bc, snapShot) {
          print('snapShot  data :${snapShot.data}');
          return snapShot.connectionState == ConnectionState.done ?
          GestureDetector(
            onTap: () async {
              if (await ExtStorage.fileExist(myFile.name)) {
                ExtStorage.openFile(myFile.name);
              }
              else {
                if (myFile.url.isNotEmpty) {
               var   res=false;
               res=await    DifferentDialog.showProgressDownloadDialog( myFile: myFile,labFilesLogic: logic
                  );

              print('res ***************************************************  $res');

if (res==true) {

  logic.update();
  res=false;
}
                }
              }
            },
            child: Container(
              margin: EdgeInsets.symmetric(vertical: 5,),
              padding: EdgeInsets.symmetric(vertical: 15, horizontal: 10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: AppColors.primaryColorOpacity
              ),
              child: Row(
                children: [
                  SvgPicture.asset(
                    AppImages.pdf, color: AppColors.primaryColor,
                    width: 30,
                    height: 40,),
                  UiHelper.horizontalSpaceSmall,
                  Expanded(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text(myFile.name, maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: AppStyles.primaryStyle(size: 15),)),
                          ],
                        ),
                        UiHelper.verticalSpace(3),
                        Row(
                          children: [
                            Expanded(child: Text(myFile.date,
                              style: AppStyles.primaryStyleGreen(size: 13),)),
                          ],
                        ),
                      ],
                    ),
                  ),


                  UiHelper.horizontalSpaceMedium,

                  if(snapShot.data == false)
                    Icon(Icons.arrow_circle_down_outlined,
                      color: AppColors.primaryColorGreen,),
                  UiHelper.horizontalSpaceSmall,

                ],
              ),
            ),
          ) : Container();
        });
  }
}
