  import 'package:flutter/material.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

class  AuthUi{


  static  OutlineInputBorder outlineInputBorder =OutlineInputBorder(
  borderRadius: BorderRadius.all(
  Radius.circular(20)),
  borderSide: BorderSide(
  color:
  Colors.white.withOpacity(0.6))
  ,
  );

  static BoxDecoration btnBoxDecoration =BoxDecoration(

    borderRadius: BorderRadius.circular(30),
    color: AppColors.white


  );


  }