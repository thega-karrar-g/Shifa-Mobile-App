extension Ex on String {
  String get reverse => split('').reversed.join();
}
