import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:reactive_forms/reactive_forms.dart';
import '../../../language_and_localization/app_strings.dart';
import '../../../shared_in_ui/shared/dynamic_column.dart';
import '../../../shared_in_ui/shared/ui_helpers.dart';
import '../../../shared_in_ui/ui.dart';
import '../../../utils/helpers/theme_helper/app_colors.dart';
import '../../../utils/helpers/theme_helper/app_styles.dart';
import '../auth_controller.dart';

class ReactiveRegisterGuestForm extends StatelessWidget {
  ReactiveRegisterGuestForm({Key? key,}) : super(key: key);


 static TextEditingController textEditingController=TextEditingController();

  String nameKey = 'name';
  String mobileKey = 'mobile';


  final double paddingHeight = 15.0;

  var requiredFields = ' '
      '${AppStrings.phoneNum.tr} *\n'
      '${AppStrings.name.tr} *\n'
      ''
      '';


  FormGroup buildForm() => fb.group(<String, Object>{
        nameKey: FormControl<String>(
          validators: [
            Validators.required,
          ],
        ),
        mobileKey: FormControl<String>(
          validators: [
            Validators.required,
          ],
        ),

      });

  @override
  Widget build(BuildContext context) {

    return GetBuilder<AuthController>(builder: (logic) {
      var yes=false,noChecked=false;
      if (logic.nationality.answer!=null) {
        yes=logic.nationality.answer !=null&&logic.nationality.answer==true;
        noChecked=logic.nationality.answer !=null&&logic.nationality.answer==false;
      }

      return SingleChildScrollView(
        child: ReactiveFormBuilder(
          form: buildForm,
          builder: (context, form, child) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Text(
                            AppStrings.createAccount.tr
                                .toString()
                                .toUpperCase(),
                            maxLines: 2,
                            style: AppStyles.primaryStyle(size: 40, bold: true),
                          ),
                        ),
                      ),
                      UiHelper.horizontalSpace(Get.width * .3)
                    ],
                  ),
                  Ui.greenLine(),

                  Row(
                    children: [
                      Expanded(
                          child: Text(
                        AppStrings.fillRequiredInformation.tr,
                        style: AppStyles.subTitleStyle(),
                      )),
                      UiHelper.horizontalSpace(120),
                    ],
                  ),
                  UiHelper.verticalSpace(Get.height * .02),


                  Visibility(
                    visible:true,
                    child: DynamicColumn(
                      children: [
                        Container(
                          // height: 80,
                          decoration: Ui.getBoxDecorationLogin(),
                          child: ReactiveTextField<String>(
                            formControlName: nameKey,
                            validationMessages: (control) => {
                              ValidationMessage.required:
                                  AppStrings.name.tr +
                                      ' ' +
                                      AppStrings.mustNotEmpty.tr,
                            },
                            keyboardType: TextInputType.text,
                            textInputAction: TextInputAction.next,
                            style: AppStyles.primaryStyleGreen(),
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              focusedErrorBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              focusedBorder: InputBorder.none,

                              labelText: AppStrings.fullName.tr.capitalizeFirst,
                              labelStyle: AppStyles.subTitleStyle(),
                              // filled: true,

                              //  fillColor: AppColors.filedBg ,
                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 12, vertical: paddingHeight),
                              hintText: AppStrings.phoneNum.tr,
                              errorStyle: TextStyle(
                                  color: Colors.white.withOpacity(0.7)),
                              hintStyle: TextStyle(
                                  color: Colors.white.withOpacity(0.7)),
                              // prefixIcon: Icon(Icons.call,
                              //
                              //     color: Colors.white),
                            ),
                          ),
                        ),

                        UiHelper.verticalSpaceMedium,
                        Container(
                          height: 70,
                          decoration: Ui.getBoxDecorationLogin(),
                          child: ReactiveTextField<String>(
                            formControlName: mobileKey,
                            validationMessages: (control) => {
                              ValidationMessage.required:
                              AppStrings.phoneNum.tr +
                                  ' ' +
                                  AppStrings.mustNotEmpty.tr,
                            },
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                              LengthLimitingTextInputFormatter(10),
                            ],
                            keyboardType: TextInputType.number,
                            textInputAction: TextInputAction.next,
                            style: AppStyles.primaryStyleGreen(),
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              focusedErrorBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              focusedBorder: InputBorder.none,

                              labelText: AppStrings.phoneNum.tr,
                              labelStyle: AppStyles.subTitleStyle(),
                              // filled: true,

                              //  fillColor: AppColors.filedBg ,
                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: paddingHeight),
                              hintText: AppStrings.phoneNum.tr,
                              errorStyle: TextStyle(
                                  color: Colors.white.withOpacity(0.7)),
                              hintStyle: TextStyle(
                                  color: Colors.white.withOpacity(0.7)),
                              // prefixIcon: Icon(Icons.call,
                              //
                              //     color: Colors.white),
                            ),
                          ),
                        ),
                    UiHelper.verticalSpaceMedium,

                        Container(
                          margin: EdgeInsets.symmetric(vertical: 5),
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)
                              ,
                              color: AppColors.primaryColorOpacity
                          ),
                          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 15),
                          child: Column(
                            children: [
                              Row(children: [

                                Expanded(child: Text(logic.nationality.question.tr,style: AppStyles.primaryStyle(bold: true,size: 13,height: 1.5),))
                                ,

                                UiHelper.horizontalSpaceMedium,

                                Row(


                                  children: [



                                    GestureDetector(
                                      onTap: (){
                                        logic.updateNationality(true);
                                      },
                                      child: SizedBox(
                                        height: 30,
                                        child: Row(
                                          children: [

                                            Text(AppStrings.saudi.tr,style: AppStyles.primaryStyleGreen(),),
                                            SizedBox(width: 5,),
                                            Container(
                                              padding: EdgeInsets.all(3),
                                              width: 20,height: 20,
                                              decoration: BoxDecoration(
                                                  color: yes?AppColors.primaryColorGreen:AppColors.primaryColorOpacity,
                                                  borderRadius: BorderRadius.circular(5),
                                                  border: Border.all(width: yes?0:2,color: AppColors.subTitleColor)

                                              ),
                                              child:yes? Icon(Icons.check,color: AppColors.white,size: 15,):Container(),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    UiHelper.horizontalSpaceMedium,
                                    GestureDetector(
                                      onTap: (){
                                        logic.updateNationality(false);

                                      },
                                      child: SizedBox(
                                        height: 30,
                                        child: Row(
                                          children: [

                                            Text(AppStrings.nonSaudi.tr,style: AppStyles.primaryStyleGreen(),),
                                            SizedBox(width: 10),
                                            Container(
                                              padding: EdgeInsets.all(3),
                                              width: 20,height: 20,
                                              decoration: BoxDecoration(
                                                  color: noChecked?AppColors.primaryColorGreen:AppColors.primaryColorOpacity,
                                                  borderRadius: BorderRadius.circular(5),
                                                  border: Border.all(width: noChecked?0:2,color: AppColors.subTitleColor)

                                              ),
                                              child:noChecked? Icon(Icons.check,color: AppColors.white,size: 15,):Container(),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    UiHelper.verticalSpaceMedium,
//Spacer()

//         Expanded(
//           child: IntrinsicWidth(
//     child: Row(
//     children: [
//
//     Text(AppStrings.other.tr,style: AppStyles.primaryStyleGreen(),),
// UiHelper.horizontalSpaceMedium,
//     Container(
//     padding: EdgeInsets.all(3),
//     width: 20,height: 20,
//     decoration: BoxDecoration(
//     color: !questionnaire.answer?AppColors.primaryColorGreen:AppColors.primaryColorOpacity,
//     borderRadius: BorderRadius.circular(5),
//     border: Border.all(width: !questionnaire.answer?0:2,color: AppColors.subTitleColor)
//
//     ),
//     child:!questionnaire.answer? Icon(Icons.check,color: AppColors.white,size: 15,):Container(),
//     ),
//     ],
//     ),
//     ),
//         ),
                                  ],
                                ),

                              ],),



                            ],
                          ),
                        )

                      ],
                    ),
                  ),


                  Ui.primaryButton(
                      title:
                           AppStrings.signUp,
                      marginH: 0,
                      onTab: () {

                        if (logic.nationality.answer !=null) {
                          if (form.valid ) {

                            Map<String, dynamic> data = {
                              'ksa_nationality':logic.nationality.answer! ? 'KSA':''
                            };
                            data.addAll(form.value);
                            print(data);
                            logic.registerGuest(data);

                          } else {
                            // print(form.errors.toString());
                            //  form.markAllAsTouched();
                            logic.buildFailedSnackBar(
                                msg: AppStrings.fillAllRequiredFields.tr +
                                    '\n\n' +
                                    requiredFields
                            );
                          }
                        }
                        else{
                          logic.buildFailedSnackBar(
                              msg: AppStrings.nationalityRequired.tr

                          );
                        }



                      }),



                  SizedBox(
                    height: 32,
                  ),

                  //  SizedBox(height: 50),
                ],
              ),
            );
          },
        ),
      );
    });
  }
}
