import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_column.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
class NoAppointmentTimes extends StatelessWidget {
  const NoAppointmentTimes({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(



      child: SingleChildScrollView(
        child: DynamicColumn(
       // mainAxisAlignment: MainAxisAlignment.center,
        //crossAxisAlignment: CrossAxisAlignment.center,
        children: [

        Padding(
          padding: const EdgeInsets.symmetric(vertical: 1),
          child: SvgPicture.asset(AppImages.noAppointment,width: Get.width*.7,height: Get.height*.3,),
        ),
          UiHelper.verticalSpaceLarge,

          Text(AppStrings.oops.tr,style: AppStyles.primaryStyle(size: 30),),

          UiHelper.verticalSpaceSmall,

          Text(AppStrings.noAppointment.tr,textAlign: TextAlign.center,style: AppStyles.primaryStyle(size: 15,opacity: .7,height: 1.7),),


    ],),
      ),);
  }
}
