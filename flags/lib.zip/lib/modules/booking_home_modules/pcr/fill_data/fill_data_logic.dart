import 'package:get/get.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/patient.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';

import '../../../../utils/constants/app_route_names.dart';
import '../../../../utils/enums.dart';

class FillDataLogic extends BaseController {


  final  nameKey='name';
  final  passportKey='passport';
  final  ssnKey='ssn';

  List<Patient>  patients=[];



  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    PatientDataLogic.paymentAppointmentType=PaymentAppointmentTypes.pcr;


    int count=Get.arguments as int  ;
  var  forms=List<FormGroup> .generate(count,(i)=>FormGroup({
    nameKey: FormControl<String>(
      validators: [
        Validators.required,
      ],
    ),
    ssnKey: FormControl<String>(
      validators: [
        Validators.required,
      ],
    ),
    passportKey: FormControl<String>(
      validators: [

      ],

    ),
  }));
    patients=List<Patient> .generate(count,(i)=>Patient(id: i+1,form: forms[i]));

  }


updatePatient(Patient p){

    patients[patients.indexOf(p)].hasCertificate=! p.hasCertificate;
    update();
}


navToNext(){

    bool valid=true;
    for (var element in patients) {

      if (element.form.invalid) {
        valid=false;
        break;
      }

      if (element.hasCertificate&&element.form.value[passportKey]==null) {
        valid=false;
break;
      }
    }
if (valid) {
  PatientDataLogic.showFiles=false;
  PatientDataLogic.patientFollowers='';

  for (var el in patients) {
var passport=el.hasCertificate? ('-'+el.form.value[passportKey].toString()):'';
    var e=el.form.value[nameKey].toString().trim()+'-'+el.form.value[ssnKey].toString()+ passport;
    PatientDataLogic.patientFollowers+=e;

    if (el!=patients.last) {
      PatientDataLogic.patientFollowers+=',';

    }

  }


  Get.toNamed(AppRouteNames.patientData,);

}
else{
  buildFailedSnackBar(msg: AppStrings.fillAllRequiredFields.tr);
}




}

}
