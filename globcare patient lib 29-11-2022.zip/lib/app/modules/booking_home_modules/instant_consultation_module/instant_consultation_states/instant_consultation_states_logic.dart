import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jitsi_meet_wrapper/jitsi_meet_wrapper.dart';
import 'package:wakelock/wakelock.dart';

import '../../../../base_controller/base_controller.dart';
import '../../../../core/language_and_localization/app_strings.dart';
import '../../../../data/enums.dart';
import '../../../../data/models/request_model.dart';
import '../../../../data/models/user_model.dart';
import '../../../../data/repositories/appointment_repository.dart';
import '../../../../data/repositories/profile_repository.dart';
import '../../../../data/repositories/request_repository.dart';
import '../../../../global_widgets/shared/different_dialogs.dart';
import '../../../../routes/app_route_names.dart';
import '../../../../services/push_notification_service.dart';
import '../../../../utils/audio/asset_audio.dart';
import '../../../../utils/constants/api_keys.dart';
import '../../../../utils/constants/app_images.dart';
import '../../../../utils/constants/app_urls.dart';
import '../../../../utils/constants/booking_vars.dart';
import '../../../qr_scanner/qr_scanner_logic.dart';
import '../../appointment_base_controllers/appointment_base_controller.dart';

class InstantConsultationStatesLogic extends BaseController
    with WidgetsBindingObserver {
  final AppointmentRepository _appointmentRepository = AppointmentRepository();
  final RequestRepository requestRepository = RequestRepository();
  final ProfileRepository _profileRepository = ProfileRepository();
  PushNotificationService pushNotificationService = PushNotificationService();

  List<AppUser> members = [];

  List<RequestModel> requests = [];
  static DateTime current1 = DateTime.now();

  static bool userInMeeting = false, meetingFinished = false, playTone = true;

  GlobalKey countDownKey = GlobalKey();
  String keyValue = '0';

  static String rate = '';

  Duration countDownDuration = Duration(minutes: 2, seconds: 0);

  static InstantConsultationStatus instantConsultationStatus =
      InstantConsultationStatus.load;

  DateTime alert = DateTime.now().add(Duration(seconds: 10));

///////////   meeting vars

  String room = '';
  bool? isAudioOnly = true;
  bool? isAudioMuted = true;
  bool? isVideoMuted = true;

  final subjectText = TextEditingController(text: "");
  final nameText = TextEditingController(text: "");
  final emailText = TextEditingController(text: "");
  final iosAppBarRGBAColor = TextEditingController(text: "#0080FF80");
  static AppUser? selectedPatient;

  fetch() async {
    members.clear();
    members.add(currentUser!);
    setBusy(true);
    var list = await _profileRepository.getMemberList();
    members.addAll(list);
    setBusy(false);
    update();
  }

  updateSelectedPatient(AppUser user) {
    selectedPatient = user;

    update();
  }

  joinMeeting() async {

    Wakelock.enable();


    var meetingUrl = currentRequest!.jitsiLink;
    room = (meetingUrl.substring(meetingUrl.lastIndexOf('/') + 1));

    nameText.text = currentRequest!.patient;
    emailText.text = currentUser!.email;
    subjectText.text = currentRequest!.name;

    //String? serverUrl = serverText.text.trim().isEmpty ? null : serverText.text;

    // Enable or disable any feature flag here
    // If feature flag are not provided, default values will be used
    // Full list of feature flags (and defaults) available in the README
    Map<FeatureFlag, Object> featureFlags = {
      FeatureFlag.isWelcomePageEnabled: false,
      FeatureFlag.isAddPeopleEnabled: false,
      FeatureFlag.isInviteEnabled: false,
      FeatureFlag.isRaiseHandEnabled: false,
      FeatureFlag.isMeetingPasswordEnabled: false,
      FeatureFlag.isLiveStreamingEnabled: false,
      FeatureFlag.isReplaceParticipantEnabled: false,
      FeatureFlag.isRecordingEnabled: false,
      // FeatureFlagEnum.ADD_PEOPLE_ENABLED: false,
      // FeatureFlagEnum.INVITE_ENABLED: false,
      // FeatureFlagEnum.RAISE_HAND_ENABLED: false,
      // FeatureFlagEnum.MEETING_PASSWORD_ENABLED: false,
    };

    // Define meetings options here
    var options = JitsiMeetingOptions(
      roomNameOrUrl: room,
      serverUrl: meetingUrl,
      subject: subjectText.text,
      // token: tokenText.text,
      isAudioMuted: false,
      isAudioOnly: isAudioOnly,
      isVideoMuted: isVideoMuted,
      userDisplayName: nameText.text,
      userEmail: emailText.text,
      featureFlags: featureFlags,
    );

    await JitsiMeetWrapper.joinMeeting(
        options: options,
        listener: JitsiMeetingListener(
          onConferenceWillJoin: (message) {
            // debugPrint("${options.room} will join with message: $message");
          },
          onConferenceJoined: (message) {
            // debugPrint("${options.room} joined with message: $message");
          },
          onConferenceTerminated: (message, er) {
            Wakelock.disable();

            // debugPrint("${options.room} terminated with message: $message");
          },
        ));
  }









  ///////////////////

  updateStatus(InstantConsultationStatus s) {
    instantConsultationStatus = s;
    update();
  }

  sendRequest() async {
    userInMeeting = false;
String fcmToken=await PushNotificationService().getToken();
    Map<String, String> data = {
      'patient_id': selectedPatient!.id,
      'qr_code': QrScannerLogic.qrCtrl.text.toString().trim()
    };

    Map<String, String> fcmData = {
      'id': selectedPatient!.id,
      'type':'1',
      'device_type':Platform.isAndroid?'android':'ios',
      'fcm_token':fcmToken,
    };

    DifferentDialog.showProgressDialog();

    await requestRepository.updateFcmToken(fcmData);
    var requests =
        await requestRepository.getRequestList(id: selectedPatient!.id);
    var allow =
        requests.where((element) => element.status.contains('waiting')).toList();

    if (allow.isEmpty) {
      var res = await requestRepository.createInstantCon(data);

      Get.back();
      if (res != null) {
        if (res[ApiKeys.responseSuccess] == 1) {
          Get.back();

          QrScannerLogic.qrCtrl.clear();




          pushNotificationService.sendPushMessage(
            title: PushNotificationService.notificationTitle,
            body:
                '${PushNotificationService.notificationBody}  ${selectedPatient!.name} ',
            token: AppUrls.baseUrl == AppUrls.baseUrlProduction
                ? PushNotificationService.androidTopic
                : PushNotificationService.androidTestTopic,
          );
          pushNotificationService.sendPushMessage(
              title: PushNotificationService.notificationTitle,
              body:
                  '${PushNotificationService.notificationBody}  ${selectedPatient!.name} ',
              token: AppUrls.baseUrl == AppUrls.baseUrlProduction
                  ? PushNotificationService.iosTopic
                  : PushNotificationService.iosTestTopic,
              isIos: true);
          onInit();
        } else {


          Get.back();
          buildFailedSnackBar(msg: res[ApiKeys.responseMessage]);
        }
      } else {
        buildFailedSnackBar(msg: AppStrings.thereIsProblem.tr);
      }
    } else {
      Get.back();

      buildFailedSnackBar(msg: AppStrings.alreadyHaveRequest.tr);
    }

    // soonMessage();
    // DifferentDialog.showProgressDialog();
    // var d=await Future.delayed(Duration(seconds: 2),);
    // Get.back();
    // updateStatus(InstantConsultationStatus.timer);
    // var dd=await Future.delayed(Duration(seconds: 5),);
    // updateStatus(InstantConsultationStatus.accepted);
  }

  timerFinished() async {
    if (DateTime.now().minute % 2 == 0) {
      updateStatus(InstantConsultationStatus.approved);
    } else {
      updateStatus(InstantConsultationStatus.resend);
    }
  }

  openPayment({
    bool applePay = false,
  }) async {
    BookingVars.paymentFromInstantCons = true;
    DifferentDialog.showPaymentLoading();

     await AppointmentBaseController()
        .performtrxn(
            orderId: currentRequest!.id.toString(),
            failRoute: AppRouteNames.instantConsultation,
            requestModel: currentRequest,
            transType: Platform.isIOS && applePay ? 'applepay' : 'hosted')
        .then((value) {
      onInit();
    });
  }

  String formatDuration(Duration d) {
    String f(int n) {
      return n.toString().padLeft(2, '0');
    }

    // We want to round up the remaining time to the nearest second
    d += Duration(microseconds: 999999);
    return "${f(d.inMinutes)}:${f(d.inSeconds % 60)}";
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();


    WidgetsBinding.instance.removeObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    switch (state) {
      case AppLifecycleState.paused:
        {}
        // await player.play();
        break;
      case AppLifecycleState.inactive:
        {}
        //await player.stop();
        break;
      case AppLifecycleState.resumed:
        {
          instantConsultationStatus = InstantConsultationStatus.load;
          checkData();
        }
        //  await player.stop();
        break;
      case AppLifecycleState.detached:
        {}
        // await player.stop();
        // TODO: Handle this case.
        break;
    }
  }

  List<String> statuses = [
    'waiting',
    'approved',
    'ready',
    'in_process',
    'evaluation'
  ];

  RequestModel? currentRequest;

  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
    instantConsultationStatus = InstantConsultationStatus.load;

    QrScannerLogic.qrCtrl.clear();
    userInMeeting = false;
    BookingVars.price = 0;
    WidgetsBinding.instance.addObserver(this);
    checkData();
  }

  selectPatientClick() {
    if (selectedPatient != null) {
      InstantConsultationStatesLogic.instantConsultationStatus =
          InstantConsultationStatus.send;
      update();
      setBusy(true);
      checkData();
      setBusy(false);
    } else {
      buildFailedSnackBar(msg: AppStrings.selectPatientMsg.tr);
    }
  }

  bool isLoading = false;

  checkData() async {
    // setBusy(true);
    isLoading = true;
    requests = await requestRepository.getRequestList(id: selectedPatient!.id);
    isLoading = false;

    currentRequest = requests.reversed
        .toList()
        .firstWhereOrNull((element) => statuses.contains(element.status));

    // setBusy(false);
    // if (AssetAudio.player.playing) {
    //   AssetAudio.player.stop();
    // }

    if (currentRequest == null) {
      // print('***************************   currentRequest=null  ');
      instantConsultationStatus = InstantConsultationStatus.send;
// setBusy(true);
      isLoading = true;

      String price = await _appointmentRepository.getInstantConsPrice();
// setBusy(false);
      isLoading = false;

      BookingVars.price = double.parse(price);
    } else if (currentRequest!.status == statuses[0]) {
      // print('***************************   currentRequest=waiting  ');

      instantConsultationStatus = InstantConsultationStatus.timer;
      timerCount();
    } else if (currentRequest!.status == statuses[1]) {
      // print('***************************   approved  ');

      // print('******************************   price ${currentRequest!.price} ********************************');

      var vat = 0.0;
      double currentPrice =
          currentRequest!.price.toDouble() - currentRequest!.discount;
      if (!selectedPatient!.ssn.startsWith('1')) {
        vat = BookingVars.price * .15;
        //  BookingVars.price+= vat;
      }

      currentPrice += vat;

      if (currentPrice == 0) {
        instantConsultationStatus = InstantConsultationStatus.load;
        update();
        var data = {
          ApiKeys.consultationId: currentRequest!.id.toString(),
          ApiKeys.paymentReference: 'Free'
        };

        await _appointmentRepository.setPaymentStatus(data,
            url: AppUrls.setPaymentStatusInstantCons);

        checkData();
      } else {
        instantConsultationStatus = InstantConsultationStatus.approved;
      }
      timerCount();
    } else if (currentRequest!.status == statuses[4]) {
      // print('***************************   approved  ');

      instantConsultationStatus = InstantConsultationStatus.rating;
      timerCount();
    } else if (currentRequest!.status == statuses[2]) {
      // print('***************************   ready  ');

      instantConsultationStatus = InstantConsultationStatus.startMeeting;

      timerCount();
    } else if (currentRequest!.status == statuses[3]) {
      // print('***************************   in_process  ');

      instantConsultationStatus = InstantConsultationStatus.startMeeting;
      timerSound();
      // if (!userInMeeting && !meetingFinished) {
      //   if (!AssetAudio.player.playing && playTone) {
      //    // AssetAudio().playAudio();
      //
      //     if (HomeScreenController.isAppInForeground) {
      //       LocalNotificationService.instance.showLocaleNotification(
      //           AppStrings.meetingReadyTitleMsg.tr,
      //           AppStrings.meetingReadyBodyMsg.tr,
      //           payload: AppRouteNames.instantConsultation);
      //     }
      //   }
      // }

      timerCount();
    }
    update();
  }

  timerCount() {
    DateTime current = DateTime.now();
    Stream timer = Stream.periodic(Duration(seconds: 1), (i) {
      current = current.add(Duration(seconds: 1));
      return current;
    }).take(300);

    timer.listen((data) {
      var d = data as DateTime;

      if (d.difference(current1).inSeconds % 10 == 0) {
        keyValue = 'key${d.difference(current1).inSeconds}';
        // print('   *************************  30');
        // print('   *************************  ${d.difference(current1).inSeconds}');

        if (!isLoading) {
          checkData();
        }
      }
    });
  }

  timerSound() {
    DateTime current = DateTime(2022, 1, 1, 1, 1, 1);
    DateTime current2 = DateTime(2022, 1, 1, 1, 1, 10);
    Stream timer = Stream.periodic(Duration(seconds: 1), (i) {
      current = current.add(Duration(seconds: 1));
      return current;
    }).take(10);

    timer.listen((data) {
      var d = data as DateTime;

      if (d.difference(current2).inSeconds == 0) {
        print(
            'timer sound ******************  ${d.difference(current2).inSeconds}');

        if (AssetAudio.player.playing) {
          AssetAudio.player.stop();
        }
        playTone = false;
      }
    });
  }

  startMeeting() {
    userInMeeting = true;
    if (AssetAudio.player.playing) {
      AssetAudio.player.stop();
    }

    // var appointment = Appointment(
    //     appointmentDate: DateTime.now(),
    //     doctor: currentRequest!.name,
    //
    //     videoLink: currentRequest!.jitsiLink);
    // //print(appointment.videoLink);
    //
    //  Get.toNamed(AppRouteNames.meetingPage,arguments: appointment);

    joinMeeting();
  }

  onCounterDownDone() {
    DifferentDialog.showServiceInfoSnackBar(
        description: AppStrings.doctorsBusyNow.tr,
        title: '',
        image: AppImages.iconInstantCon);
    //buildFailedSnackBar(msg: AppStrings.doctorsBusyNow.tr);
    Future.delayed(Duration(seconds: 3), () {
      countDownKey = GlobalObjectKey(keyValue);
      update();
    });
  }

  rateConsultation() async {
    Map<String, String> data = {
      'consultation_id': currentRequest!.id.toString(),
      'evaluation': rate,
    };

    DifferentDialog.showTankMsgDialog();

    var result = await requestRepository.rateConsultation(data);
    print(result);
    // buildSuccessSnackBar(msg: result);
    Get.back();

    if (result[ApiKeys.responseSuccess] == 1) {
      DifferentDialog.showTankMsgDialog();

      // checkData();
    }
  }
}
