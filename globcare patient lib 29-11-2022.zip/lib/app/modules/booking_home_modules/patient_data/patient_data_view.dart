import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../../../core/language_and_localization/app_strings.dart';
import '../../../core/theme_helper/app_colors.dart';
import '../../../core/theme_helper/app_styles.dart';
import '../../../data/enums.dart';
import '../../../global_widgets/project_widget/record_widget.dart';
import '../../../global_widgets/shared/loading.dart';
import '../../../global_widgets/shared/my_appbar.dart';
import '../../../global_widgets/shared/ui_helpers.dart';
import '../../../global_widgets/ui.dart';
import '../../../utils/constants/app_images.dart';
import '../../../utils/constants/booking_vars.dart';
import '../../auth/widgets/reactive_login_form.dart';
import '../../auth/widgets/reactive_register_form.dart';
import '../../my_profile_module/members/widgets/reactive_add_member_form.dart';
import '../choose_date_period/choose_date_period_view.dart';
import '../pcr/choose_date/choose_date_view.dart';
import 'patient_data_logic.dart';
import 'widgets/file_item.dart';
import 'widgets/patient_item.dart';

class PatientDataPage extends StatelessWidget {
  final PatientDataLogic logic = Get.put(PatientDataLogic());

  PatientDataPage({Key? key}) : super(key: key);
  final FocusNode _focusNode =
      FocusNode(); //1 - declare and initialize variable

  OutlineInputBorder outlineInputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(10.h)),
    borderSide: BorderSide(color: AppColors.registerFiled),
  );
  final double paddingHeight = 25.0.h;
  final labelStyle = TextStyle(
      color: AppColors.subTitleColor,
      fontWeight: FontWeight.bold,
      fontSize: 13.sp);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: GetBuilder<PatientDataLogic>(builder: (logic) {
      return Column(
        children: [
          myAppBar2(title: AppStrings.patientData.tr),
          logic.busy
              ? MyLoadingWidget()
              : Expanded(
                  child: GestureDetector(
                    onTap: () {
                      _focusNode.unfocus();
                    },
                    child: Container(
                      //  margin: EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.h),
                        // border: Border.all(color: AppColors.primaryColor.withOpacity(.1))
                      ),

                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Text(AppStrings.explainHealthProblem.tr,style:AppStyles.primaryStyle(bold: true,size: 14),),
                            //
                            // SizedBox(height: 10,),
                            //
                            // Text(AppStrings.tellDoctorSufferFromDiseases.tr,
                            //   style: AppStyles.subTitleStyle(),
                            // ),

                            //    UiHelper.verticalSpaceLarge,
                            if(logic.currentUser !=null)

                            Row(
                              children: [
                                Ui.titleGreenUnderLine(
                                    AppStrings.selectPatient.tr,
                                    bottomPadding: 8),
                              ],
                            ),

                            if(logic.currentUser !=null)
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 0, vertical: 10),
                              decoration: BoxDecoration(
                                  color: AppColors.primaryColorOpacity,
                                  borderRadius: BorderRadius.circular(10)),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Row(
                                        children: [
                                          // UiHelper.horizontalSpaceMedium,
                                          Row(
                                            children: logic.members
                                                .map((e) => GestureDetector(
                                                    onTap: () {
                                                      logic
                                                          .updateSelectedPatient(
                                                              e);
                                                    },
                                                    child: PatientItem(
                                                      user: e,
                                                      selected: logic
                                                                  .selectedPatient !=
                                                              null &&
                                                          logic.selectedPatient!
                                                                  .id ==
                                                              e.id,
                                                    )))
                                                .toList(),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  UiHelper.horizontalSpaceSmall,
                                  GestureDetector(
                                    onTap: () {
                                      Get.bottomSheet(
                                              Padding(
                                                padding:
                                                    const EdgeInsets.all(30.0),
                                                child: AddMemberForm(),
                                              ),
                                              isScrollControlled: true,
                                              backgroundColor: AppColors.white,
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.only(
                                                          topLeft:
                                                              Radius.circular(
                                                                  10),
                                                          topRight:
                                                              Radius.circular(
                                                                  10))))
                                          .then((value) {
                                        print(
                                            '***************************   after ');
                                        logic.fetch();
                                      });
                                    },
                                    child: Container(
                                      // width: 100.w,
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 5.w),
                                      height: 30.h,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                          color: AppColors.primaryColorGreen,
                                          borderRadius: BorderRadius.only(
                                            topRight:
                                                Radius.circular(ar ? 5.h : 0),
                                            bottomRight:
                                                Radius.circular(ar ? 5.h : 0),
                                            bottomLeft:
                                                Radius.circular(ar ? 0 : 5.h),
                                            topLeft:
                                                Radius.circular(ar ? 0 : 5.h),
                                          )),

                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.add,
                                            color: AppColors.white,
                                            size: 17.w,
                                          ),
                                          UiHelper.horizontalSpaceTiny,
                                          Text(
                                            AppStrings.addNew.tr,
                                            textAlign: TextAlign.center,
                                            style: AppStyles.whiteStyle(
                                                bold: false, size: 11),
                                          ),
                                          UiHelper.horizontalSpaceTiny,
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            if (PatientDataLogic.chooseDateType ==
                                    ChooseDateType.doctor ||
                                PatientDataLogic.chooseDateType ==
                                    ChooseDateType.hide)
                              Container()
                            else if (PatientDataLogic.chooseDateType ==
                                ChooseDateType.pcr)
                              ChoosePCRDatePage()
                            else
                              ChooseDatePeriodPage(
                                globalKey: logic.periodsKey,
                              ),

                            UiHelper.verticalSpaceLarge,

                            Ui.titleGreenUnderLine(AppStrings.audioNote.tr,
                                bottomPadding: 8),

                            Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 5.w, vertical: 5.h),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10.h),
                                    color: AppColors.primaryColorOpacity),
                                child: RecoredWidget()),
                            SizedBox(
                              height: 20.h,
                            ),

                            Ui.titleGreenUnderLine(AppStrings.textNote.tr,
                                bottomPadding: 8),

                            TextFormField(
                              textInputAction: TextInputAction.newline,
                              keyboardType: TextInputType.multiline,
                              maxLines: null,
                              focusNode: _focusNode,
                              style: Ui.labelStyle,
                              controller: BookingVars.patientComment,
                              decoration: InputDecoration(
                                //  labelText: lable.tr,
                                labelStyle: AppStyles.subTitleStyle(bold: true),
                                filled: true,
                                fillColor: AppColors.primaryColorOpacity,
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: 12.w, vertical: 10.h),
                                hintText: AppStrings.textNoteHint.tr,
                                errorStyle: TextStyle(
                                    color: Colors.white.withOpacity(0.7)),
                                errorBorder: outlineInputBorder,
                                hintStyle: AppStyles.subTitleStyle(
                                  bold: true,
                                ),
                                border: outlineInputBorder,
                                focusedBorder: outlineInputBorder,
                                enabledBorder: outlineInputBorder,
                              ),
                            ),

                            SizedBox(
                              height: 20.h,
                            ),
                            // if(BookingVars.showFiles)
                            Column(
                              children: [
                                Row(
                                  children: [
                                    Ui.titleGreenUnderLine(
                                        AppStrings.attachments.tr,
                                        bottomPadding: 8),
                                  ],
                                ),
                                Container(
                                  width: Get.width,
                                  decoration: BoxDecoration(
                                      color: AppColors.primaryColorOpacity,
                                      borderRadius:
                                          BorderRadius.circular(10.h)),
                                  height: 80.h,
                                  // color: AppColors.registerFiled,

                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Container(
                                          // width: Get.width*.7,
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 15.w, vertical: 5.h),
                                          decoration: BoxDecoration(
                                              color:
                                                  AppColors.primaryColorOpacity,
                                              borderRadius:
                                                  BorderRadius.circular(10.h)),

                                          child: Container(
                                            //height: 60,
                                            //  width: 60,
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10.h),
                                                border: Border.all(
                                                    color: AppColors
                                                        .primaryColorOpacity)),
                                            child: Row(
                                              children: [
                                                GestureDetector(
                                                    onTap: () {
                                                      Get.bottomSheet(
                                                          Padding(
                                                            padding: EdgeInsets
                                                                .symmetric(
                                                                    horizontal:
                                                                        50.w,
                                                                    vertical:
                                                                        30.h),
                                                            child: Row(
                                                              children: [
                                                                Expanded(
                                                                    child:
                                                                        GestureDetector(
                                                                  onTap: () {
                                                                    logic
                                                                        .pickCamera();
                                                                  },
                                                                  child: Row(
                                                                    children: [
                                                                      SvgPicture
                                                                          .asset(
                                                                        AppImages
                                                                            .camera,
                                                                        height:
                                                                            25.h,
                                                                        width:
                                                                            20.w,
                                                                      ),
                                                                      UiHelper
                                                                          .horizontalSpaceSmall,
                                                                      Text(
                                                                        AppStrings
                                                                            .openCamera
                                                                            .tr,
                                                                        style: AppStyles.primaryStyle(
                                                                            size:
                                                                                12,
                                                                            bold:
                                                                                true),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                )),
                                                                Expanded(
                                                                    child:
                                                                        GestureDetector(
                                                                  onTap: () {
                                                                    logic
                                                                        .pickFiles();
                                                                  },
                                                                  child: Row(
                                                                    children: [
                                                                      SvgPicture
                                                                          .asset(
                                                                        AppImages
                                                                            .files,
                                                                        height:
                                                                            25.h,
                                                                        width:
                                                                            25.w,
                                                                      ),
                                                                      UiHelper
                                                                          .horizontalSpaceSmall,
                                                                      Text(
                                                                        AppStrings
                                                                            .openFiles
                                                                            .tr,
                                                                        style: AppStyles.primaryStyle(
                                                                            size:
                                                                                12,
                                                                            bold:
                                                                                true),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                )),
                                                              ],
                                                            ),
                                                          ),
                                                          backgroundColor:
                                                              AppColors.white,
                                                          shape: RoundedRectangleBorder(
                                                              borderRadius: BorderRadius.only(
                                                                  topLeft: Radius
                                                                      .circular(
                                                                          20.h),
                                                                  topRight: Radius
                                                                      .circular(
                                                                          20.h))));
                                                      //logic.pickFiles();
                                                    },
                                                    child: SvgPicture.asset(
                                                      AppImages.upload,
                                                      width: 25.w,
                                                      height: 25.h,
                                                    )),
                                                UiHelper.horizontalSpaceMedium,
                                                Visibility(
                                                    visible: !(BookingVars
                                                                .attachFile !=
                                                            null ||
                                                        BookingVars
                                                                .cameraFile !=
                                                            null),
                                                    child: Text(
                                                      AppStrings
                                                          .uploadAttachmentHint
                                                          .tr,
                                                      style: AppStyles
                                                          .primaryStyle(
                                                              bold: true,
                                                              opacity: .5),
                                                    )),
                                                Visibility(
                                                  visible: BookingVars
                                                              .attachFile !=
                                                          null ||
                                                      BookingVars.cameraFile !=
                                                          null,
                                                  child: Expanded(
                                                      child: ListView(
                                                    scrollDirection:
                                                        Axis.horizontal,
                                                    children: [
                                                      if (BookingVars
                                                              .attachFile !=
                                                          null)
                                                        ViewFileItem(
                                                          file: BookingVars
                                                              .attachFile!,
                                                          onTab: () {
                                                            BookingVars
                                                                    .attachFile =
                                                                null;
                                                            logic.update();
                                                          },
                                                        ),
                                                      if (BookingVars
                                                              .cameraFile !=
                                                          null)
                                                        ViewFileItem(
                                                          file: BookingVars
                                                              .cameraFile!,
                                                          onTab: () {
                                                            BookingVars
                                                                    .cameraFile =
                                                                null;
                                                            logic.update();
                                                          },
                                                        ),
                                                    ],
                                                  )),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                UiHelper.verticalSpaceMedium,
                              ],
                            ),

                            if (logic.currentUser == null)
                              Column(
                                children: [
                                  Ui.primaryButton(
                                      title: AppStrings.logIn,
                                      //  marginV: 10,
                                      onTab: () {
                                        BookingVars.fromPatientData = true;

                                        Get.bottomSheet(
                                                Padding(
                                                  padding:
                                                      UiHelper.safeAreaPadding,
                                                  child: SizedBox(
                                                      height: Get.height * .7,
                                                      child: ReactiveLoginForm(
                                                        title: AppStrings.logIn,
                                                      )),
                                                ),
                                                backgroundColor:
                                                    AppColors.white,
                                                isScrollControlled: true,
                                                enterBottomSheetDuration:
                                                    Duration(milliseconds: 750),
                                                exitBottomSheetDuration:
                                                    Duration(milliseconds: 750),
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.only(
                                                            topRight:
                                                                Radius.circular(
                                                                    10),
                                                            topLeft: Radius
                                                                .circular(10))))
                                            .then((value) {
                                        //  logic.fetch();
                                        });

                                      }),
                                  SizedBox(
                                    height: 8,
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                          child: Divider(
                                        color: AppColors.subTitleColor,
                                      )),
                                      UiHelper.horizontalSpaceMedium,
                                      Text(
                                        AppStrings.or.tr,
                                        style:
                                            AppStyles.primaryStyle(bold: true),
                                      ),
                                      UiHelper.horizontalSpaceMedium,
                                      Expanded(
                                          child: Divider(
                                        color: AppColors.subTitleColor,
                                      )),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 12,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      GestureDetector(
                                        onTap: () {
                                          BookingVars.fromPatientData = true;



                                          Get.bottomSheet(
                                                  Padding(
                                                    padding: UiHelper
                                                        .safeAreaPadding,
                                                    child: SizedBox(
                                                        height: Get.height * .8,
                                                        child:
                                                            ReactiveRegisterForm()),
                                                  ),
                                                  backgroundColor:
                                                      AppColors.white,
                                                  isScrollControlled: true,
                                                  enterBottomSheetDuration:
                                                      Duration(
                                                          milliseconds: 750),
                                                  exitBottomSheetDuration:
                                                      Duration(
                                                          milliseconds: 750),
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.only(
                                                              topRight: Radius
                                                                  .circular(10),
                                                              topLeft: Radius
                                                                  .circular(
                                                                      10))))
                                              .then((value) {

                                                logic.logger.i('result is :$value');


                                         //   logic.fetch();
                                          });

                                          //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                                        },
                                        child: Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 20, vertical: 10),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                border: Border.all(
                                                    width: 1,
                                                    color: AppColors
                                                        .primaryColorGreen)),
                                            child: Text(
                                              AppStrings.register.tr,
                                              textAlign: TextAlign.right,
                                              style:
                                                  AppStyles.primaryStyleGreen(
                                                      bold: true, size: 15),
                                            )),
                                      ),

                                      UiHelper.horizontalSpaceMedium,

                                      //      Container(width:30,color: AppColors.subTitleColor,height: 1,),
                                      //     UiHelper.horizontalSpaceMedium,

                                      // GestureDetector(
                                      //   onTap: () {
                                      //     BookingVars.fromPatientData=true;
                                      //
                                      //     Get.bottomSheet(Padding(
                                      //       padding: UiHelper.safeAreaPadding,
                                      //       child:   SizedBox(
                                      //           height: Get.height*.8,
                                      //           child: ReactiveRegisterGuestForm()),
                                      //     ),
                                      //         backgroundColor: AppColors.white,
                                      //         isScrollControlled: true,
                                      //         enterBottomSheetDuration: Duration(milliseconds: 750),
                                      //         exitBottomSheetDuration: Duration(milliseconds: 750),
                                      //         shape: RoundedRectangleBorder(
                                      //             borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10))
                                      //         )
                                      //
                                      //     ).then((value) {
                                      //       logic.update();
                                      //
                                      //     });
                                      //
                                      //     //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                                      //   },
                                      //
                                      //   child: Container(
                                      //
                                      //
                                      //
                                      //       padding: EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                                      //
                                      //       decoration: BoxDecoration(
                                      //           borderRadius: BorderRadius.circular(10),
                                      //           border: Border.all(width: 1,color: AppColors.primaryColorGreen)
                                      //       ),
                                      //
                                      //       child: Text(AppStrings.continueAsGuest.tr,style: AppStyles.primaryStyleGreen(bold: true,size: 15),)),
                                      // ),
                                    ],
                                  ),
                                ],
                              )
                            else
                              Ui.primaryButton(
                                  title: logic.isSend
                                      ? AppStrings.send
                                      : AppStrings.continueTo.tr,
                                  color: AppColors.primaryColor,
                                  marginH: 0,
                                  onTab: () {
                                    logic.navToNext();

//print(logic.currentUser);
                                  }),

                            UiHelper.verticalSpaceMassive
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
        ],
      );
    }));
  }

  greenLine() {
    return Container(
      height: 5,
      width: 100,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: AppColors.primaryColorGreen),
    );
  }

  titleGreenUnderLine(String title, {double bottomMargin = 15}) {
    return IntrinsicWidth(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title.tr,
            style: AppStyles.primaryStyle(bold: true, size: 14),
          ),
          Row(
            children: [
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(top: 5),
                  height: 5,
                  //  width: Get.width*.3,
                  decoration: BoxDecoration(
                      color: AppColors.primaryColorGreen,
                      borderRadius: BorderRadius.circular(20)),
                ),
              ),
            ],
          ),
          SizedBox(
            height: bottomMargin,
          ),
        ],
      ),
    );
  }
}
