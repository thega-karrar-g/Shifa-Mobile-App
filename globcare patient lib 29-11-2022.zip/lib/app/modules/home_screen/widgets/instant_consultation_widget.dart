
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:im_animations/im_animations.dart';
import 'dart:math' as math; // import this

import '../../../core/language_and_localization/app_strings.dart';
import '../../../core/theme_helper/app_colors.dart';
import '../../../core/theme_helper/app_styles.dart';
import '../../../global_widgets/shared/ui_helpers.dart';
import '../../../global_widgets/ui.dart';
import '../../../utils/constants/app_images.dart';

class InstantConsultationWidget extends StatelessWidget {
  const InstantConsultationWidget({Key? key,this.onTab}) : super(key: key);

  final Function? onTab;

  @override
  Widget build(BuildContext context) {
    double height=100;
    return  Padding(
      padding: EdgeInsets.only(bottom: 10.h),
      child: Row(
        children: [


          Expanded(
            flex: 2,
            child: GestureDetector(
              onTap: () {
onTab!();


},
              child: Container(
                height: height.h,
                decoration: BoxDecoration(
                    color: AppColors.primaryColor
                        .withOpacity(.1),
                    borderRadius: BorderRadius.circular(5.h)),
                padding: EdgeInsets.symmetric(
                    vertical: 5.h, horizontal: 30),
                // margin: EdgeInsets.symmetric(vertical: 0.h,horizontal: 30),
                child: Row(
                  children: [
                    Expanded(
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              vertical: 2.h, horizontal: 5.w),
                          child: Column(
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                flex: 1,
                                child: Row(
                                  children: [
                                    Expanded(
                                        child: Text(
                                          AppStrings
                                              .instantConsultation.tr,
                                          maxLines: 2,
                                          textAlign: TextAlign.center,
                                          style:
                                          AppStyles.primaryStyle(
                                              size: 11,
                                              bold: true,
                                              color: AppColors
                                                  .primaryColor),
                                        )),
                                  ],
                                ),
                              ),
                              //     UiHelper.verticalSpaceTiny,
                              Ui.primaryButton(
                                  title: AppStrings.bookNow,
                                  paddingV: 5,
                                  color:
                                  AppColors.primaryColorGreen,
                                  fontSize: 11,
                                  marginH: 3,
                                  marginV: 0,
                                  radius: 5,
                                  onTab: () {
                                    // PatientDataLogic.serviceName=AppStrings.telemedicine.tr;
                                    // PatientDataLogic.service=NurseService(name: AppStrings.telemedicine,nameAr: 'استشارة طبية فيديو');
                                    // PatientDataLogic.appointmentType='';
                                    // DoctorsController.doctorType='TD';
                                    // PatientDataLogic.serviceCode='';

                                    onTab!();

                                    //      DifferentDialog.showUpdateAppDialog();

                                    //  Get.to(VerifyCodePage());

                                    // Get.to(LocationTestPage(),arguments: AppRouteNames.doctorBook);
                                    //   Get.toNamed(AppRouteNames.doctors,arguments: AppRouteNames.doctorBook);
                                  }),

                              UiHelper.verticalSpaceSmall,
                            ],
                          ),
                        )),
                    UiHelper.horizontalSpaceMedium,
                    Container(
                      // height: height.h,
                       width: 70.w,
                      padding: EdgeInsets.symmetric(
                          vertical: 2.h, horizontal: 2.w),
                      child: Transform(
                        transform: Matrix4.rotationY(
                            Get.locale.toString() == 'ar'
                                ? 0
                                : math.pi),
                        alignment: Alignment.center,
                        child: ColorSonar(
//                           waveColor: AppColors.primaryColor,
//                           waveThickness: 1.3,
//                           radius: 70,
// insets: 0,

                          contentAreaRadius: 13.h,
                          waveFall: 11.h,
                           waveMotionEffect: Curves.elasticInOut,
                          waveMotion: WaveMotion.smooth,
  duration: Duration(seconds: 1),

                            contentAreaColor: AppColors.primaryColor.withOpacity(.2),
                            outerWaveColor: AppColors.primaryColor.withOpacity(.2),
                            innerWaveColor: AppColors.primaryColor.withOpacity(.2),
                            middleWaveColor: AppColors.primaryColor.withOpacity(.2),



                          //  waveThickness: 2,
                          child: Image.asset(
                           AppImages.iconCallDoctor,
                            // fit: BoxFit.fill,
                            width: 100.w, height: (height-20).h,
                            // colorBlendMode: BlendMode.color,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // UiHelper.horizontalSpaceMedium,
          // Expanded(child:  CallUsWidget(),),
        ],
      ),
    );
  }
}
