
import 'dart:io';

import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';

import '../appointment_base_controllers/appointment_base_controller.dart';

class BookInvoiceLogic extends BaseController {

bool booked=false;

  int index=0;

double vat=0;

var isIos=Platform.isIOS;


  changePaymentType(int i){

    index=i;

    if(i==0){

      PatientDataLogic.paymentType=AppStrings.cash.toLowerCase();
    }
    else{
      PatientDataLogic.paymentType=AppStrings.insurance.toLowerCase();

    }

    update();

  }

  void navToPayment() {
if(currentUser!=null) {

  PatientDataLogic.price+=double.parse(vat.toStringAsFixed(2));
  AppointmentBaseController().makeBookingWithFileDio();
//  performtrxn();

  // if (index == 0) {
  //   PatientDataLogic.paymentType = 'cash';
  //
  //   // print(PatientDataLogic.appointmentDate);
  //   Get.toNamed(AppRouteNames.paymentMethods);
  // }
  //
  // else {
  //   PatientDataLogic.paymentType = 'insurance';
  //   //     print(PatientDataLogic.appointmentDate);
  //
  //
  //   Get.toNamed(AppRouteNames.insurance);
  // }
}
else{
  buildFailedSnackBar(msg: AppStrings.loginRequired.tr);
}


  }

//
//   Future<void> performtrxn( {String transType ='hosted'}) async {
//
//
//     _queryFirstName.text = 'John';
//     _queryCountry.text = 'SA';
//     _queryLastName.text = 'Deo';
//     _queryAddress.text='101 Street';
//     _queryCity.text='Mumbai';
//     _queryState.text='Maharashtra';
//     _queryZip.text='4000001';
//     _queryphone.text='110000000';
//     _queryemail.text='text@web.com';
//     _queryorderid.text=getRandString(10000000);
//     _querycurrency.text='SAR';
//     _queryamt.text='1.00';
//     _queryaction.text='1';
//     _querytokenoperation.text='A';
//     _querytokentype.text='1';//cust present or not
//     _querycardTokenNo.text='';
//     _queryudf1.text='';
//     _queryudf2.text='';
//     _queryudf3.text='';
//     _queryudf4.text='';
//     _queryudf5.text='';
//     _querycompanyName.text='Concerto';
//     _queryshipping.text='1.00';
//     _querymerchantIdentifier.text="merchant.urway.technologies.applepay";
//
//     var lastResult ="";
//     var act=actionHolder;
//     var carOper=cardOperHolder;
//     var tokenTy=_querytokentype.text;
//     print('$act - $carOper - $tokenTy');
//     if(transType=="hosted") {
//       // on Apple Click call other method  check with if else
//       lastResult = await Payment.makepaymentService(context: Get.context!,
//           country: _queryCountry.text,
//           action: act,
//           currency: _querycurrency.text,
//        //   amt: '100.0',
//           amt: PatientDataLogic.price.toString(),
//           customerEmail: _queryemail.text,
//           trackid: _queryorderid.text,
//           udf1: _queryudf1.text,
//          // udf2: 'https://glob-care.com/',
//           udf2: 'https://glob-care.com/test.html',
//           udf3: Get.locale.toString(),
//           udf4: '',
//           udf5: '',
//           cardToken: _querycardTokenNo.text,
//           address: _queryAddress.text,
//           city: _queryCity.text,
//           state: _queryState.text,
//           tokenizationType: tokenTy,
//           zipCode: _queryZip.text,
//           tokenOperation: carOper,onBack: (){
//
//         DifferentDialog.showBackPaymentDialog();
//
//           },title: AppStrings.paymentDetails.tr,ar: Get.locale.toString()=='ar');
//
//
//       print('Result in Main is $lastResult');
//     }
//     else if(transType =="applepay")
//     {
//       print("In apple pay");
//       lastResult = await Payment.makeapplepaypaymentService
//         (context: Get.context!,
//           country: _queryCountry.text,
//           action: act,
//           currency: _querycurrency.text,
//           amt: PatientDataLogic.price.toString(),
//           customerEmail: _queryemail.text,
//           trackid: _queryorderid.text,
//           udf1: _queryudf1.text,
//           udf2: _queryudf2.text,
//           udf3: _queryudf3.text,
//           udf4: _queryudf4.text,
//           udf5: _queryudf5.text,
//           tokenizationType: tokenTy,
//           merchantIdentifier:_querymerchantIdentifier.text,
//           shippingCharge: _queryshipping.text,
//           companyName:_querycompanyName.text
//       );
//       print('Result on Apple Pay in Main is $lastResult');
//     }
//
// // if (xyz != null )
// //    {h
// //      lastResult=xyz;
//     Map<String,dynamic> decodedJSON;
//     var decodeSucceeded = false;
//     try {
//       decodedJSON = json.decode(lastResult) as Map<String, dynamic>;
//       decodeSucceeded = true;
//     } on FormatException catch (e) {
//       print('The provided string is not valid JSON');
//     }
//     if(decodeSucceeded)
//     {
//       var responseData = json.decode(lastResult);
//       print('RESP $responseData');
//       var trnsId = responseData["TranId"] as String;
//       var respCode = responseData["ResponseCode"] as String ;
//       var result = responseData["result"] as String;
//       var amount = responseData["amount"] as String;
//       var cardToken = responseData["cardToken"] as String;
//       var cardBrand = responseData["cardBrand"] as String;
//       var maskedPanNo = responseData["maskedPanNo"] as String;
//
// //     String trnsid=responseData.TranId;
//       Get.to( ReceiptPage(trnsId, result, amount, cardToken,cardBrand,maskedPanNo,respCode));
//
//       // Navigator.of(context).push(MaterialPageRoute(builder: (context) => ReceiptPage(trnsid,result,amount,cardToken,respCode)));
//     }
//     else
//     {
//       if(lastResult.isNotEmpty) {
//         print('Show');
//       }
//       else
//       {
//         print('Show Blank Data');
//       }
//     }
//     print('Payment $lastResult');
//   }
//
//
//
//   String getRandString(int len) {
//     var random = Random.secure();
//     var values =  random.nextInt(10000000);
//    // return base64UrlEncode(values);
//  return   values.toString();
//   }


@override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    vat=0;

    PatientDataLogic.price=0;
    PatientDataLogic.price=double.parse(PatientDataLogic.service.price)*PatientDataLogic.service.quantity;
    if(PatientDataLogic.service2.id!=0)
{
  PatientDataLogic.price+=double.parse(PatientDataLogic.service2.price)*PatientDataLogic.service2.quantity;

}
    if(PatientDataLogic.service3.id!=0)
    {
      PatientDataLogic.price+=double.parse(PatientDataLogic.service3.price)*PatientDataLogic.service3.quantity;

    }

      print(PatientDataLogic.price);
  }
}
