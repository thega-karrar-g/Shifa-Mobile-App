import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/widgets/reactive_login_form.dart';
import 'package:sehati_app/modules/auth/widgets/reactive_register_form.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
import 'package:sehati_app/utils/time_helper.dart';


import 'book_invoice_logic.dart';

class BookInvoicePage extends StatelessWidget {
  final BookInvoiceLogic logic = Get.put(BookInvoiceLogic());

   BookInvoicePage({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    final ar=Get.locale.toString()=='ar';

   // var d=DateTime.parse(PatientDataLogic.appointmentDate.substring(0,10));

    print(PatientDataLogic.appointmentDate);
    var d=TimeHelper.addZerosToDate(PatientDataLogic.appointmentDate);



    return Ui.myScaffold(child:
    Column(children: [

      myAppBar2(title: AppStrings.bookingDetails),


      Expanded(
        child: GetBuilder<BookInvoiceLogic>(builder: (logic) {
          logic. vat=0.0;

          var price=(double.parse( PatientDataLogic.service.price) * PatientDataLogic.service.quantity);

          if(logic.currentUser!=null){

            if(logic.currentUser!.nationality!=null){

              if(!logic.currentUser!.nationality!.contains('KSA')){
                logic.  vat= PatientDataLogic.price*.15;
                //  PatientDataLogic.price+= vat;
              }
            }

          }



  return SingleChildScrollView(
    padding: EdgeInsets.zero,
          child: Wrap(
            children: [

              Column(children: [

                if(logic.currentUser==null)
                Column(
                  children: [
                    Ui.primaryButton(
                        title: AppStrings.logIn,
                        onTab: (){

                          PatientDataLogic.fromPatientData=true;

Get.bottomSheet(Padding(
  padding: UiHelper.safeAreaPadding,
  child:   SizedBox(
      height: Get.height*.7,
      child: ReactiveLoginForm(title: AppStrings.logIn,)),
),
backgroundColor: AppColors.white,
isScrollControlled: true,
enterBottomSheetDuration: Duration(milliseconds: 750),
exitBottomSheetDuration: Duration(milliseconds: 750),
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10))
  )

).then((value) {
  logic.update();
});

                        }
                    ),

                    SizedBox(
                      height: 16,
                    ),

                    Row(children:  [

                      Expanded(child: Divider(color: AppColors.subTitleColor,)),
                      UiHelper.horizontalSpaceMedium,
                      Text(AppStrings.or.tr,style: AppStyles.primaryStyle(bold: true),),
                      UiHelper.horizontalSpaceMedium,

                      Expanded(child: Divider(color: AppColors.subTitleColor,)),


                    ],),

                    SizedBox(
                      height: 16,
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        GestureDetector(
                          onTap: () {
                            PatientDataLogic.fromPatientData=true;

                            Get.bottomSheet(Padding(
                              padding: UiHelper.safeAreaPadding,
                              child:   SizedBox(
                                  height: Get.height*.8,
                                  child: ReactiveRegisterForm()),
                            ),
                                backgroundColor: AppColors.white,
                                isScrollControlled: true,
                                enterBottomSheetDuration: Duration(milliseconds: 750),
                                exitBottomSheetDuration: Duration(milliseconds: 750),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(topRight: Radius.circular(10),topLeft: Radius.circular(10))
                                )

                            ).then((value) {
                              logic.update();

                            });

                            //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                          },

                          child: Text(AppStrings.register.tr,style: AppStyles.primaryStyle(bold: true,size: 15),),
                        ),
                      ],
                    ),
                  ],
                ),


                Stack(
                  clipBehavior: Clip.none,
                  children: [

                    Container(
                      margin: EdgeInsets.only(top:logic.currentUser!=null? 50:20,bottom: 25),
                      decoration: BoxDecoration(
                          color: AppColors.primaryColorOpacity,
                          borderRadius: BorderRadius.circular(10)
                      ),
                      child: Column(children: [



                        Padding(

                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Column(children: [

if(logic.currentUser!=null)
                              UiHelper.verticalSpace(80)
else
  UiHelper.verticalSpace(16),


                              if(PatientDataLogic.doctor.name!.isNotEmpty)
  UiHelper.verticalSpace(10),

                              if(PatientDataLogic.doctor.name!.isNotEmpty)
                              invoiceRow(title: AppStrings.doctor,value: ar?PatientDataLogic.doctor.nameAr!:PatientDataLogic.doctor.name!,),
                              invoiceRow(title:ar? PatientDataLogic.service.nameAr:PatientDataLogic.service.name,value: ' $price '+AppStrings.currency.tr,),
                              if(PatientDataLogic.service2.id!=0)
                              invoiceRow(title:ar? PatientDataLogic.service2.nameAr:PatientDataLogic.service2.name,value: ' ${PatientDataLogic.service2.price} '+AppStrings.currency.tr,),
                              if(PatientDataLogic.service3.id!=0)

                                invoiceRow(title:ar? PatientDataLogic.service3.nameAr:PatientDataLogic.service3.name,value: ' ${PatientDataLogic.service3.price} '+AppStrings.currency.tr,),

                              Row(children: [
                                Text( DateFormat(' d ').format((d)),style: AppStyles.primaryStyleGreen(bold: true,size: 12),),

                                Text(DateFormat(' MMM ',Get.locale.toString()).format((d)),style: AppStyles.primaryStyleGreen(bold: true,size: 12),),
                                Text( DateFormat(' yyyy ').format((d)),style: AppStyles.subTitleStyle(bold: true,size: 12),),

                              if(PatientDataLogic.appointmentDate.length>10)
                                Text( DateFormat(' HH:mm a',Get.locale.toString()).format((d)),style: AppStyles.subTitleStyle(bold: true,size: 12),)
                                else
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 20),
                                  child: Text(PatientDataLogic.period.tr,style: AppStyles.subTitleStyle(bold: true,size: 12),),
                                ),




                                UiHelper.horizontalSpaceMedium,SvgPicture.asset(AppImages.calendar,color: AppColors.primaryColorGreen,),

                              ],),

UiHelper.verticalSpaceMedium,
                            //  invoiceRow(title: AppStrings.addedTax,value: '10 '+AppStrings.currency.tr),



                                invoiceRow(title: AppStrings.addedTax,value: '${logic.vat.toStringAsFixed(2)}  ${AppStrings.currency.tr}',)

                              ,
                           //   invoiceRow(title: AppStrings.personsCount,value: '1',marginV: 20),


                            ],)),

                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          height: 60,

                          decoration: BoxDecoration(
                              color: AppColors.primaryColor,
                              borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10),

                                  bottomRight: Radius.circular(10)
                              )
                          ),

                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(children: [

                                Text(AppStrings.total.tr,style: AppStyles.whiteStyle(size: 15,bold: false),),

                                Spacer(),
                                Text(' ${(PatientDataLogic.price+logic.vat).toStringAsFixed(2)} '+AppStrings.currency.tr,style: AppStyles.whiteStyle(size: 15,bold: true),),

                              ],),
                              UiHelper.verticalSpaceSmall,
                              // Row(children: [
                              //
                              //   Text(AppStrings.addedTax.tr,style: AppStyles.whiteStyle(size: 15,bold: false),),
                              //
                              //   Spacer(),
                              //   if(logic.checkUserSignIn)
                              //   Text( '${logic.currentUser!.ssn.startsWith('1')? '0':  ( PatientDataLogic.price)*.15}  ${AppStrings.currency.tr}',style: AppStyles.whiteStyle(size: 15,bold: true),)
                              //  else
                              //   Text(  ' 0  ${AppStrings.currency.tr}',style: AppStyles.whiteStyle(size: 15,bold: true),)
                              //
                              // ],),
                            ],
                          ),

                        ),





                      ],),
                    ),
                    Positioned(
                        top: 20,
                        child: Row(
                          children: [

                            if(logic.currentUser!=null)

                            RotatedBox(
                              quarterTurns: ar? 2:0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  alignment: Alignment.centerLeft,
                                  height: 100,width: Get.width-60,
                                  decoration: BoxDecoration(
                                    image:  DecorationImage(

                                      // colorFilter: ColorFilter.mode(AppColors.primaryColor.withOpacity(0.3), BlendMode.dstATop),

                                      image:  AssetImage(AppImages.invoiceBgPng,), fit: BoxFit.fitWidth,),

                                  ),

                                  child: Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: RotatedBox(
                                        quarterTurns: ar?2:0,

                                        child: Text(  logic.currentUser!.name,style: AppStyles.whiteStyle(bold: true),)),
                                  ),

                                ),
                              ),
                            ),
                          ],
                        )),

                  ],
                ),


                // Column(
                //   children: [
                //     Row(
                //       children: [
                //         Text(AppStrings.paymentType.tr,style: AppStyles.primaryStyle(bold: true,size: 16),),
                //       ],
                //     ),
                //     Ui.greenLine(),
                //
                //
                //     Row(
                //       children: [
                //
                //         genderButton(title: AppStrings.cash,selected: logic.index==0,onTab: (){logic.changePaymentType(0);}),
                //         UiHelper.horizontalSpaceMedium,
                //         genderButton(title: AppStrings.insurance,selected: logic.index==1,onTab: (){logic.changePaymentType(1);}),
                //         UiHelper.horizontalSpaceMassive,
                //
                //
                //       ],
                //     )
                //   ],
                // ),

                UiHelper.verticalSpaceMedium,

                Row(children: [
                  Expanded(
                    child: Text.rich(TextSpan(text: AppStrings.byClick.tr+ ' ',

                      style: AppStyles.subTitleStyle(size: 13,),

                    children: [

                      TextSpan(text:AppStrings.termsAndConditions.tr ,style: AppStyles.primaryStyle(size: 13,bold: true,height: 1.5)
                      ,
                          recognizer:  TapGestureRecognizer()..onTap = () {
                            Get.toNamed(AppRouteNames.termsOfService);
                          }

                      )
                    ]

                    ),



                    ),
                  ),



                ],),

                Row(
                  children: [
                    Expanded(
                    child: Ui.primaryButton(title: AppStrings.cardPay,fontSize: 15,color: logic.currentUser!=null?AppColors.primaryColor:AppColors.subTitleColor,onTab: (){

                      logic.navToPayment();

                    }),
                  ),




                  ],
                ),

                //  if(logic.isIos)
                // Ui.primaryButton(title: AppStrings.applePay,fontSize: 15,icon: FontAwesomeIcons.applePay,marginV: 10,color: logic.currentUser!=null?AppColors.black:AppColors.subTitleColor,onTab: (){
                //
                //   logic.navToPayment();
                //
                // })
              ],)

            ],
          ),
        );
}),
      ),






    ],)


    );
  }



  invoiceRow({String title='',String value='',double marginV=15}){

    return                   Padding(
      padding:  EdgeInsets.only(left: 0,bottom: marginV),
      child: Row(
        children: [
          Expanded(child: Text(title.tr,style: AppStyles.primaryStyle(),)),
          Text(value.tr,textAlign: TextAlign.center,style: AppStyles.primaryStyle(bold: true,size: 13),),


        ],

      ),
    );

  }


  genderButton({String title='',bool selected=false,Function? onTab}){


    return  GestureDetector(

      onTap: (){
        if(onTab!=null){

          onTab();

        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15,horizontal: 20),
        decoration: BoxDecoration(
            color: selected?AppColors.primaryColor:AppColors.primaryColorOpacity,
            borderRadius: BorderRadius.circular(10)
        ),
        child: Text(title.tr,style: selected?AppStyles.whiteStyle(bold: true,size: 15):AppStyles.primaryStyle(size: 15,opacity: .8),),

      ),
    );

  }


}
