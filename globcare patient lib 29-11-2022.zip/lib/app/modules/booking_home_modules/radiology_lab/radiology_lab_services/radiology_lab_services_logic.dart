import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../base_controller/base_controller.dart';
import '../../../../core/language_and_localization/app_strings.dart';
import '../../../../data/enums.dart';
import '../../../../data/models/home_service.dart';
import '../../../../data/models/nurse_service.dart';
import '../../../../data/repositories/service_repository.dart';
import '../../../../routes/app_route_names.dart';
import '../../../../utils/constants/booking_vars.dart';

class RadiologyLabServicesLogic extends BaseController {
  final ServiceRepository _serviceRepository = ServiceRepository();
  int index = 0;
  String code = 'R';

  GlobalKey? key = GlobalKey();
  final finalKey = GlobalKey();
  List<NurseService> _services = [],
      searchList = [],
      currentServices = [],
      selectedItems = [];

  HomeService homeService = Get.arguments;

  updateIndex(int i) {
    index = i;

    switch (i) {
      case 0:
        {
          code = 'L';
        }
        break;
      case 1:
        {
          code = 'LP';
        }
        break;
    }
    currentServices.clear();
    currentServices.addAll(_services.where((element) => element.code == code));
    searchList.clear();
    searchList.addAll(currentServices);
    key = null;

    update();
  }

  updateItems(NurseService item) {
    key = finalKey;

    if (selectedItems.contains(item)) {
      selectedItems.remove(item);
    } else {
      if (selectedItems.isEmpty || selectedItems.length < 3) {
        selectedItems.add(item);
      } else {
        AppStrings.selectTimeMsg;
        buildFailedSnackBar(msg: AppStrings.maximumServicesMsg.tr);
      }
    }

    update();
  }

  checkItem(NurseService item) {
    return selectedItems.contains(item);
  }

  updateItemsAdd(NurseService item) {
    // key=finalKey;

    if (item.quantity < 5) {
      currentServices[currentServices.indexOf(item)].quantity++;
    }
    update();
  }

  updateItemsSub(NurseService item) {
    // key=finalKey;

    if (item.quantity > 1) {
      currentServices[currentServices.indexOf(item)].quantity--;
    }
    update();
  }

  navToTimeSlots() {
    // if(selectedItems.isNotEmpty){
    //
    //
    //   if(homeService.code=='R'){
    //     BookingVars.appointmentType='-hhc';
    //
    //   }
    //    if(homeService.code=='PCR'){
    //     //BookingVars.appointmentType='-hhc';
    //     BookingVars.isPcr=true;
    //
    //
    //    }
    //
    //
    //    else{
    //      BookingVars.isPcr=false;
    //
    //    }
    //   else{
    //     BookingVars.appointmentType='-hhc';
    //
    //
    //   }
    //
    //
    //   BookingVars.serviceId=nurseService.id;
    //   BookingVars.service=nurseService;
    //
    //   BookingVars.price=double.parse(nurseService.price);
    //
    //   BookingVars.serviceType='N';
    //   BookingVars.serviceCode='';
    //
    //   BookingVars.doctorName='';
    //   BookingVars.doctor.name='';
    //   BookingVars.doctor.nameAr='';
    //   BookingVars.paymentAppointmentType=PaymentAppointmentTypes.hhc;
    //
    //   Get.toNamed(AppRouteNames.chooseDatePeriod);
    //
    // }else{
    //   buildFailedSnackBar(msg: AppStrings.selectMsg.tr);
    // }

    if (selectedItems.isNotEmpty) {
      BookingVars.serviceId = selectedItems[0].id;
      BookingVars.service = selectedItems[0];
      if (selectedItems.length > 1) {
        BookingVars.service2 = selectedItems[1];
      } else {
        BookingVars.service2 = NurseService();
      }

      if (selectedItems.length > 2) {
        BookingVars.service3 = selectedItems[2];
      } else {
        BookingVars.service3 = NurseService();
      }

      BookingVars.price = 0.0;
      for (var element in selectedItems) {
        BookingVars.price += double.parse(element.price);
      }
      BookingVars.paymentAppointmentType = PaymentAppointmentTypes.hhc;

      BookingVars.serviceType = 'N';
      BookingVars.serviceCode = '';

      BookingVars.appointmentType = '-hhc';
      BookingVars.doctorName = '';
      BookingVars.doctor.name = '';
      BookingVars.doctor.nameAr = '';

      Get.toNamed(AppRouteNames.patientData);
    } else {
      buildFailedSnackBar(msg: AppStrings.selectMsg.tr);
    }
  }

  @override
  search({String txt = ''}) {
    searchList.clear();

    searchList.addAll(currentServices
        .where((element) =>
            element.name.toLowerCase().contains(txt.toLowerCase()) ||
            element.nameAr.contains(txt))
        .toList());

    update();
  }

  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
    BookingVars.audioFile = null;
    BookingVars.attachFile = null;
    BookingVars.cameraFile = null;
    BookingVars.service2 = NurseService();
    BookingVars.service3 = NurseService();
    BookingVars.showFiles = true;
    BookingVars.patientComment.clear();
    setBusy(true);
    _services = await _serviceRepository.getServicesList();
    currentServices
        .addAll(_services.where((element) => element.code == homeService.code));

    searchList.addAll(currentServices);

    print(homeService.code);
    print(_services.length);
    print(currentServices.length);
    print(searchList.length);
    setBusy(false);
    update();
  }
}
