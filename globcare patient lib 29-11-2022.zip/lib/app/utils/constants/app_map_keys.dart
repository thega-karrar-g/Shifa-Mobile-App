class GoogleMapApiKeys {
  static const String androidApiKey = 'AIzaSyCy2qo-6fEu-Ln06xDUgJQxM7V2TGgGGTo';

  static const String iOSApiKey = 'AIzaSyBL0_a-fhNZXgGZfzHW46pPqZcmxLVfkLs';
}
