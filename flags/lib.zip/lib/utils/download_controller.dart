import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/shared_in_ui/shared/different_dialogs.dart';
import 'package:sehati_app/utils/ext_storage.dart';

class DownloadController extends BaseController {
  double progress = 0.0;

  bool downloaded=false;
  downloadFile({String url = '', String fileName = ''}) async {
    var exist = await ExtStorage.fileExist(fileName);
    var savePath = await ExtStorage.savePathFile(fileName);
 if (!exist) {

   print( '    ***************************************  start download');

    try {
      downloaded=false;
      progress=0;
   //   setBusy(true);
     // DifferentDialog.showProgressDownloadDialog();
      await Dio().download(url, savePath, onReceiveProgress: (received, total) {
        if (total != -1) {
          print((received / total * 100).toStringAsFixed(0) + "%");
          //you can build progressbar feature too

          progress = double.parse((received / total * 100).toStringAsFixed(0));
          print('****************  $progress');
          update();
        }
      });
      if (progress==100) {
        downloaded=true;

      }

     // setBusy(false);
      print("File is saved to download folder.");
    } catch (e) {
      print(e.toString());
    }}
  }
}
