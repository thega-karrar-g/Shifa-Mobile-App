import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/booking_home_modules/home_visit/home_visit_item.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';

import 'home_visit_logic.dart';

class HomeVisitPage extends StatelessWidget {
  final HomeVisitLogic logic = Get.put(HomeVisitLogic());

   HomeVisitPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: Column(
      children: [
        myAppBar2(title: AppStrings.homeVisitDoctor),
        Expanded(child: ListView.builder(
            itemCount: logic.homeVisitServices.length,
            itemBuilder: (bc,index)=>HomeVisitItem(homeService: logic.homeVisitServices[index],)),)

      ],
    ));
  }
}
