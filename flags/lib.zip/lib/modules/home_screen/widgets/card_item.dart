import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/modules/booking_home_modules/service_details/service_details_logic.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
class CardItem extends StatelessWidget {
   CardItem({Key? key,this.homeService,this.primary=false}) : super(key: key);

   bool primary=true;
   HomeService? homeService;
  @override
  Widget build(BuildContext context) {
    return Container(
      //  elevation: 0.1,
      decoration: BoxDecoration(
        //  color:
        //  primary?
        //  AppColors.primaryColor.withOpacity(.05)
              //:AppColors.primaryColorGreen.withOpacity(.05),
          //,
          borderRadius: BorderRadius.circular(10)
      ),


      child: InkWell(
        onTap: (){

          if(homeService!.next.isNotEmpty) {
            ServiceDetailsLogic.serviceCode = homeService!.code;
            ServiceDetailsLogic.icon = homeService!.icon;
            Get.toNamed(homeService!.route, arguments: homeService);
          }
          else{


            BaseController().soonMessage();
          }

        },
        child: Stack(
          children: [
            // Positioned.fill(
            //
            //     child: Image.asset(
            //      // primary?AppImages.maskPrimaryPng : AppImages.maskGreenPng
            //       AppImages.maskPrimaryPng
            //
            //       ,width: Get.width/2,height: 200,fit: BoxFit.fill,)),

            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.all(0.0),
                 // color: AppColors.primaryColorGreen,
                  alignment: Alignment.center,
                  // height: 60,
                  //  width: 60,
                  child: Image.asset(
                    homeService!.icon,
               //     color:primary? AppColors.primaryColor:AppColors.primaryColorGreen,
                 //   color: AppColors.primaryColor,
                    width: 60,
                    height: 60,
                    fit: BoxFit.fitHeight,
                  ),
                ),
                Expanded(
                  child: Container(
               //     color: AppColors.primaryColorOpacity,
                    padding: const EdgeInsets.symmetric(horizontal: 5,vertical: 0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            homeService!.name.tr,maxLines: 3,
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                            style: AppStyles.primaryStyle(bold: true,size: 10.sp,height: 1.3)
      //  :AppStyles.primaryStyleGreen(bold: true,size: 10.sp,height: 1.5),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),


          ],
        ),
      ),
    );
  }
}
