import 'package:flutter/material.dart';
import 'package:flutter_toggle_tab/flutter_toggle_tab.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/auth_controller.dart';
import 'package:sehati_app/shared_in_ui/form_widgets/reactive_text_form.dart';
import 'package:get/get.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_anim.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_fonts.dart';

class CompleteRegisterForm extends StatelessWidget {
  CompleteRegisterForm({Key? key, this.controller}) : super(key: key);
  final AuthController? controller;
  final FocusNode _focusNode = FocusNode();


  final double paddingHeight = 25.0;



  final OutlineInputBorder outlineInputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.all(
        Radius.circular(25)),
    borderSide: BorderSide(
        color:
        AppColors.registerFiled)
    ,
  );

  // FormGroup buildForm() =>
  //     fb.group(<String, Object>{
  //
  //       'location': FormControl<String>(
  //         value:  controller!.addressController.text,
  //         validators: [Validators.required, ],
  //       ),
  //
  //
  //       'ssn': FormControl<String>(
  //         validators: [Validators.required, Validators.number],
  //       ),
  //       'mobile': FormControl<String>(
  //         validators: [Validators.required, Validators.number],
  //       ),
  //
  //       // 'marital_status': FormControl<String>(
  //       //   validators: [
  //       //     Validators.required,
  //       //   ],
  //       // ),
  //       'gender': FormControl<String>(
  //         validators: [
  //           Validators.required,
  //         ],
  //       ),
  //       'dob': FormControl<DateTime>(value: null),
  //       'rememberMe': false,
  //     });

  final listItems = ['Single', 'Married', 'Widowed', 'Divorced', 'Separated'];
  final TextStyle style =
  Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.white));
  FormGroup buildForm2() =>
      fb.group(<String, Object>{

        'location': FormControl<String>(
           value:  controller!.addressController.text,
        ),


        'ssn': FormControl<String>(
          validators: [Validators.required, Validators.number],
        ),
        'dob': FormControl<DateTime>(value: null),


        // 'marital_status': FormControl<String>(
        //   validators: [
        //     Validators.required,
        //   ],
        // ),
        // 'gender': FormControl<String>(
        //   validators: [
        //     Validators.required,
        //   ],
        // ),
        'rememberMe': false,
      });
  final labelStyle = TextStyle(
      color: AppColors.black54, fontWeight: FontWeight.bold, fontSize: 13,fontFamily: AppFonts.mainFontFamily);


  @override
  Widget build(BuildContext context) {



    return GetBuilder<AuthController>(builder: (controller) {
      return Stack(
        children: [
          ReactiveFormBuilder(
            form:buildForm2,
            builder: (context, form, child) {

              final formControl = form.control('location');
              formControl.value = controller.resultLocation;
              formControl.markAsTouched();// if newName is invalid then validation messages will show up in UI

              return Column(
                children: [



                  Row(
                    children: [
                      Expanded(child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(AppStrings.almostDone.tr,style: Get.textTheme.headline6!.merge(TextStyle(color: AppColors.black)),),
SizedBox(height: 5,),
                            Text(AppStrings.fillRequiredInformation.tr,style: Get.textTheme.subtitle2!.merge(TextStyle(color: AppColors.blackTxt2)),),
                          ],
                        ),
                      )),
                    ],
                  ),
                  SizedBox(height: 30,),


                  Theme(
                    data: ThemeData.light().copyWith(

                      primaryColor: AppColors.primaryColor,
                      colorScheme: ColorScheme.light(primary: AppColors.primaryColor),
                     textTheme: Get.textTheme

                    ),
                    child: ReactiveDatePicker<DateTime>(
                      formControlName: 'dob',

                      firstDate: DateTime(1920),
                      lastDate: DateTime.now(),

                      builder: (context, picker, child) {


                        return ReactiveTextField(
                          onTap: () {
                            if (_focusNode.canRequestFocus) {
                              _focusNode.unfocus();
                              picker.showPicker();
                            }
                          },
                          style: labelStyle,
                          valueAccessor: DateTimeValueAccessor(
                            dateTimeFormat: DateFormat('dd/MM/yyyy'),
                          ),
                          //  focusNode: _focusNode,
                          formControlName: 'dob',
                          readOnly: true,


                          decoration: InputDecoration(
                            labelText: AppStrings.dob.tr,
                            labelStyle: labelStyle,
                            filled: true,
                            fillColor: AppColors.registerFiled,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 12, vertical: 20),
                            hintText: '',
                            errorStyle: TextStyle(
                                color: Colors.white.withOpacity(0.7)),
                            errorBorder: outlineInputBorder,
                            hintStyle: TextStyle(
                                color: Colors.white.withOpacity(0.7)),
                            prefixIcon: Icon(Icons.date_range_sharp,
                                color: AppColors.primaryColor),
                            border: outlineInputBorder,
                            focusedBorder: outlineInputBorder,
                            enabledBorder: outlineInputBorder,

                          ),
                        );
                      },
                    ),
                  ),


                  SizedBox(height: 10,),


                  Row(
                    children: [

                      Expanded(child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5),
                        child: Text(AppStrings.gender.tr,style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold,color: AppColors.blackTxt),),
                      )),

                      FlutterToggleTab(
                        width: Get.width/6,
                        height: 50,
                        borderRadius: 15,

                        selectedTextStyle: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w600),
                        unSelectedTextStyle: TextStyle(
                            color: AppColors.primaryColor,
                            fontSize: 14,
                            fontWeight: FontWeight.w400),
                        labels: [AppStrings.male.tr, AppStrings.female.tr],
                        icons:const [FontAwesomeIcons.male, FontAwesomeIcons.female],

                        unSelectedBackgroundColors: [AppColors.registerFiled.withOpacity(1)],
                        selectedBackgroundColors:const [AppColors.primaryColor],
                        selectedLabelIndex: (index) {
                          controller.updateGenderIndex(index);
                        },
                        selectedIndex: controller.genderIndex.value,),
                    ],
                  ),

                  SizedBox(height: 5,),


                  Row(children: [
                    Expanded(child:




                      ReactiveTextForm.reactiveTextFieldAuth(
                        formControlName: AppStrings.location.toLowerCase(),

                        validationMessage: AppStrings.locationHint.tr,
                        lable: AppStrings.location.tr,
                        iconData: Icons.location_on,
                        lableStyle: labelStyle,

                        outlineInputBorder: outlineInputBorder
                    ),
                    ),

                    SizedBox(width: 10,),

                    GestureDetector(
                      onTap: ()async{

                        var    resultLocation=await  Get.toNamed(AppRouteNames.map,arguments: AppRouteNames.register);

                        controller.updateLocation(resultLocation);



                        //   controller.getCurrentLocation();


                        //  form.value[AppStrings.location.toLowerCase()]= controller.addressController.text ;

                      },

                      child: Container(
                        height: 50,
                        width: 50,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: AppColors.primaryColor
                        ),

                        child: Icon(Icons.location_on, color: AppColors.white,),


                      ),
                    )

                  ],)


                  ,


                  ReactiveTextForm.reactiveTextFieldAuth(
                    formControlName: 'ssn',
                    isNumber: true,
                    validationMessage: AppStrings.ssnHint.tr,
                    lable: AppStrings.idNo,
                    iconData: Icons.contact_page,
                    lableStyle: labelStyle,


                    outlineInputBorder: outlineInputBorder,

                  ),



                  SizedBox(height: 15,),


                  Ui.primaryButton(title: AppStrings.signUp, onTab: () {






                    if(form.valid){
                    // Get.toNamed(AppRouteNames.successRegister);

                      controller.mapUser.addAll(form.value);
                      controller.mapUser.addAll({'gender':controller.genderIndex.value==0?'Male':'Female'});

                   //   controller.register(controller.registerMap(controller.mapUser));

                   }
                    else{
                      controller.buildFailedSnackBar(msg: AppStrings.fillAllField.tr);

                    }




                  }),


                  SizedBox(
                    height: 30,
                  ),
                ],
              );
            },
          ),
          Positioned.fill(
              top: 20,

              //   right: Get.width*.5,
              child: Align(
                alignment: Alignment.center,
                child: Column(
                  children: [
                    if(controller.isLoading)
                      SizedBox(
                          height: Get.height/4,
                          width: Get.width*.5,
                          child: Lottie.asset(AppAnim.lottieLoading2,


                          )),
                  ],
                ),
              ))

        ],
      );
    });
  }
}
