import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/modules/drawer_module/drawer_widget/main_drawer_widget.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

import '../doctors_controller.dart';

class DoctorDetailsPage extends StatelessWidget {
  const DoctorDetailsPage({this.doctor, Key? key}) : super(key: key);
  final Doctor? doctor;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appointmentBG,
      drawer: MainDrawerWidget(),

      // appBar: AppBar(),
      body: GetBuilder<DoctorsController>(builder: (logic) {
  return SingleChildScrollView(
        child: Column(
          children: [

            Stack(
              children: [

                Container(height: Get.height*.24,
                alignment: Alignment.topCenter,
                padding: EdgeInsets.only(top: Get.height*.08),
                decoration: BoxDecoration(
                  color: AppColors.filedBg,
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                  )
                ),

                  child: Row(
                    children: [
                      Container(
                      padding: EdgeInsets.symmetric(horizontal: 20,vertical: 0),
                      child:                   GestureDetector(
                          onTap: (){
                            Get.back();
                          },
                          child: Icon(Icons.arrow_back_ios_outlined,color: AppColors.white,))
                        ,
                      ),

                      SizedBox(width: Get.width/4.3,),
                      Container(

                      padding: EdgeInsets.symmetric(horizontal: 1,vertical: 0),
                      child:
                      Text(AppStrings.doctorDetails,style: Get.textTheme.headline6!.merge(TextStyle(fontSize: 18,color: AppColors.white)),)
                        ,
                      ),
                    ],
                  ),

                ),

                Stack(
                  children: [
                    Container(
                      //height: 100,
                      padding: EdgeInsets.symmetric(vertical: 10),
                    margin: EdgeInsets.only(top: Get.height*.16,bottom: 50,right: 20,left: 20),
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [BoxShadow(color:AppColors.primaryColor .withOpacity(.3), blurRadius: 3)],
                      ),

                      child: Row(children: [

                        Ui.circluarImg(url: '',size: 60,errorImg: AppImages.doctorImg),



                        Expanded(child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${doctor!.name}',style: Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.filedBg,fontWeight: FontWeight.bold)),),

                            SizedBox(height: 10,),

                            Text('${doctor!.speciality}',style: Get.textTheme.bodyText2!.merge(TextStyle(color: AppColors.black,fontSize: 12)),),
                          ],
                        )),


                      ],),
                    ),


                  ],
                )


              ],
            ),


            Container(
                decoration: BoxDecoration(boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 10,
                      spreadRadius: 1)
                ]),
            ),
UiHelper.verticalSpace(20),

SizedBox(
  height: 40,
  child:   ListView.builder( scrollDirection: Axis.horizontal,itemCount: logic.doctorSlots.length, itemBuilder: (bc,index)=>Container(
    margin: EdgeInsets.symmetric(horizontal: 10),
    padding: EdgeInsets.symmetric(horizontal: 10,vertical: 5),

  decoration: BoxDecoration(

    borderRadius: BorderRadius.circular(20),

    border: Border.all(color: AppColors.primaryColor)

  ),

child: Text(logic.doctorSlots[index]),

  )),
),



//
// Row(children: [
//   SizedBox(width: 20,),
//
//   Expanded(child: card(AppStrings.patients, '50+')),
//   SizedBox(width: 10,),
//
//   Expanded(child: card(AppStrings.experience, '9',years: 'years')),
//   SizedBox(width: 10,),
//
//   Expanded(child: card(AppStrings.rating, '4.5')),
//   SizedBox(width: 20,),
//
//
// ],),
//
//
//             Container(
//               padding: EdgeInsets.symmetric(vertical: 20,horizontal: 20),
//
//               child: Column(children: [
//
//
//               Row(
//                 children: [
//                   Text(AppStrings.aboutDr.tr,style: Get.textTheme.headline3!.merge(TextStyle(fontSize: 16,fontWeight: FontWeight.bold)),),
//                 ],
//               ),
//
//               SizedBox(height: 10,),
//               Row(
//                 children: [
//                   Text(doctor!.speciality.toString(),style: Get.textTheme.subtitle2!.merge(TextStyle(fontSize: 16,fontWeight: FontWeight.bold,color: AppColors.blackTxt2)),),
//                 ],
//               ),
//
//
//             ],),),
//



            Container(
              padding: EdgeInsets.symmetric(vertical: 20,horizontal: 20),

              child: Column(children: [


              // Row(
              //   children: [
              //     Text(AppStrings.map.tr,style: Get.textTheme.headline3!.merge(TextStyle(fontSize: 16,fontWeight: FontWeight.bold)),),
              //
              //
              //   ],
              // ),
              //
              // SizedBox(height: 10,),
              // Row(
              //   children: [
              //     Container(
              //         padding: EdgeInsets.symmetric(horizontal: 5),
              //         child: Image.asset(AppImages.mapPng,fit: BoxFit.fill,width: Get.width-50,))
              //
              //   ],
              // ),
               // SizedBox(height: 35,),


                Ui.primaryButton(title: AppStrings.bookAppointment.tr,onTab: (){
                  Get.toNamed(AppRouteNames.booking,arguments: doctor);

                })

            ],),),




          ],
        ),
      );
}),
    );
  }

  Widget text(BuildContext context, String title, {int flex = 1}) {
    return Expanded(
        flex: flex,
        child: Text(
          title,
          style: Theme.of(context).textTheme.bodyText1,
        ));
  }

  card( String title,String value ,{String years=''}){

    return Card(
      shadowColor: AppColors.primaryColor,
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
padding: EdgeInsets.symmetric(vertical: 30,horizontal: 15),
        child: Column(
          children: [

            Text(title,style: Get.textTheme.subtitle2!.merge(TextStyle(color:AppColors.blackTxt2,fontWeight: FontWeight.bold )),),


            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(value,style: Get.textTheme.headline5!.merge(TextStyle(color: AppColors.primaryColor,fontWeight: FontWeight.bold,fontSize: 30)),),
             if(years.isNotEmpty)   Padding(
               padding: const EdgeInsets.symmetric(horizontal: 10),
               child: Text(years,style: Get.textTheme.headline5!.merge(TextStyle(color: AppColors.primaryColor,fontSize: 15,fontWeight: FontWeight.bold)),),
             ),
              ],
            ),

          ],
        ),
      ),
    );



  }

  TimeOfDay stringToTimeOfDay(String tod) {
    final format = DateFormat.j(); //"6:00 AM"
    return TimeOfDay.fromDateTime(format.parse(tod));
  }
}
