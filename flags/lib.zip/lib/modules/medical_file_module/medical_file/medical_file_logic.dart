import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';

class MedicalFileLogic extends GetxController {


  List<HomeService>  services=[

    HomeService(id: 1,name: AppStrings.prescriptionList,icon: AppImages.iconMedicineList,route: AppRouteNames.radiologyLabFiles,primary: true),
    HomeService(id: 1,name: AppStrings.labTests,icon: AppImages.iconLab,route: AppRouteNames.radiologyLabFiles,primary: true,code: 'L'),
    HomeService(id: 1,name: AppStrings.medFileReport,icon: AppImages.iconMedicalReport,route: AppRouteNames.radiologyLabFiles,primary: true),
    HomeService(id: 1,name: AppStrings.medFileImageTest,icon: AppImages.iconXRay,route:AppRouteNames. radiologyLabFiles,primary: true,code: 'X'),



  ];

}
