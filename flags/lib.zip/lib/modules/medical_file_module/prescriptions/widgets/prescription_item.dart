
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_prescription.dart';
import 'package:sehati_app/modules/medical_file_module/prescriptions/views/prescription_details.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

class PrescriptionItem extends StatelessWidget {
  const PrescriptionItem({this.prescription,Key? key}) : super(key: key);

 final Prescription? prescription;

  @override
  Widget build(BuildContext context) {
//    final DateFormat dateFormat = DateFormat("dd-MMM-yyyy HH:mm a");

    return ListTile(
contentPadding: EdgeInsets.zero,

      onTap: (){

        // Navigator.push(context, MaterialPageRoute(builder: (bc)=>PrescriptionDetails(prescription: prescription,)));

      },
      title: Stack(
        fit: StackFit.loose,
        children: [




          Column(
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                margin: EdgeInsets.only(top: 10),
                decoration: BoxDecoration(
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(.1), blurRadius: 3)], color: AppColors.primaryColor, borderRadius: BorderRadius.circular(30.0)),
                child: Column(children: [

                  Row(children: [

                    Ui.circluarImg(url: '',size: 60,errorImg: AppImages.doctorImg),



                    Expanded(child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${prescription!.doctor}',style: Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.white,fontWeight: FontWeight.bold)),),

                        SizedBox(height: 10,),

                        Text('${prescription!.name}',style: Get.textTheme.bodyText2!.merge(TextStyle(color: AppColors.white,fontSize: 12)),),
                      ],
                    )),


                  ],),

                 // SizedBox(height: 10,),
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
                    margin: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        color: AppColors.filedBg,
                        borderRadius: BorderRadius.circular(10)
                    ),

                    child: Row(children: [

                      Icon(Icons.home,color: AppColors.white,),
                      SizedBox(width: 10,),
                   //   Expanded(child: Text('${prescription!.doctor}',style: Get.textTheme.subtitle1,)),
                      Expanded(child: Text(AppStrings.appOwner.tr,style: Get.textTheme.subtitle1!.merge(TextStyle(fontSize: 13)),)),


                    ],),
                  ),

                ],)


                ,
              ),

              Container(
                height: 10,
                margin: EdgeInsets.symmetric(horizontal: 26,vertical: 0),
                decoration: BoxDecoration(
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(.1), blurRadius: 3)], color: AppColors.primaryColor.withOpacity(.5),
                    borderRadius:
                    BorderRadius  .only(bottomLeft: Radius.circular(100),bottomRight: Radius.circular(100))),

              ),
              Container(
                height: 10,
                margin: EdgeInsets.symmetric(horizontal: 38,vertical: 0),
                decoration: BoxDecoration(
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(.1), blurRadius: 3)], color: AppColors.registerFiled,
                    borderRadius:
                    BorderRadius  .only(bottomLeft: Radius.circular(100),bottomRight: Radius.circular(100))),

              ),

            ],
          ),

          Positioned(
              top: 25,
            //  left: 10,
              right: 15,
              child: GestureDetector(
                  onTap: (){
                    Get.to(PrescriptionDetails(prescription: prescription,));

                  },

                  child: SvgPicture.asset(AppImages.arrow,width: 25,height: 25,)))

        ],
      ),
    );







  }
}
