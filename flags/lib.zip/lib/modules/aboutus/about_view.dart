import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/about_model.dart';
import 'package:sehati_app/modules/aboutus/widgets/about_item.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'about_logic.dart';

class AboutPage extends StatelessWidget {
  final AboutLogic logic = Get.put(AboutLogic());

   AboutPage({Key? key}) : super(key: key);



  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: Column(children: [

      myAppBar2(title: AppStrings.about),

      Expanded(child: SingleChildScrollView(
        child: Wrap(
          children: [

            ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: AboutModel.aboutList.length,
                itemBuilder: (bc,index)=>AnimationConfiguration.staggeredList(
                    position: index,
                    duration: Duration(milliseconds:500 ),

                    child: SlideAnimation(
                        verticalOffset: 100,
                        duration: Duration(milliseconds: 500),
                        child: AboutItem(aboutModel: AboutModel.aboutList[index],))
                )),
            Column(
              children: [
                UiHelper.verticalSpaceMedium,

                Image.asset(AppImages.logoSvg,width: 100,height: 100,),
                UiHelper.verticalSpaceSmall,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(AppStrings.appVersion,style: AppStyles.primaryStyle(bold: true,size: 13,opacity: .7),),
                  ],
                ),
                UiHelper.verticalSpaceLarge,
              ],
            )

          ],
        ),
      )),


    ],));
  }
}
