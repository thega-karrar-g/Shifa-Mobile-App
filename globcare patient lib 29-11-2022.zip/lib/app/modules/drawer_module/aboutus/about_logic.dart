import '../../../base_controller/base_controller.dart';

class AboutLogic extends BaseController {}
