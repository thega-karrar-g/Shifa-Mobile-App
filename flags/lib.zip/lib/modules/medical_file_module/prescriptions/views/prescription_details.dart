import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_prescription.dart';
import 'package:sehati_app/modules/medical_file_module/prescriptions/widgets/medicine_item.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';

class PrescriptionDetails extends StatelessWidget {
   PrescriptionDetails({this.prescription, Key? key}) : super(key: key);
  final Prescription? prescription;
  bool  ar=Get.locale.toString()=='ar';


   @override
   Widget build(BuildContext context) {
     return Ui.myScaffold(child: Column(
       children: [


         myAppBar2(title: AppStrings.prescriptionDetails.tr),


         Expanded(
           child: ListView.builder(
               padding: EdgeInsets.symmetric(vertical: 0),
               physics: NeverScrollableScrollPhysics(),
               itemCount: prescription!.prescriptionLines.length,
               itemBuilder: (bc,index)=>MedicineItem(prescriptionLine: prescription!.prescriptionLines[index],primary: index%2==1,)),
         ),


       ],
     ));
  }

  Widget text(BuildContext context, String title, {int flex = 1}) {
    return Expanded(
        flex: flex,
        child: Text(
          title,
          style: Theme.of(context).textTheme.bodyText1,
        ));
  }
}
