import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/insurance.dart';
import 'package:sehati_app/modules/booking_home_modules/appointment_base_controllers/appointment_base_controller.dart';
import 'package:sehati_app/repositories/insurance_repository.dart';

class InsuranceLogic extends BaseController {


  Insurance? selectedCompany;

  final  InsuranceRepository _insuranceRepository=InsuranceRepository();

  List<Insurance> items=[

  ];



  updateCompany(Insurance selected){



    selectedCompany=selected;
    update();
  }
  bool  isLoad=false;
  isLoading(bool load){
    isLoad=load;
    update();

  }



  @override
  void onInit() async{
    // TODO: implement onInit
    super.onInit();
    setBusy(true);
    items=await  _insuranceRepository.getInsuranceList();
    setBusy(false);

  }





  makeBookingWithFileDio()async{

    final  AppointmentBaseController appointmentBaseController=AppointmentBaseController();


    appointmentBaseController.makeBookingWithFileDio();



  }




}



