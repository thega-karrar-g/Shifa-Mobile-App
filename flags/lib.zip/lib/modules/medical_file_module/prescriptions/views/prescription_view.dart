import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_prescription.dart';
import 'package:sehati_app/modules/medical_file_module/prescriptions/widgets/prescription_list.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';

import '../../../../shared_in_ui/shared/loading.dart';
import '../prescription_controller.dart';

class PrescriptionsPage extends GetView<PrescriptionController> {
  // final controller = Get.find<DoctorsController>();
  @override
  final controller = Get.put(PrescriptionController());

  PrescriptionsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: Column(
      children: [
        myAppBar2(title: AppStrings.prescriptionList),


        Expanded(
          child: FutureBuilder<List<Prescription>>(
            future: controller.getPrescription(),
            builder: (bc, snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                return PrescriptionList(
                  prescriptions: snapshot.data??[],
                );
              } else if (snapshot.connectionState ==
                  ConnectionState.waiting) {
                return Center(child: MyLoadingWidget());
              }

              return Container();
            },
          ),
        ),
      ],
    ));
  }


}
