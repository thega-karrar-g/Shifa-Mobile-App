
class NotificationModel {
  NotificationModel({
    this.id=0,
    this.name='',
    this.description='',this.date='',this.readed=false
  });

  int id;
  String name='',description='',date='';
  bool  readed=false;


  factory NotificationModel.fromJson(Map<String, dynamic> json) => NotificationModel(
    id: json['id'] ??0,
    name: json['name']??'',
    description: json['description']??'',
    date: json['date']??'',

  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "description": description,
    "date": date,

  };

  static List<NotificationModel>  notifications=[

    NotificationModel(id: 1,name: 'Kristine Jones',description: 'It is a long established fact that a reader will be distracted by the readable content of a page.',date: '2 hours ago'),
    NotificationModel(id: 1,name: 'Kay Hicks',description: 'There are many variations of passages of Lorem Ipsum available.',date: '6 hours ago'),
    NotificationModel(id: 1,name: 'Cheryl Moretti',description: 'It is a long established fact that a reader will be distracted by the readable content of a page.',date: '1 day ago',readed: true),
    NotificationModel(id: 1,name: 'Kristine Jones',description: 'It is a long established fact that a reader will be distracted by the readable content of a page.',date: '3 days ago',),
    NotificationModel(id: 1,name: 'Cheryl Moretti',description: 'It is a long established fact that a reader will be distracted by the readable content of a page.',date: '1 day ago'),


  ];

}

