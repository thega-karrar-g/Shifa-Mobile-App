import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/booking_home_modules/pcr/fill_data/widgets/form_item.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';

import 'fill_data_logic.dart';

class FillDataPage extends StatelessWidget {
  final FillDataLogic logic = Get.put(FillDataLogic());

   FillDataPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: Column(children: [
      myAppBar2(title: AppStrings.fillData),

      Expanded(
        child: GetBuilder<FillDataLogic>(builder: (logic) {
          return ListView.builder(
              itemCount: logic.patients.length,
              itemBuilder: (bc, index) =>
                  FormItem(patient: logic.patients[index], logic: logic,key: UniqueKey(),));
        }),
      ),
      UiHelper.verticalSpaceMedium,

      Ui.primaryButton(title: AppStrings.continueTo,onTab: (){

        logic.navToNext();

       // DifferentDialog.showCompleteDataDialog();
        //   Get.toNamed(AppRouteNames.patientData);

      })


    ],));
  }
}
