import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/slides_model.dart';
import 'package:sehati_app/modules/booking_home_modules/appointment_base_controllers/appointment_base_controller.dart';
import 'package:sehati_app/services/firebase_services.dart';
import 'package:sehati_app/shared_in_ui/shared/different_dialogs.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
import 'package:sehati_app/utils/launcher.dart';
import 'package:showcaseview/showcaseview.dart';

import '../../base_controller/base_controller.dart';

GetStorage box = GetStorage();
final GlobalKey languageKey = GlobalKey();
final GlobalKey infoKey = GlobalKey();

final ar = Get.locale.toString() == 'ar';

Widget myAppBar({String title = '', double h = 40, Color color = AppColors
    .white, withBack = true}) {
  return Container(
    //  color: color,
    margin: EdgeInsets.only(top: h, bottom: 20),
    child: Row(children: [
      SizedBox(width: Get.width * .08,),
      if(withBack)
        GestureDetector(
            onTap: () => Get.back(),
            child: Icon(
              Icons.arrow_back_ios_outlined, color: AppColors.primaryColor,)),
      SizedBox(width: Get.width * .1,),

      Expanded(
          child: Text(title.tr, style: Get.textTheme.subtitle1!.merge(TextStyle(
              color: AppColors.black, fontWeight: FontWeight.bold)),)),

    ],),
  );
}

Widget myAppBar2({String title = '', double h = 20, Color color = AppColors
    .white, withBack = true, bool isHome = false, bool showAll = false}) {
  //
  // var t=title.tr.toUpperCase().split(' ');
  //
  //  var newTitle='';
  //
  //  if(showAll){
  //    for (var element in t) {
  //      if(element!=t.last) {
  //        newTitle += '' + element + ' ';
  //      }
  //    }
  //
  //
  //  }
  //  else{
  //    newTitle=t.first;
  //
  //    if(t.length>2){
  //    newTitle+=' '+t[1];
  //  }
  //    if(!isHome){
  //     // newTitle+='\n'+t.last;
  //    }
  //  }
  //

  return Column(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        //  color: color,
        margin: EdgeInsets.only(top: h, bottom: isHome ? 0 : 5),
        child: Row(children: [
          // SizedBox(width: Get.width*.08,),
          if(withBack)
            GestureDetector(
                onTap: () => Get.back(),
                child: RotatedBox(
                    quarterTurns: Get.locale.toString() == 'ar' ? 2 : 0,
                    child: SvgPicture.asset(AppImages.back))),

          if(isHome) Image.asset(
            AppImages.logoSvg, width: 50, height: 50,)
          ,


          Spacer(),


          GestureDetector(
              onTap: () {
                Get.toNamed(AppRouteNames.language);
              }
              ,
              //  onTap: ()=>Get.back(),
              child: Icon(
                Icons.language, color: AppColors.primaryColor,)),
          UiHelper.horizontalSpaceLarge,

          GestureDetector(
              onTap: () {
                //  Get.to(PaymentWebviewPage());
                //BookInvoiceLogic().performtrxn();
                //AppointmentBaseController().performtrxn(transType: 'applepay',orderId: '121');
                AppointmentBaseController().soonMessage();

                // Get.toNamed(AppRouteNames.notifications);
              }
              ,
              //  onTap: ()=>Get.back(),
              child: SvgPicture.asset(AppImages.notification)),
          UiHelper.horizontalSpaceLarge,


          //  UiHelper.horizontalSpaceLarge,

          Builder(
              builder: (context) {
                return GestureDetector(
                    onTap: () => Scaffold.of(context).openDrawer(),
                    child: SvgPicture.asset(AppImages.menu));
              }
          ),

        ],),
      ),

      Row(children: [

        Expanded(
          child: Padding(
            padding: EdgeInsets.only(top: isHome ? 0 : 5, bottom: 5),
            child: Row(
              children: [


                if(!isHome)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          IntrinsicWidth(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment
                                  .start,
                              crossAxisAlignment: CrossAxisAlignment
                                  .start,
                              children: [
                                Text(title.tr, maxLines: 2,
                                  style: AppStyles.primaryStyle(
                                      size: 20,
                                      bold: true,
                                      height: ar ? 1.3 : 1.0),),

                                // Text(t.last,maxLines: 2,style: AppStyles.primaryStyle(size: 20,bold: true,height: ar?1.3:1.0),),
                                // UiHelper.verticalSpace(5),

                                Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        margin: EdgeInsets.only(top: 5),
                                        height: 5,
                                        //  width: Get.width*.3,
                                        decoration: BoxDecoration(
                                            color: AppColors
                                                .primaryColorGreen,
                                            borderRadius: BorderRadius
                                                .circular(20)),
                                      ),
                                    ),
                                  ],
                                ),
                                UiHelper.verticalSpace(5),

                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                // if(isHome)
                //
                //   Text(' , ',maxLines: 2,style: AppStyles.primaryStyle(size: 30,bold: true),),

                if(!isHome)
                  UiHelper.verticalSpaceSmall,

                // if(isHome)
                // Text(AppStrings.haveNiceDay.tr,maxLines: 2,style: AppStyles.subTitleStyle(size: 20,),),


              ],
            ),
          ),
        ),
      ],),

      if(withBack && !isHome)

        UiHelper.verticalSpaceSmall,

    ],
  );

}
Widget myAppBarPayment({String title = '', double h = 20, Color color = AppColors
    .white, withBack = true, bool isHome = false, bool showAll = false}) {
  //
  // var t=title.tr.toUpperCase().split(' ');
  //
  //  var newTitle='';
  //
  //  if(showAll){
  //    for (var element in t) {
  //      if(element!=t.last) {
  //        newTitle += '' + element + ' ';
  //      }
  //    }
  //
  //
  //  }
  //  else{
  //    newTitle=t.first;
  //
  //    if(t.length>2){
  //    newTitle+=' '+t[1];
  //  }
  //    if(!isHome){
  //     // newTitle+='\n'+t.last;
  //    }
  //  }
  //

  return Column(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        //  color: color,
        margin: EdgeInsets.only(top: h, bottom: isHome ? 0 : 5),
        child: Row(children: [
          // SizedBox(width: Get.width*.08,),
          if(withBack)
            GestureDetector(
                onTap: () => Get.back(),
                child: RotatedBox(
                    quarterTurns: Get.locale.toString() == 'ar' ? 2 : 0,
                    child: SvgPicture.asset(AppImages.back))),

          if(isHome) Image.asset(
            AppImages.logoSvg, width: 50, height: 50,)
          ,


          Spacer(),


          GestureDetector(
              onTap: () {
                Get.toNamed(AppRouteNames.language);
              }
              ,
              //  onTap: ()=>Get.back(),
              child: Icon(
                Icons.language, color: AppColors.primaryColor,)),
          UiHelper.horizontalSpaceLarge,

          GestureDetector(
              onTap: () {
                //  Get.to(PaymentWebviewPage());
                //BookInvoiceLogic().performtrxn();
                //AppointmentBaseController().performtrxn(transType: 'applepay',orderId: '121');
                AppointmentBaseController().soonMessage();

                // Get.toNamed(AppRouteNames.notifications);
              }
              ,
              //  onTap: ()=>Get.back(),
              child: SvgPicture.asset(AppImages.notification)),
          UiHelper.horizontalSpaceLarge,


          //  UiHelper.horizontalSpaceLarge,

          Builder(
              builder: (context) {
                return GestureDetector(
                    onTap: () => Scaffold.of(context).openDrawer(),
                    child: SvgPicture.asset(AppImages.menu));
              }
          ),

        ],),
      ),

      Row(children: [

        Expanded(
          child: Padding(
            padding: EdgeInsets.only(top: isHome ? 0 : 5, bottom: 5),
            child: Row(
              children: [


                if(!isHome)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          IntrinsicWidth(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment
                                  .start,
                              crossAxisAlignment: CrossAxisAlignment
                                  .start,
                              children: [
                                Text(title.tr, maxLines: 2,
                                  style: AppStyles.primaryStyle(
                                      size: 20,
                                      bold: true,
                                      height: ar ? 1.3 : 1.0),),

                                // Text(t.last,maxLines: 2,style: AppStyles.primaryStyle(size: 20,bold: true,height: ar?1.3:1.0),),
                                // UiHelper.verticalSpace(5),

                                Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        margin: EdgeInsets.only(top: 5),
                                        height: 5,
                                        //  width: Get.width*.3,
                                        decoration: BoxDecoration(
                                            color: AppColors
                                                .primaryColorGreen,
                                            borderRadius: BorderRadius
                                                .circular(20)),
                                      ),
                                    ),
                                  ],
                                ),
                                UiHelper.verticalSpace(5),

                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                // if(isHome)
                //
                //   Text(' , ',maxLines: 2,style: AppStyles.primaryStyle(size: 30,bold: true),),

                if(!isHome)
                  UiHelper.verticalSpaceSmall,

                // if(isHome)
                // Text(AppStrings.haveNiceDay.tr,maxLines: 2,style: AppStyles.subTitleStyle(size: 20,),),


              ],
            ),
          ),
        ),
      ],),

      if(withBack && !isHome)

        UiHelper.verticalSpaceSmall,

    ],
  );

}


Widget myAppBarHome({String title = '', double h = 20, Color color = AppColors
    .white, withBack = true, bool isHome = false, bool showAll = false}) {
  //
  // var t=title.tr.toUpperCase().split(' ');
  //
  //  var newTitle='';
  //
  //  if(showAll){
  //    for (var element in t) {
  //      if(element!=t.last) {
  //        newTitle += '' + element + ' ';
  //      }
  //    }
  //
  //
  //  }
  //  else{
  //    newTitle=t.first;
  //
  //    if(t.length>2){
  //    newTitle+=' '+t[1];
  //  }
  //    if(!isHome){
  //     // newTitle+='\n'+t.last;
  //    }
  //  }
  //

  return ShowCaseWidget(
      builder: Builder(builder: (context) {
        if (box.read('langHint') == null) {
          WidgetsBinding.instance!.addPostFrameCallback((_) =>
              ShowCaseWidget.of(context)!
                  .startShowCase([languageKey]));

          box.write('langHint', true);
        }
        return Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              //  color: color,
              margin: EdgeInsets.only(top: h, bottom: isHome ? 0 : 5),
              child: Row(children: [
                // SizedBox(width: Get.width*.08,),
                if(withBack)
                  GestureDetector(
                      onTap: () => Get.back(),
                      child: RotatedBox(
                          quarterTurns: Get.locale.toString() == 'ar' ? 2 : 0,
                          child: SvgPicture.asset(AppImages.back))),

                if(isHome) Image.asset(
                  AppImages.logoSvg, width: 50, height: 50,)
                ,


                Spacer(),

                GestureDetector(
                    onTap: () {
                      Launcher.phoneCall(AppStrings.contactUsNo);
                    //  Get.toNamed(AppRouteNames.receiptPage);
                    }
                    ,
                    //  onTap: ()=>Get.back(),
                    child: Image.asset(AppImages.hotLine,width: 30,height: 30,)),
                UiHelper.horizontalSpaceLarge,

                Showcase(
                  description: AppStrings.languageHint.tr,
                  descTextStyle: AppStyles.primaryStyle(),
                  radius: BorderRadius.circular(30),
                  overlayPadding: EdgeInsets.all(15),
                  key: languageKey,
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 5, vertical: 20),
                  child: GestureDetector(
                      onTap: () {
                        Get.toNamed(AppRouteNames.language);
                      }
                      ,
                      //  onTap: ()=>Get.back(),
                      child: Icon(
                        Icons.language, color: AppColors.primaryColor,)),
                ),
                UiHelper.horizontalSpaceLarge,

                GestureDetector(
                    onTap: () {
                      //  Get.to(PaymentWebviewPage());
                      //BookInvoiceLogic().performtrxn();
                      //AppointmentBaseController().performtrxn(transType: 'applepay',orderId: '121');
                      AppointmentBaseController().soonMessage();

              //       FireBaseService.sendPhoneNumberCode(phoneNumber: '+967716371395');
                     // FireBaseService.sendPhoneNumberCode(phoneNumber: '+967771414753');
                      // Get.toNamed(AppRouteNames.notifications);
                    }
                    ,
                    //  onTap: ()=>Get.back(),
                    child: SvgPicture.asset(AppImages.notification)),
                UiHelper.horizontalSpaceLarge,


                //  UiHelper.horizontalSpaceLarge,

                Builder(
                    builder: (context) {
                      return GestureDetector(
                          onTap: () => Scaffold.of(context).openDrawer(),
                          child: SvgPicture.asset(AppImages.menu));
                    }
                ),

              ],),
            ),

            Row(children: [

              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(top: isHome ? 0 : 5, bottom: 5),
                  child: Row(
                    children: [


                      if(!isHome)
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [

                                IntrinsicWidth(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    children: [
                                      Text(title.tr, maxLines: 2,
                                        style: AppStyles.primaryStyle(size: 20,
                                            bold: true,
                                            height: ar ? 1.3 : 1.0),),

                                      // Text(t.last,maxLines: 2,style: AppStyles.primaryStyle(size: 20,bold: true,height: ar?1.3:1.0),),
                                      // UiHelper.verticalSpace(5),

                                      Row(
                                        children: [
                                          Expanded(
                                            child: Container(
                                              margin: EdgeInsets.only(top: 5),
                                              height: 5,
                                              //  width: Get.width*.3,
                                              decoration: BoxDecoration(
                                                  color: AppColors
                                                      .primaryColorGreen,
                                                  borderRadius: BorderRadius
                                                      .circular(20)),
                                            ),
                                          ),
                                        ],
                                      ),
                                      UiHelper.verticalSpace(5),

                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                      // if(isHome)
                      //
                      //   Text(' , ',maxLines: 2,style: AppStyles.primaryStyle(size: 30,bold: true),),

                      if(!isHome)
                        UiHelper.verticalSpaceSmall,

                      // if(isHome)
                      // Text(AppStrings.haveNiceDay.tr,maxLines: 2,style: AppStyles.subTitleStyle(size: 20,),),


                    ],
                  ),
                ),
              ),
            ],),

            if(withBack && !isHome)

              UiHelper.verticalSpaceSmall,

          ],
        );
      })
  );
}

Widget myAppBarLocation(
    {String title = '', double h = 20, Color color = AppColors
        .white, withBack = true, bool isHome = false, bool showAll = false}) {
  //
  // var t=title.tr.toUpperCase().split(' ');
  //
  //  var newTitle='';
  //
  //  if(showAll){
  //    for (var element in t) {
  //      if(element!=t.last) {
  //        newTitle += '' + element + ' ';
  //      }
  //    }
  //
  //
  //  }
  //  else{
  //    newTitle=t.first;
  //
  //    if(t.length>2){
  //    newTitle+=' '+t[1];
  //  }
  //    if(!isHome){
  //     // newTitle+='\n'+t.last;
  //    }
  //  }
  //

  return Column(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        //  color: color,
        margin: EdgeInsets.only(top: h, bottom: isHome ? 0 : 5),
        child: Row(children: [
          // SizedBox(width: Get.width*.08,),
          if(withBack)
            GestureDetector(
                onTap: () => Get.back(),
                child: RotatedBox(
                    quarterTurns: Get.locale.toString() == 'ar' ? 2 : 0,
                    child: SvgPicture.asset(AppImages.back))),

          if(isHome) Image.asset(AppImages.logoSvg, width: 50, height: 50,)
          ,


          Spacer(),


          // Showcase(
          //   description: AppStrings.languageHint.tr,
          //   descTextStyle:AppStyles.primaryStyle(),
          //   radius: BorderRadius.circular(30),
          //   overlayPadding: EdgeInsets.all(15),
          //   key: languageKey,
          //   contentPadding: EdgeInsets.symmetric(horizontal: 5,vertical: 20),
          //   child: GestureDetector(
          //       onTap: (){
          //
          //
          //
          //         Get.toNamed(AppRouteNames.language);
          //       }
          //       ,
          //       //  onTap: ()=>Get.back(),
          //       child: Icon(Icons.language,color: AppColors.primaryColor,)),
          // ),
          // UiHelper.horizontalSpaceLarge,

          GestureDetector(
              onTap: () {
                //  Get.to(PaymentWebviewPage());
                //BookInvoiceLogic().performtrxn();
                //AppointmentBaseController().performtrxn(transType: 'applepay',orderId: '121');
                AppointmentBaseController().soonMessage();

                // Get.toNamed(AppRouteNames.notifications);
              }
              ,
              //  onTap: ()=>Get.back(),
              child: SvgPicture.asset(AppImages.notification)),
          UiHelper.horizontalSpaceLarge,


          //  UiHelper.horizontalSpaceLarge,

          Builder(
              builder: (context) {
                return GestureDetector(
                    onTap: () => Scaffold.of(context).openDrawer(),
                    child: SvgPicture.asset(AppImages.menu));
              }
          ),

        ],),
      ),

      Row(children: [

        Expanded(
          child: Padding(
            padding: EdgeInsets.only(top: isHome ? 0 : 5, bottom: 5),
            child: Row(
              children: [


                if(!isHome)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          IntrinsicWidth(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(title.tr, maxLines: 2,
                                  style: AppStyles.primaryStyle(size: 20,
                                      bold: true,
                                      height: ar ? 1.3 : 1.0),),

                                // Text(t.last,maxLines: 2,style: AppStyles.primaryStyle(size: 20,bold: true,height: ar?1.3:1.0),),
                                // UiHelper.verticalSpace(5),

                                Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        margin: EdgeInsets.only(top: 5),
                                        height: 5,
                                        //  width: Get.width*.3,
                                        decoration: BoxDecoration(
                                            color: AppColors.primaryColorGreen,
                                            borderRadius: BorderRadius.circular(
                                                20)),
                                      ),
                                    ),
                                  ],
                                ),
                                UiHelper.verticalSpace(5),

                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                // if(isHome)
                //
                //   Text(' , ',maxLines: 2,style: AppStyles.primaryStyle(size: 30,bold: true),),

                if(!isHome)
                  UiHelper.verticalSpaceSmall,

                // if(isHome)
                // Text(AppStrings.haveNiceDay.tr,maxLines: 2,style: AppStyles.subTitleStyle(size: 20,),),


              ],
            ),
          ),
        ),
      ],),

      if(withBack && !isHome)

        UiHelper.verticalSpaceSmall,

    ],
  );
}

Widget myAppBarServices(
    {String title = '', double h = 20, Color color = AppColors
        .white, withBack = true, bool isHome = false, bool showAll = false, String code = ''}) {
  var t = title.tr.toUpperCase().split(' ');
  var newTitle = '';


  if (showAll) {
    for (var element in t) {
      if (element != t.last) {
        newTitle += '' + element + ' ';
      }
    }
  }
  else {
    newTitle = t.first;

    if (t.length > 2) {
      newTitle += ' ' + t[1];
    }
    if (!isHome) {
      // newTitle+='\n'+t.last;
    }
  }


  return ShowCaseWidget(
      builder: Builder(builder: (context) {
        if (box.read('infoHint') == null) {
          WidgetsBinding.instance!.addPostFrameCallback((_) =>
              ShowCaseWidget.of(context)!
                  .startShowCase([infoKey]));

          box.write('infoHint', true);
        }
        return Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              //  color: color,
              margin: EdgeInsets.only(top: h, bottom: isHome ? 0 : 5),
              child: Row(children: [
                // SizedBox(width: Get.width*.08,),
                if(withBack)
                  GestureDetector(
                      onTap: () => Get.back(),
                      child: RotatedBox(
                          quarterTurns: Get.locale.toString() == 'ar' ? 2 : 0,
                          child: SvgPicture.asset(AppImages.back))),

                if(isHome) Image.asset(
                  AppImages.logoSvg, width: 50, height: 50,)
                ,


                Spacer(),


                GestureDetector(
                    onTap: (){



                      Get.toNamed(AppRouteNames.language);
                    }
                    ,
                    //  onTap: ()=>Get.back(),
                    child: Icon(Icons.language,color: AppColors.primaryColor,size: 30,)),
                UiHelper.horizontalSpaceLarge,

                Showcase(
                  description: AppStrings.infoHint.tr,
                  descTextStyle: AppStyles.primaryStyle(),
                  radius: BorderRadius.circular(30),
                  overlayPadding: EdgeInsets.all(15),
                  key: infoKey,
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 5, vertical: 20),
                  child: GestureDetector(
                      onTap: () {
                        //  Get.to(PaymentWebviewPage());
                        //BookInvoiceLogic().performtrxn();
                        //AppointmentBaseController().performtrxn();

                        var slide = Slide.slides
                            .where((element) => element.code == code,)
                            .first;
                        print(slide.title);
                        DifferentDialog.showServiceInfoSnackBar(
                            description: slide.description!.tr, title: slide
                            .title!.tr, image: slide.image!);
                        // Get.toNamed(AppRouteNames.notifications);
                      }
                      ,
                      //  onTap: ()=>Get.back(),
                      child: SvgPicture.asset(
                        AppImages.info, color: AppColors.primaryColor,
                        height: 33,
                        width: 33,)),
                ),
                UiHelper.horizontalSpaceLarge,


                //  UiHelper.horizontalSpaceLarge,

                Builder(
                    builder: (context) {
                      return GestureDetector(
                          onTap: () => Scaffold.of(context).openDrawer(),
                          child: SvgPicture.asset(AppImages.menu));
                    }
                ),

              ],),
            ),

            Row(children: [

              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(top: isHome ? 0 : 5, bottom: 5),
                  child: Row(
                    children: [


                      if(!isHome)
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                //   Text(newTitle,maxLines: 2,style: AppStyles.primaryStyle(size: 20,bold: true,height: ar?1.3:1.0),),

                                //  UiHelper.verticalSpace(5),
                                IntrinsicWidth(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    children: [
                                      Text(title.tr, maxLines: 2,
                                        style: AppStyles.primaryStyle(size: 20,
                                            bold: true,
                                            height: ar ? 1.3 : 1.0),),
                                      UiHelper.verticalSpace(5),

                                      Row(
                                        children: [
                                          Expanded(
                                            child: Container(
                                              margin: EdgeInsets.only(top: 5),
                                              height: 5,
                                              //  width: Get.width*.3,
                                              decoration: BoxDecoration(
                                                  color: AppColors
                                                      .primaryColorGreen,
                                                  borderRadius: BorderRadius
                                                      .circular(20)),
                                            ),
                                          ),
                                        ],
                                      ),
                                      UiHelper.verticalSpace(5),

                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                      // if(isHome)
                      //
                      //   Text(' , ',maxLines: 2,style: AppStyles.primaryStyle(size: 30,bold: true),),

                      if(!isHome)
                        UiHelper.verticalSpaceSmall,

                      // if(isHome)
                      // Text(AppStrings.haveNiceDay.tr,maxLines: 2,style: AppStyles.subTitleStyle(size: 20,),),


                    ],
                  ),
                ),
              ),
            ],),

            if(withBack && !isHome)

              UiHelper.verticalSpaceSmall,

          ],
        );
      })
  );
}


Widget myAppBar3({String title = '', double h = 20, Color color = AppColors
    .white, withBack = true, bool isHome = false}) {
  var t = title.tr.toUpperCase().split(' ');
  var newTitle = t.first;

  if (t.length > 1) {
    //newTitle+='\n'+t.last;
  }

  return Column(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        //  color: color,
        margin: EdgeInsets.only(top: h, bottom: 0),
        child: IntrinsicHeight(
          child: Row(

            children: [
              // SizedBox(width: Get.width*.08,),


              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Text(newTitle,maxLines: 2,style: AppStyles.primaryStyle(size: 20,bold: true,height: ar?1.1:1.0),),

                      //UiHelper.verticalSpace(8),
                      IntrinsicWidth(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(title.tr, maxLines: 2,
                              style: AppStyles.primaryStyle(size: 20,
                                  bold: true,
                                  height: ar ? 1.0 : 1.0),),

                            UiHelper.verticalSpace(5),
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    margin: EdgeInsets.only(top: 5),
                                    height: 5,
                                    //  width: Get.width*.3,
                                    decoration: BoxDecoration(
                                        color: AppColors.primaryColorGreen,
                                        borderRadius: BorderRadius.circular(
                                            20)),
                                  ),
                                ),
                              ],
                            ),

                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Column(
                children: [
                  Row(
                    children: [

                      GestureDetector(
                          onTap: () {
                            Get.toNamed(AppRouteNames.language);
                          }
                          ,
                          //  onTap: ()=>Get.back(),
                          child: Icon(
                            Icons.language, color: AppColors.primaryColor,)),
                      UiHelper.horizontalSpaceLarge,

                      GestureDetector(
                          onTap: () {
                            BaseController().soonMessage();

                            //  Get.toNamed(AppRouteNames.notifications);
                          }
                          ,
                          //  onTap: ()=>Get.back(),
                          child: SvgPicture.asset(AppImages.notification)),

                      UiHelper.horizontalSpaceLarge,

                      Builder(
                          builder: (context) {
                            return GestureDetector(
                                onTap: () => Scaffold.of(context).openDrawer(),
                                child: SvgPicture.asset(AppImages.menu));
                          }
                      ),
                    ],
                  ),

                  Spacer()

                ],
              ),

            ],),
        ),
      ),


      UiHelper.verticalSpaceSmall,


    ],
  );
}


class AppBarLogic extends BaseController {

 check(BuildContext context)async{

   setBusy(true);
   if ( box.read('langHint') == null) {
     WidgetsBinding.instance!.addPostFrameCallback((_) =>
         ShowCaseWidget.of(context)!
             .startShowCase([languageKey]));

     box.write('langHint', true);
   }
   setBusy(false);

 }

}
