import 'dart:io';
import 'dart:math';
import 'package:dio/dio.dart' as d;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_image/flutter_native_image.dart';
import 'package:get/get.dart';
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:path/path.dart'  as path;
import 'package:sehati_app/modules/booking_home_modules/appointment_base_controllers/appointment_base_controller.dart';
import 'package:sehati_app/utils/enums.dart';
import '../../../language_and_localization/app_strings.dart';
import '../../../models/m_doctors.dart';
import '../../../models/nurse_service.dart';
import '../../../models/questionnaire.dart';
import '../../../utils/constants/app_route_names.dart';
class PatientDataLogic extends BaseController {


  static bool? fromPatientData;
static TextEditingController patientComment=TextEditingController();
  final ImagePicker _picker = ImagePicker();

  List<PlatformFile> files =[];
 static List<File> uploadFiles =[];
  List<File> cameraFiles =[];


  static PlatformFile? currentFile;
  static File? currentFile1;
  static File? audioFile;
  static File? attachFile;
  static File? cameraFile;
  static File? voiceNote;

  static String appointmentType='';
  static String patientFollowers ='';
  static double price=0;
  static int doctorId=0;
  static Doctor doctor=Doctor();
  static NurseService service=NurseService();
  static NurseService service2=NurseService();
  static NurseService service3=NurseService();

  static int patientId=0;
  static int serviceId=0;
  static int serviceId2=0;
  static int serviceId3=0;
  static String serviceName='';
  static String doctorName='';
  static String serviceType='N';
  static String serviceCode='N';
  static String paymentType='pay';
  static String consultancyType='';
  static String appointmentDate='';
  static String period='';
  static String hour='';
  static String location='';
  static String textNote='';
  static String doctorGender='Male';
  static bool showFiles=true;
   bool isSend=false;



  final  nameKey='patient';
  final  contactKey='mobile';
  late FormGroup form;


  static PaymentAppointmentTypes paymentAppointmentType=PaymentAppointmentTypes.hhc;

  Questionnaire nationality=Questionnaire(answer: true,questionAr: 'سعودي',question: AppStrings.saudi);


  updateNationality(){

//    nationality.answer=! nationality.answer;
    update();

  }
  pickFiles()async{


    FilePickerResult? result = await FilePicker.platform.pickFiles (allowMultiple: false,

      type: FileType.custom,
      allowedExtensions: ['jpg','jpeg','png', 'pdf', ],


    );

    if (result != null) {

         //   uploadFiles.addAll(  result.files.map((f) => File(f.path!)).toList());
     // files.addAll(result.files);
      print(' picker result **********************************************************');

      print(result.files.first.path);




      var f= File( result.files.first.path!);

      int sizeInBytes =await f.length();
      double sizeInMb = sizeInBytes / (1024 * 1024);

      if (sizeInMb > 1){
buildFailedSnackBar(msg: AppStrings.fileErrorMsg.tr);
        // This file is Longer the
      }
      else {
        attachFile = File(result.files.first.path!);
        print(attachFile!.path);
        // currentFile=result.files.first;
        update();
      }
    } else {
      // User canceled the picker
    }

  }


  pickCamera()async{
    final XFile? photo = await _picker.pickImage(source: ImageSource.camera,);

    if(photo!=null){

var dt=DateTime.now();
var name=dt.toString().replaceAll(' ', '').replaceAll(':', '').replaceAll('-', '').replaceAll('.', '');
      String dir = path.dirname(photo.path);
      String newPath = path.join(dir, '$name.jpg');
      //photo.renameSync(newPath);
      var f=File(photo.path);
       cameraFile= await f.copy(newPath);

ImageProperties properties = await FlutterNativeImage.getImageProperties(cameraFile!.path);

cameraFile = await FlutterNativeImage.compressImage(cameraFile!.path,
    quality: 70,
    targetWidth: 600,
    targetHeight: (properties.height! * 600 / properties.width!).round()
);

//cameraFile=File(ff.path);

  //    uploadFiles.add(ff);
    //  files.add(PlatformFile(path: ff.path,name: ff.path.split('/').last, size: size.toInt(),bytes: await ff.readAsBytes(),));
      update();
    }

  }


  removeItem(int index){
    //files.removeAt(index);
    uploadFiles.removeAt(index);
    update();
  }

  deleteFile(File file){
    file.delete();
  }
  updateFiles(List<PlatformFile> mFiles){

    files=mFiles;
    update();

  }





 static Future<List<d.MultipartFile>> getAttachments()async{

    List<d.MultipartFile> list=[];
    for (var element in uploadFiles) {

      var bytes=await element.readAsBytes();
      var fileName = element.path.split('/').last;
      list.add(d.MultipartFile.fromBytes(bytes, filename: fileName, contentType: MediaType('application', '*')));

    }


    return list;

}


  double  getFileSizeString({required int bytes, int decimals = 0}) {
    if (bytes <= 0) return 0;
   //const suffixes = [" Bytes", "KB", "MB", "GB", "TB"];
    var i = (log(bytes) / log(1024)).floor();
    var d= ((bytes / pow(1024, i)));
    return d;

  }
 String getFileSize(int bytes, int decimals)  {
    //var file = File(filepath);
    //int bytes = await file.length();
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    var i = (log(bytes) / log(1024)).floor();

    var d= ((bytes / pow(1024, i)).toStringAsFixed(decimals)) + ' ' + suffixes[i];

 return d;
  }

  var fileRequired=false;

@override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    if(PatientDataLogic.serviceCode.isNotEmpty){
      fileRequired=true;
    }
    else{
      fileRequired=false;
    }

    if(Get.arguments=='Car'){
      isSend=true;


      form=FormGroup({
        nameKey: FormControl<String>(
            validators: [Validators.required]

        ),

        contactKey: FormControl<String>(
            validators: [Validators.required]


        ),
      }) ;


    }
    else{
      isSend=false;
    }
  }

  void navToNext() {

    //print(PatientDataLogic.service.toJson());

    if(currentUser!=null){
    if(isSend){
        PatientDataLogic.appointmentType='Car';
     // soonMessage();
  Map <String,String>  data={
    nameKey: currentUser!.id,
    contactKey: currentUser!.phone,
    'ksa_nationality': currentUser!.nationality.toString(),
    'service_id':'${PatientDataLogic.service.id}',
    'patient_comment':patientComment.text.toString(),


    'location':PatientDataLogic.location,

  };
  AppointmentBaseController().requestCareGiver(data);

    }


    else if(Get.arguments=='SM'){
      Get.toNamed(AppRouteNames.sleepQuestionnaire);


    }

    else {
      Get.toNamed(AppRouteNames.invoicePage);

      // if (PatientDataLogic.serviceCode.isNotEmpty) {
      //   if (PatientDataLogic.attachFile==null&&PatientDataLogic.cameraFile==null) {
      //     buildFailedSnackBar(
      //         msg: AppStrings.attachmentRequiredMsg.tr);
      //   }
      //   else {
      //     // PatientDataLogic.paymentType = 'cash';
      //
      //
      //     Get.toNamed(AppRouteNames.invoicePage);
      //   }
      // }
      // else {
      //   Get.toNamed(AppRouteNames.invoicePage);
      // }
    }
  }
    else{
      Get.toNamed(AppRouteNames.login);

    }


  }

}
