import 'package:get/get.dart';
import '../../../base_controller/base_controller.dart';
import '../../../core/language_and_localization/app_strings.dart';
import '../../../data/enums.dart';
import '../../../data/models/nurse_service.dart';
import '../../../data/repositories/service_repository.dart';
import '../../../routes/app_route_names.dart';
import '../../../utils/constants/booking_vars.dart';
import '../patient_data/patient_data_logic.dart';

class VaccinationLogic extends BaseController {
  final ServiceRepository _serviceRepository = ServiceRepository();

  List<NurseService> selectedItems = [];

  List<NurseService> items = [];

  updateItems(NurseService item) {
    if (selectedItems.contains(item)) {
      selectedItems.remove(item);
    } else {
      selectedItems.clear();

      selectedItems.add(item);
    }

    update();
  }

  checkItem(NurseService item) {
    return selectedItems.contains(item);
  }

  navToTimeSlots() {
    PatientDataLogic.chooseDateType = ChooseDateType.other;

    if (selectedItems.isNotEmpty) {
      BookingVars.serviceId = selectedItems[0].id;
      BookingVars.serviceType = 'N';
      BookingVars.serviceCode = 'V';
      BookingVars.service = selectedItems[0];
      BookingVars.price = double.parse(selectedItems[0].price);
      BookingVars.doctor.name = '';
      BookingVars.doctor.nameAr = '';
      BookingVars.appointmentType = '-hhc';
      BookingVars.doctorName = '';

      Get.toNamed(AppRouteNames.patientData);
    } else {
      buildFailedSnackBar(msg: AppStrings.selectMsg.tr);
    }
  }

  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
    setBusy(true);
    var data = await _serviceRepository.getServicesList();
    BookingVars.paymentAppointmentType = PaymentAppointmentTypes.hhc;

    items.addAll(data.where((element) => element.code == 'V'));

    setBusy(false);
    update();
  }
}
