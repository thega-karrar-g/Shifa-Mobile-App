// import 'package:device_preview/device_preview.dart';
// import 'package:device_preview/plugins.dart';

// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:sehati_app/modules/auth/auth_controller.dart';
import 'package:sehati_app/modules/intro/intro_logic.dart';
import 'package:sehati_app/services/session_service.dart';
import 'package:sehati_app/start_app.dart';
import 'package:sehati_app/utils/helpers/connectivity_controller.dart';
import 'package:sehati_app/utils/helpers/theme_helper/theme_helpr.dart';
import 'language_and_localization/app_language.dart';
import 'modules/drawer_module/settings/controllers/theme_mode_controller.dart';

//flutter run --no-pub
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // await Firebase.initializeApp();
  //
  // //await FirebaseAuth.instance.useAuthEmulator('localhost', 9099);
  // FirebaseAuth auth = FirebaseAuth.instance;


  await GetStorage.init();

  Get.put(ConnectivityController());

  await Get.put(IntroController()).setupDb();
  await Get.put(SessionService()).setupDb();
  await Get.put(ThemeHelper()).setUpDb();
  await Get.put(ThemeModeController()).initThemeMode();
  await Get.put(AppLanguage()).setUpDB();
   Get.put(AuthController());

  //Get.put(AppBarLogic());

  runApp(
    const StartMyApp(),
   //  Row(
   //    textDirection: TextDirection.ltr,
   //    crossAxisAlignment: CrossAxisAlignment.stretch,
   //    children: [
   //      /*Expanded(
   //      child: Container(color: Colors.red),
   //    ),*/
   //      Expanded(
   //        child: DevicePreview(
   //          enabled: false,
   //          plugins: const [
   //            ScreenshotPlugin(),
   //            FileExplorerPlugin(),
   //            SharedPreferencesExplorerPlugin(),
   //          ],
   //          builder: (context) => const StartMyApp(),
   //        ),
   //      ),
   //    ],
   //  ),
  );
}
