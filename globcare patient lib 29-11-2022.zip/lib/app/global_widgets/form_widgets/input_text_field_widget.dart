import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:reactive_forms/reactive_forms.dart';

class InputTextField extends StatelessWidget {
  final String formControlName;
  final String? hintText;
  final String? labelText;
  final IconData? prefixIcon;
  final Widget? suffix;
  final bool readOnly;
  final bool obscureText;
  final int? minLines;
  final int? maxLines;
  final int? maxLength;
  final bool showErrors;
  final bool isNumeric;

  // final bool isUrl;
  final bool enabled;

  // final bool isEmail;
  // final bool isRequired;
  final bool isFill;
  final InputBorder? inputBorder;
  final void Function()? onSubmitted;
  final TextInputAction? textInputAction;
  final List<TextInputFormatter>? inputFormatters;

  // final Map<String, String> Function(AbstractControl<dynamic>)?
  //     validationMessages;

  const InputTextField({
    Key? key,
    required this.formControlName,
    this.hintText,
    this.labelText,
    // this.validationMessages,
    this.prefixIcon,
    this.onSubmitted,
    this.textInputAction,
    this.suffix,
    this.minLines,
    this.maxLines,
    this.readOnly = false,
    this.obscureText = false,
    this.showErrors = true,
    this.maxLength,
    this.isNumeric = false,
    this.isFill = true,
    this.enabled = true,
    this.inputBorder,
    this.inputFormatters,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ReactiveTextField(
      formControlName: formControlName,
      showErrors: showErrors
          ? (control) => (control.invalid && control.touched)
          : ((control) => showErrors),
    //  onSubmitted: onSubmitted,
      minLines: minLines,
      maxLines: maxLines,
      obscureText: obscureText,
      readOnly: readOnly,
      keyboardType: isNumeric ? TextInputType.number : null,
      inputFormatters:
          isNumeric ? [FilteringTextInputFormatter.digitsOnly] : [],
      textInputAction: textInputAction ?? TextInputAction.next,
      // validationMessages: validationMessages,
      // validationMessages: (control) => {
      //   ValidationMessage.required: 'The email must not be empty',
      //   ValidationMessage.email: 'The email value must be a valid email',
      // },
      decoration: InputDecoration(
        // labelText:this.labelText,
        // border: UnderlineInputBorder(),
        hintText: hintText,
        alignLabelWithHint: true,
        filled: isFill,
        isDense: true,
        // fillColor: inputFillColor,
        // contentPadding: EdgeInsets.zero,
        border: inputBorder ??
            const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(8.0)),
              borderSide: BorderSide.none,
            ),
        prefixIcon: prefixIcon != null ? Icon(prefixIcon) : null,
        labelText: hintText,
        suffix: suffix,
      ),
    );
  }
}
