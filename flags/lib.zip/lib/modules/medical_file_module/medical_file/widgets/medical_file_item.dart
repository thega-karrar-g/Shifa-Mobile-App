import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
class MedicalFileItem extends StatelessWidget {
   MedicalFileItem({Key? key,this.homeService,}) : super(key: key);

   HomeService? homeService;
  @override
  Widget build(BuildContext context) {

    return Container(
      //  elevation: 0.1,
      decoration: BoxDecoration(
          color:   AppColors.primaryColor.withOpacity(.05),
          borderRadius: BorderRadius.circular(10)
      ),


      child: InkWell(
        onTap: (){

          if(homeService!.route.isNotEmpty){
          Get.toNamed(homeService!.route,arguments: homeService);}

          else{
            BaseController().soonMessage();

          }

        },
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            // Positioned.fill(
            //
            //     child: Image.asset(AppImages.maskPrimaryPng ,width: Get.width/2,height: 200,fit: BoxFit.fill,)),

            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                UiHelper.verticalSpaceSmall,
                Container(
                  padding: EdgeInsets.all(5.0),

                  alignment: Alignment.center,
                  // height: 60,
                  //  width: 60,
                  child: Image.asset(
                    homeService!.icon,
                   // color:primary? AppColors.primaryColor:AppColors.primaryColorGreen,
                    width: 70,
                    height: 70,
                  ),
                ),
                UiHelper.verticalSpaceTiny,
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 5,left: 5,bottom: 10),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            homeService!.name.tr,maxLines: 3,
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                            style:homeService!.primary? AppStyles.primaryStyle(bold: true,size: 12):AppStyles.primaryStyleGreen(bold: true,size: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                UiHelper.verticalSpaceMedium,
              ],
            ),


            Positioned.fill(
                bottom: -25,
                child: Align(alignment: Alignment.bottomCenter,
            child: Container(
              padding: EdgeInsets.all(8),
              width: 60,
              height: 40,
              decoration: BoxDecoration(
                color: homeService!.primary?AppColors.primaryColor:AppColors.primaryColorGreen,
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(15),
                  bottomLeft: Radius.circular(15),
                )
              ),

              child: CircleAvatar(backgroundColor: AppColors.white,

              radius: 10,

                child: Icon(Icons.arrow_forward_ios_rounded,size: 18,color: homeService!.primary?AppColors.primaryColor:AppColors.primaryColorGreen,),
              ),

            ),

            ))

          ],
        ),
      ),
    );
  }
}
