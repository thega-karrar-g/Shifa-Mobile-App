import 'package:sehati_app/api/my_emergency_contact_api.dart';
import 'package:sehati_app/models/emergency_contact_model.dart';

class MyEmergencyContactRepository {
  final MyEmergencyContactApi _familyMemberApi = MyEmergencyContactApi();

  static final _instance = MyEmergencyContactRepository._internal();

  factory MyEmergencyContactRepository() {
    return _instance;
  }

  MyEmergencyContactRepository._internal();

  Future getEmergencyContactList() async {
    var result = await _familyMemberApi.getMyEmergencyContact();

    List<EmergencyContact> emergencyContact = [];

    if (result != null && result is List) {
      for (var newData in result) {
        EmergencyContact familyMember = EmergencyContact(name: newData.question, phoneNum: newData.phoneNum,relation: '',address: '');
        emergencyContact.add(familyMember);
      }
      return emergencyContact;
    } else {
      return result;
    }
  }
}
