
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/modules/doctor_module/doctors/widgets/doctors_grid.dart';
import 'package:sehati_app/modules/doctor_module/doctors/widgets/tele_doctor.dart';

import 'package:sehati_app/shared_in_ui/shared/dynamic_grid.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/no_data.dart';
import 'package:sehati_app/shared_in_ui/shared/tab_item.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/grid_aspect_ratio.dart';

import '../../../../shared_in_ui/shared/loading.dart';
import '../doctors_controller.dart';

class DoctorsPage extends GetView<DoctorsController> {


  @override
  final controller = Get.put(DoctorsController());

  DoctorsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
   // DifferentDialog.showServiceInfoSnackBar(description:controller. slide.description!.tr,title:controller. slide.title!.tr,image: controller.slide.image!);
//DifferentDialog.showPaymentSuccessDialog(msg: '');
    return Ui.myScaffold(child: GetBuilder<DoctorsController>(builder: (logic) {


      return Column(
        children: [
          myAppBarServices(title: DoctorsController.doctorType!='TD'?AppStrings.homeVisitDoctor.tr.capitalize.toString():
          AppStrings.telemedicineDoctors.tr.capitalize!,code: DoctorsController.doctorType!='TD'?'HVD':'TD'),
          // UiHelper.verticalSpace(20),
          // if(DoctorsController.doctorType=='TD')
          // SizedBox(
          //   height: 70,
          //   child: Row(children: [
          //
          //     Expanded(
          //       child: Container(
          //         margin: EdgeInsets.symmetric(vertical: 10),
          //         padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          //         decoration: BoxDecoration(color: AppColors.primaryColorOpacity,borderRadius: BorderRadius.circular(15)),
          //         child: Row(children: [
          //           UiHelper.horizontalSpaceSmall,
          //
          //           SvgPicture.asset(AppImages.search),
          //           UiHelper.horizontalSpace(15),
          //           Expanded(
          //             child: TextFormField(
          //               style: AppStyles.subTitleStyle(size: 15),
          //
          //               decoration:InputDecoration(
          //                   hintText: AppStrings.search.tr,
          //                 border: Ui.outlineInputBorder,
          //                 focusedBorder: Ui.outlineInputBorder,
          //                 enabledBorder: Ui.outlineInputBorder,
          //                 errorBorder: Ui.outlineInputBorder,
          //                 focusedErrorBorder: Ui.outlineInputBorder,
          //                 hintStyle: AppStyles.subTitleStyle(size: 15),
          //                 labelStyle: AppStyles.subTitleStyle(size: 15),
          //
          //
          //               ),
          //               onChanged: (t){
          //                 logic.search(txt: t);
          //               },
          //
          //             ),
          //           ),
          //
          //
          //         ],),
          //
          //       )
          //
          //       ,
          //     ),
          //     UiHelper.horizontalSpace(16),
          //     GestureDetector(
          //         onTap: (){
          //           DifferentDialog.doctorsFilterBottomSheet(specialties: controller.specialties,);
          //
          //         },
          //
          //         child: SvgPicture.asset(AppImages.filter,)),
          //
          //   ],),
          // ),


// UiHelper.verticalSpace(20),
          if(DoctorsController.doctorType!='TD')

            Row(children: [



              TabItem(name: AppStrings.general,selected: logic.isGeneral, onTab: (){

                logic.updateGeneral(general: true);

              }),

              UiHelper.horizontalSpaceMedium,



              TabItem(name: AppStrings.specialist,selected: !logic.isGeneral, onTab: (){

                logic.updateGeneral(general: false);

              }),







            ],),


          Expanded(child:

          logic.busy?Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children:const [
              MyLoadingWidget(),
            ],
          ):
          DoctorsController.doctorType!='TD' &&logic.isGeneral?

          DynamicGridView(data: logic.currentDoctors.where((element) => element.doctorType==logic.generalType).toList(),
              scrollable: true,
              padding: UiHelper.doctorGridViewPadding,
              count: Get.width~/300,
              aspectRatio: GridAspectRatio.aspectRatio(count: Get.width~/300,height: 110),

              mainSpacing: 10,
              crossSpacing: 0,

              itemBuilder: (item){
                return TeleDoctorItemList(

                  doctor: item as Doctor,
                );
              })
              :

          logic.deptDoctors.isNotEmpty? DoctorsGrid(
            deptDoctors:logic.deptDoctors,
          ):NoDataFound()


          )


        ],
      );
    }));
  }




// void dispose() {
//   Get.delete<DoctorsController>();
// }
}
