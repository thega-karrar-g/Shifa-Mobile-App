import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/period.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/repositories/appointment_repository.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/constants/app_urls.dart';
import 'package:sehati_app/utils/group_by.dart';

class ChooseDatePeriodLogic extends BaseController {


  int  infoIndex=0,genderIndex=0,currentIndex=0;



final AppointmentRepository _appointmentRepository=AppointmentRepository();

  changeInfoIndex(int index){


    infoIndex=index;
    update();
  }

  DateTime selectedDay=DateTime.now();

changeDay(int index){
  currentIndex=index;
  updateGender(genderIndex);

  selectedDay=periodItems[index].date;
  updateAppointmentDate();

  //updatePeriods( selectedDay);
  update();
}

List<PeriodItem>  periodItems=[];
List<Period>  periods=[];
List<String>  dayPeriods=[];

var route=Get.previousRoute;

@override
  void onInit()async {
    // TODO: implement onInit
    super.onInit();

    var url=AppUrls.periodsHHC;

    var isHHC=false;
    switch(Get.previousRoute){


      case  AppRouteNames.nurseServices:  {
        PatientDataLogic.appointmentType='-hhc';
        url=AppUrls.periodsHHC;
isHHC=true;
      }break;


      case  AppRouteNames.radiologyPage:  {
        PatientDataLogic.appointmentType='-hhc';
        url=AppUrls.periodsHHC;
        isHHC=true;

      }break;

      case  AppRouteNames.vaccination:  {
        PatientDataLogic.appointmentType='-hhc';
        url=AppUrls.periodsHHC;
        isHHC=true;


      }break;

      case  AppRouteNames.physiotherapistServices:  {
        PatientDataLogic.appointmentType='phy';
        url=AppUrls.periodsPhysiotherapy;

      }break;

    }

    setBusy(true);

     var list=await _appointmentRepository.getPeriodList(url: url);

var availableList=list.where((element) => element.available>0);

if(isHHC){

  availableList=list.where((element) => element.available>0&&element.type=='N');
}



    if(route==AppRouteNames.serviceDetails){

      String code=Get.arguments??'N';

      if(code=='SM'||code=='GCP'||code=='MH'){}
      else{
        code='N';
      }

      PatientDataLogic.serviceType=code;

      availableList=list.where((element) => element.available>0&&element.type==code);
    }


 periodItems=availableList.groupBy(   (p0) => p0.date  ).entries.map((e) => PeriodItem(date: e.key,periods: e.value)).toList();


 if(periodItems.isNotEmpty){

   selectedDay=periodItems[0].date;
   updateGender(0);
   changeDay(0);

 }

 for (var element in periodItems) {

   print(  ' date:${element.date.month}-${element.date.day}   length: ${ element.periods.length}');

 }

setBusy(false);
update();



    //changeDay(selectedDay);
    var d=DateTime(selectedDay.year,selectedDay.month,selectedDay.day,0,0,0);

    PatientDataLogic.appointmentDate=DateFormat('yyyy-MM-dd').format(d);

  }
  List<String> doctorSlots=[];

String selectedTime='';
String selectedPeriod='';



updatePeriods(DateTime dateTime){

  dayPeriods.clear();

  for (var element in periods) {

    if((element.date)==dateTime){

     // periods.add(element.period);


    }

  }
  update();


}


selectPeriod({String p=''}){
  selectedPeriod=p;
  PatientDataLogic.period=p;

  update();



}






updateAppointmentDate(){



  var appointmentDate=DateTime(selectedDay.year,selectedDay.month,
      selectedDay.day
      ,
      0,
      0,
      0

  );

   selectedTime=DateFormat('yyyy-MM-dd').format(appointmentDate);
  PatientDataLogic.appointmentDate=selectedTime;

}



updateGender(int gender){


  genderIndex=gender;
  dayPeriods.clear();



  for(var el in periodItems[currentIndex].periods){


    if(route==AppRouteNames.physiotherapistServices) {
      if (gender == 0) {
        if (el.gender == 'Male') {
          dayPeriods.add(el.period);
        }
      }

      else if (gender == 1) {
        if (el.gender == 'Female') {
          dayPeriods.add(el.period);
        }
      }
    }


    else{
      dayPeriods.add(el.period);

    }

  }




  update();
}


periodTime(String period){

  switch(period){
    case 'morning': return ' 9 ${AppStrings.timeAM.tr} - 12 ${AppStrings.timePM.tr}';
    case 'afternoon': return ' 1 ${AppStrings.timePM.tr} - 5 ${AppStrings.timePM.tr}';
    case 'evening': return ' 6 ${AppStrings.timePM.tr} - 9 ${AppStrings.timePM.tr}';
  }

}

navToPatientData() {


  if(selectedPeriod.isNotEmpty) {
    PatientDataLogic.period = selectedPeriod;
    PatientDataLogic.appointmentDate = selectedTime;

    // print(PatientDataLogic.period);
    // print(PatientDataLogic.appointmentDate);

    Get.toNamed(AppRouteNames.patientData);
  }
  else{
    buildFailedSnackBar(msg: AppStrings.selectPeriodMsg.tr);
  }
}
}
