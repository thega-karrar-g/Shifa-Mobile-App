import 'package:dio/dio.dart';
import 'package:sehati_app/models/emergency_contact_model.dart';
import 'base_api.dart';

class MyEmergencyContactApi extends BaseApi {
  static final _instance = MyEmergencyContactApi._internal();

  factory MyEmergencyContactApi() => _instance;

  MyEmergencyContactApi._internal();

  Future getMyEmergencyContact() async {
    try {
      // logger.d(myFamilyMemberUrl);
      // var response = await api.dioGet(AppUrls.familyMemberList);

      // logger.d(response.data);
      //
      // if (response.statusCode == 200) {
      //   dynamic data = response.data;
      //
      //   var decodedJsonData = jsonDecode(jsonEncode(data));
      //
      //   return decodedJsonData['data'];
      // }
      await Future.delayed(const Duration(seconds: 5));
      return [
        EmergencyContact(name: 'ahmed', phoneNum: '966666666666',relation: 'Father',address: 'sana\'a'),
        EmergencyContact(name: 'mohammed', phoneNum: '966 6666 6666',relation: 'Son',address: 'sana\'a'),
        EmergencyContact(name: 'saleh', phoneNum: '96555 556 666',relation: 'Brother',address: 'sana\'a'),
        EmergencyContact(name: 'waleed', phoneNum: '966 6666 66666',relation: 'Brother',address: 'sana\'a'),
      ];
    } on DioError catch (e) {
      // logger.d(e.response);
      return e.message;
    }
  }

  addNewEmergencyContact(EmergencyContact member) async {
    try {

      // var response =
      //     await api.dioPost(AppUrls.addNewFamilyMember, body: member.toJson());

      // logger.d(response.data);

      // if (response.statusCode == 200) {
      //   dynamic data = response.data;
      //   var decodedJsonData = jsonDecode(jsonEncode(data));
      //   if (decodedJsonData['success'] ?? false) {
      //     return true;
      //   }
      // }

    } on DioError catch (e) {
      return e.message;
    }
  }
}
