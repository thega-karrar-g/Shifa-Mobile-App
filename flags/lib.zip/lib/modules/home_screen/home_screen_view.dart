import 'dart:math' as math; // import this
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/models/nurse_service.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/modules/doctor_module/doctors/doctors_controller.dart';
import 'package:sehati_app/modules/home_screen/widgets/card_item.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/shared_styles.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/grid_aspect_ratio.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'home_screen_controller.dart';

class HomeScreenView extends GetView<HomeScreenController> {
  static const String id = '/HomeScreenView';

   HomeScreenView({Key? key}) : super(key: key);
  @override
  final controller = Get.put(HomeScreenController());

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: UiHelper.safeAreaPaddingHome,
      child: SizedBox(
       // color: AppColors.bodyBgColor.withOpacity(.9),
        child: Column(
          children: [


            myAppBarHome(title: 'Hello',withBack: false,isHome: true,h: 10),
            UiHelper.verticalSpaceSmall,

            Container(
height: 80,
              decoration: BoxDecoration(
                color: AppColors.primaryColorOpacity,
                borderRadius: BorderRadius.circular(10)
              ),
              padding: EdgeInsets.symmetric(vertical: 5),
              child: Row(
                children: [

                  Expanded(child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 5,horizontal: 15),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 2,
                          child: Row(
                            children: [
                              Expanded(child: Text(AppStrings.telemedicine.tr,maxLines: 1,textAlign: TextAlign.center,style: AppStyles.primaryStyle(size: 15,bold: true),)),
                            ],
                          ),
                        ),
UiHelper.verticalSpaceSmall,
                        Expanded(
                          flex: 3,
                          child: Ui.primaryButton2(title: AppStrings.bookNow,marginV: 0,radius: 5,
                          onTab: (){


                            PatientDataLogic.serviceName=AppStrings.telemedicine.tr;
                            PatientDataLogic.service=NurseService(name: AppStrings.telemedicine,nameAr: 'استشارة طبية فيديو');
                            PatientDataLogic.appointmentType='';
                            DoctorsController.doctorType='TD';
                            PatientDataLogic.serviceCode='';

                            // Get.to(LocationTestPage(),arguments: AppRouteNames.doctorBook);
                             Get.toNamed(AppRouteNames.doctors,arguments: AppRouteNames.doctorBook);

                          }
                          ),
                        ),



                      ],
                    ),
                  )),

                  GestureDetector(
                    onTap: (){


                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 5),
                      child: Transform(
                        transform: Matrix4.rotationY(Get.locale.toString()=='ar'?0: math.pi),
alignment: Alignment.center,
                        child: Image.asset(AppImages.iconCallDoctor,
                         // fit: BoxFit.fill,
                          width: 120,height:90,
                 // colorBlendMode: BlendMode.color,

                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if(controller.currentUser==null)

UiHelper.verticalSpaceSmall,

            if(controller.currentUser==null)
            Container(
             // height: 80,
              decoration: BoxDecoration(
                  color: AppColors.primaryColorOpacity,
                  borderRadius: BorderRadius.circular(10)
              ),
              padding: EdgeInsets.symmetric(vertical: 15,horizontal: 20),
              child: Row(
                children: [

                  Expanded(child: Text.rich(TextSpan(text: AppStrings.guest2.tr,style: AppStyles.primaryStyle(size: 13,opacity: .7,height: 1.5)
                  ,
                    children: [
                      TextSpan(text: '\t'),

                      TextSpan(text: AppStrings.logIn.tr,style: AppStyles.primaryStyle(bold: true,size: 14)

                      ,
                        recognizer:  TapGestureRecognizer()..onTap = () {
                          PatientDataLogic.fromPatientData=null;

                         // print(Get.height);
                       //   print(Get.width);
                        Get.toNamed(AppRouteNames.login);

                        }

                      )

                    ]

                  ))),

                ],
              ),
            ),




            Expanded(
              child: GetBuilder<HomeScreenController>(
                init: HomeScreenController(),
                builder: (controller) => SingleChildScrollView(
                  child: Wrap(
                    children: <Widget>[
                      // HomeSliderWidget(asstsSlides: controller.assetsSlides),
                      // emergencySection(),


                      GridView.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          crossAxisSpacing: 10.0,
                          mainAxisSpacing: 2.0,
                          childAspectRatio: GridAspectRatio.aspectRatio(count: 3,height: (145.h)),
                        ),
                        itemCount: HomeService.homeServices.length,
                        itemBuilder: (bc,index)=>
                            AnimationConfiguration.staggeredGrid(
                                position: index,
                                columnCount: 3,
                                duration: Duration(milliseconds: 500),
                                child: SlideAnimation(
// flipAxis: FlipAxis.y,
                                    verticalOffset: 150,

                                    duration: Duration(milliseconds: 500),
                                    curve: Curves.easeInOut,
                                    child: FadeInAnimation(

                                        duration: Duration(milliseconds: 500),
                                        curve: Curves.fastOutSlowIn,
                                        child: CardItem(homeService: HomeService.homeServices[index],primary: index%2==1,)))),

                        physics: const NeverScrollableScrollPhysics(),
                        padding: const EdgeInsets.symmetric(horizontal: 0,vertical: 10),


                        primary: false,
                        shrinkWrap: true,

                      ),







                    ],
                  ),
                ),
              ),
            ),
//           Container(
//             height: 60,
//             margin: EdgeInsets.symmetric(horizontal: 55,vertical: 5),
// //padding: EdgeInsets.symmetric(vertical: 5,),
//             decoration: BoxDecoration(
//               color: Colors.red.withOpacity(0),
//               borderRadius: BorderRadius.only(
//                   topRight: Radius.circular(25), topLeft: Radius.circular(25)),
//               boxShadow: [
//                 BoxShadow(color: AppColors.primaryColor.withOpacity(.20), spreadRadius: 0, blurRadius: 1),
//               ],
//             ),
//
//             child: ClipRRect(
//
//               borderRadius: BorderRadius.only(
//                 topLeft: Radius.circular(25.0),
//                 topRight: Radius.circular(25.0),
//               ),
//
//               child: Container(
//                 decoration: BoxDecoration(borderRadius: BorderRadius.only(
//     topLeft: Radius.circular(25.0),
//                   topRight: Radius.circular(25.0),
//
//
//                 ),
//
//                     boxShadow: [
//                       BoxShadow(color: AppColors.primaryColor.withOpacity(.20), spreadRadius: 0, blurRadius: 1),
//                     ],
//                   color: AppColors.white
//                 ),
//                 child: Row(
//                   children: [
//                     Expanded(child:                         GestureDetector(
//                         onTap: (){
//                           Get.toNamed(AppRouteNames.homeBooking);
//
//                         },
//                         child: svgIcon( AppImages.tabBook)),),
//                     Expanded(child:                         svgIcon( AppImages.myHome,),),
//                     Expanded(child:                         GestureDetector(
//
//                         onTap: (){
//                           Get.toNamed(AppRouteNames.account);
//                         },
//                         child: svgIcon( AppImages.settingsOut)),),
//                   ],
//                 ),
//               ),
//             ),
//           )

          ],
        ),
      ),
    );
  }

  Widget buildCard2({String icon='', String? title, VoidCallback? onTap,bool primary=true}) {
    return Container(
    //  elevation: 0.1,
      decoration: BoxDecoration(
        color:primary?   AppColors.primaryColor.withOpacity(.05):AppColors.primaryColorGreen.withOpacity(.05),
borderRadius: BorderRadius.circular(10)
      ),


      child: InkWell(
        onTap: onTap,
        child: Stack(
          children: [
            Positioned.fill(

                child: Image.asset( primary?AppImages.maskPrimaryPng : AppImages.maskGreenPng,width: Get.width/2,height: 200,fit: BoxFit.fill,)),

            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.all(8.0),
                  alignment: Alignment.center,
                 // height: 60,
                //  width: 60,
                  child: SvgPicture.asset(
                    icon,
                    color:primary? AppColors.primaryColor:AppColors.primaryColorGreen,
                    width: 60,
                    height: 60,
                  ),
                ),
                UiHelper.verticalSpaceTiny,
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          title!,maxLines: 2,
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          style:primary? AppStyles.primaryStyle(bold: true,size: 12):AppStyles.primaryStyleGreen(bold: true,size: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),


          ],
        ),
      ),
    );
  }
  Card buildCard1(IconData iconData, String? title, VoidCallback onTap) {
    return Card(
      elevation: 0.1,
      shape: SharedStyle.roundedRectangleBorderShape(radius: 5.0),
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(8.0),
              alignment: Alignment.center,
              height: 60,
              width: 60,
              decoration: BoxDecoration(
                color: AppColors.primaryColor.withAlpha(25),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: FaIcon(
                iconData,
                color: AppColors.primaryColor,
              ),
            ),
            UiHelper.verticalSpaceTiny,
            Text(
              title!,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget buildCard({String icon='', String? title, VoidCallback? onTap,bool isSelected=false,}) {
    return Container(
      margin: EdgeInsets.only(top: 5,right: 5,left: 5),
      decoration: BoxDecoration(
        // color: isSelected? AppColors.primaryColor  :AppColors.white,
        // borderRadius: BorderRadius.circular(
        //  20
        // ),

        // boxShadow: [
        //
        //   BoxShadow(
        //     color: AppColors.primaryColor.withOpacity(isSelected?0.5: 0.19),
        //     blurRadius: 1,
        //     spreadRadius: 2,
        //     offset: Offset(0.0, 2.0),
        //   ),
        // ],
      ),

      child: InkWell(
        onTap: onTap,
        child: Stack(
          children: [

            SvgPicture.asset(AppImages.homeIconBg,),


            Positioned.fill(
              top: -30,
              child: Align(
                alignment: Alignment.topCenter,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // FaIcon(
                    //   icon,
                    //   color: isAppointment? AppColors.white  :AppColors.primaryColor,
                    // ),
                    Container(
                      padding: EdgeInsets.all(20),
                      decoration: BoxDecoration(
                          color: AppColors.primaryColor,
                          shape: BoxShape.circle
                      ),
                      child: SvgPicture.asset(icon,width: 35,height: 35,
                        color:  AppColors.white ,

                      ),
                    ),

                    UiHelper.verticalSpaceTiny,
                    SizedBox(height: 10,),
                    Text(
                      title!,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: AppColors.primaryColor,
                          fontWeight:FontWeight.bold,
                          fontSize: 16

                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  Widget emergencySection() {
    return GestureDetector(
      onTap: () async {
        Get.toNamed(AppRouteNames.emergency);

        // await Navigator.of(context).pushNamed('/Emergency').then((_) {
        //   SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        //     statusBarIconBrightness: Brightness.light,
        //     statusBarColor: AppColors.mainColor,
        //   ));
        // });
      },
      child: Card(
        child: Container(
          // decoration: BoxDecoration(
          //     boxShadow: [
          //   BoxShadow(color: Colors.black.withOpacity(.1), blurRadius: 3)
          // ],
          //     color: Get.theme.cardColor, borderRadius: BorderRadius.circular(4.0)
          // ),
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: <Widget>[
              Container(
                alignment: Alignment.center,
                height: 60,
                width: 60,
                decoration: BoxDecoration(
                  color: Color(0xFFfff1ef),
                  borderRadius: BorderRadius.circular(8.0),
                ),
//                                      borderRadius: BorderRadius.circular(8.0),
                child: FaIcon(
                  FontAwesomeIcons.ambulance,
                  color: Colors.red,
                  size: 30,
                ),
              ),
              SizedBox(width: 9),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      AppStrings.emergency.tr,
                      style: Get.textTheme.subtitle2,
                    ),
                  ),
                  Container(
                    width: 200,
                    padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                    child: FittedBox(
                      fit: BoxFit.fitWidth,
                      child: Text(
                        AppStrings.emergencySubHeading.tr,
                        style: TextStyle(
                            color: Colors.grey, fontStyle: FontStyle.italic),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(width: 9),
              Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 15.0),
                child: FaIcon(
                  FontAwesomeIcons.chevronLeft,
                  size: 14,
                  color: Colors.grey,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }


  Widget homeAppBar({double marginTop=30.0, double paddingV=50}){


    return Container(
      margin: EdgeInsets.only(top: marginTop),
      padding: EdgeInsets.symmetric(horizontal: 50,vertical: paddingV),
      child: Row(children: [

        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(AppStrings.welcome.tr,style: TextStyle(fontSize: 16),),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Text(controller.currentUser!.name.split(' ').first,style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),
              ),

            ],
          ),
        ),
        GestureDetector(
          onTap: (){

//            Get.toNamed(AppRouteNames.account);

          },
          child:Ui.circluarImg(url: '',errorImg: AppImages.doctorImg,size: 70,margin: 0),
        ),



      ],),
    );
  }


  Widget svgIcon(String url){

    return SvgPicture.asset(url,width: 30,height: 30,);
  }

}
