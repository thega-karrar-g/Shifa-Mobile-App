import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:sehati_app/models/payment_method.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
class MethodItem extends StatelessWidget {
   MethodItem({Key? key,this.paymentMethod}) : super(key: key);
PaymentMethod? paymentMethod;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        Get.toNamed(AppRouteNames.paymentMethodDetails,arguments: paymentMethod);
      },

      child: Container(

        margin: EdgeInsets.symmetric(vertical: 5),
        padding: EdgeInsets.symmetric(horizontal: 15,vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: AppColors.primaryColorOpacity
        ),
        child: Row(children: [

          ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: 60,
                maxWidth: 60
              ),
              child: CircleAvatar(
                  radius: 25,
                  backgroundColor: AppColors.white,
                  child: Padding(
                    padding:  EdgeInsets.all( paymentMethod!.logo==AppImages.mada?5: 1.0),
                    child: SvgPicture.asset(paymentMethod!.logo,width: 50,height: 50,),
                  ))),
          UiHelper.horizontalSpaceSmall,
          Expanded(child: Text(paymentMethod!.name,style: AppStyles.primaryStyle(bold: true),)),

          Container(width: 10,height: 10,

          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.primaryColor)

          ),
          ),
          UiHelper.horizontalSpaceMedium,


        ],),

      ),
    );
  }
}
