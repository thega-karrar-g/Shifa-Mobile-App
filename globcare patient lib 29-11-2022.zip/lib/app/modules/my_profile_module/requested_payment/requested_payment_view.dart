import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/language_and_localization/app_strings.dart';
import '../../../global_widgets/shared/loading.dart';
import '../../../global_widgets/shared/my_appbar.dart';
import '../../../global_widgets/shared/no_data.dart';
import '../../../global_widgets/ui.dart';
import '../../../utils/constants/app_anim.dart';
import 'requested_payment_logic.dart';
import 'widgets/requested_payment_item.dart';

class RequestedPaymentPage extends StatelessWidget {
  final logic = Get.put(RequestedPaymentLogic());

   RequestedPaymentPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(
        child: Column(
      children: [
        myAppBar2(title: AppStrings.requestedPayments),
        Expanded(
          child: GetBuilder<RequestedPaymentLogic>(builder: (logic) {
            return logic.busy
                ? MyLoadingWidget()
                : logic.requests.isNotEmpty
                    ? ListView.builder(
                        itemCount: logic.requests.length,
                        itemBuilder: (bc, index) => RequestedPaymentItem(
                              requestedPayment: logic.requests[index],
                              logic: logic,
                            ))
                    : NoDataFound(
                        animation: AppAnim.noPaymentRequests,
                        msg: AppStrings.noAvailablePaymentRequests,
                      );
          }),
        )
      ],
    ));
  }
}
