import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';

class MainDrawerWidgetController extends BaseController {

  navToEmergencyContact() {
    return Get.toNamed(AppRouteNames.emergencyContactListView);
  }

}
