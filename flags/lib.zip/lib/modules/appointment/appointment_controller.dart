import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/models/m_appointment.dart';
import 'package:sehati_app/repositories/appointment_repository.dart';

class AppointmentController extends BaseController {
  final AppointmentRepository _appointmentRepository = AppointmentRepository();





  Rx<int> index=0.obs;

  @override
  var busy=false;

  List<Appointment> appointments=[];
  List<Appointment> currentAppointments=[];


  updateIndex(int i){
    index.value=i;
    currentAppointments.clear();


    switch(i){

      case 0:{
        // scheduled
        currentAppointments.addAll(appointments.where((element) => ( element.state.toLowerCase()==status[0])).toList());

      }break;
      case 1:{
        //
        //conform
        currentAppointments.addAll(   appointments.where((element) => !status.contains( element.state.toLowerCase())).toList());


      }break;

      case 2:{
        //completed
        currentAppointments.addAll(appointments.where((element) => ( element.state.toLowerCase()==status[1]||element.state.toLowerCase()==status[2])).toList());

      }break;


      case 3:{
        //canceled
        currentAppointments.addAll(appointments.where((element) => ( element.state.toLowerCase()==status[3])).toList());

      }break;
    }






update();
  }

  updateBusy(bool b){
    busy=b;
    update();
  }

  HomeService arg=Get.arguments as HomeService ;

   getAppointments() async {
    updateBusy(true);

    var code='tele';
    if(arg.code=='N'||arg.code=='MH'||arg.code=='GCP'||arg.code=='SM'){
      code='hhc';
    }
    else{
      code=arg.code;
    }

     appointments= await _appointmentRepository.getAppointmentList1(type: code);

     currentAppointments.clear();

     currentAppointments=appointments.where((element) => status[0]== element.state.toLowerCase()).toList();



    updateBusy(false);
    update();



  }



  List<String>  status=['scheduled','completed','visit_done','canceled',];

  bool isMeetPossible(String currentStatus){

    return status.contains(currentStatus.toLowerCase());
  }



  bool audioGranted=false;


@override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getAppointments();
  }


  microphoneGranted()async{
  audioGranted=  await Permission.microphone.request().isGranted;

  }



}
