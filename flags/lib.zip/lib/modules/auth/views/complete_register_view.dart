import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/widgets/complete_register_form.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

import '../auth_controller.dart';

class CompleteRegisterPage extends GetView<AuthController> {
  // final controller = Get.find<DoctorsController>();
  @override
  final controller = Get.put(AuthController());

  CompleteRegisterPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(
                //color: AppColors.primaryColor

                // color: AppColors.extraGrey
                ),
            child: SizedBox(
              width: MediaQuery.of(context).size.width * (88),
              child: SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                child: Container(
                  margin: EdgeInsets.symmetric(vertical: 10),
                  padding: EdgeInsets.only(right: 27, left: 27),
                  child: Stack(


                    children: [


                      Column(
                        children: <Widget>[



                          SizedBox(
                            height: Get.height*.3,

                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [

                                Container(
                                  margin: EdgeInsets.only(top: Get.height*.08),
                                  height: 100,
                                  width: 100,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(60),
                                    color: Colors.white.withAlpha(50),
                                  ),
                                  child: Center(
                                      child:
                                      // SvgPicture.asset(
                                      //   AppImages.logoSvg,
                                      //   width: 100,
                                      //   height: 100,
                                      // )
                                      Image.asset(
                                        AppImages.logoPng,
                                        width: 100,
                                        height: 100,
                                      )

                                  ),
                                ),
                                SizedBox(height: 20),

                                Text(AppStrings.appTitle.tr,style: (TextStyle(fontSize: 33,fontWeight: FontWeight.bold,height: 1,color: AppColors.filedBg))

                                )
                              ],
                            ),
                          ),

                          SizedBox(height: 10),

                          CompleteRegisterForm(
                            controller: controller,
                          ),


                          GestureDetector(
                            onTap: () {
                              Get.offAllNamed(AppRouteNames.login);
                              //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                            },

                            child: Text(AppStrings.haveAccount.tr,style: Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.primaryColor)),),
                          ),


                          SizedBox(
                              height: MediaQuery.of(context).size.height * 0.04),
                        ],
                      ),

                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
