import 'package:flutter/material.dart';
import 'package:get/get_rx/src/rx_typedefs/rx_typedefs.dart';
import 'package:sehati_app/models/m_labtest.dart';
import 'package:sehati_app/shared_in_ui/shared/no_data.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

import 'labtest_item_new_design.dart';
  class LabTestList extends StatelessWidget {
     LabTestList({this.labtests,this.isHorizontal=false,Key? key}) : super(key: key);

  final  List<LabTest>? labtests;


 final bool isHorizontal;

    @override
    Widget build(BuildContext context) {


      return  (labtests!.isEmpty)? NoDataFound() : ListView.builder(
          padding: EdgeInsets.only(right: 0,left: 0,bottom: 30),

          itemCount: labtests?.length,
          shrinkWrap: true,
          itemBuilder: (bc,index)=>  LabTestItemNewDesign(labtest: labtests?[index],primary: index%2==1,));
    }


    testItem({String title='',Callback? onTab,bool  isSelected=false}){

      return GestureDetector(
        onTap: onTab,
        child: Container(
          alignment: Alignment.center,

          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 5),
          margin: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.cardBackgroundColor),
              color: AppColors.white
          ),
          child: Text(title,style: TextStyle(color: AppColors.black.withOpacity(.8),fontSize: 16,fontWeight: FontWeight.bold),),),
      );


    }


  }
