import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/widgets/reactive_login_form.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';

import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
import '../auth_controller.dart';

class LoginPage extends GetView<AuthController> {
  // final controller = Get.find<DoctorsController>();
  @override
  final controller = Get.put(AuthController());



  LoginPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,

      body: SafeArea(
        minimum: UiHelper.safeAreaPadding,
        child: SingleChildScrollView(

          child: Column(
            children: [

              UiHelper.verticalSpace(Get.height*.1),


              ReactiveLoginForm(title: AppStrings.welcome,),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [

                  GestureDetector(
                    onTap: () {
                      Get.offAllNamed (AppRouteNames.home);


                      //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                    },

                    child: Text(AppStrings.guest.tr,style: AppStyles.primaryStyle(bold: true,size: 15),),
                  ),
                ],
              ),


              SizedBox(
                height: 16,
              ),

              Row(children:  [

                Expanded(child: Divider(color: AppColors.subTitleColor,)),
                UiHelper.horizontalSpaceMedium,
                Text(AppStrings.or.tr,style: AppStyles.primaryStyle(bold: true),),
                UiHelper.horizontalSpaceMedium,

                Expanded(child: Divider(color: AppColors.subTitleColor,)),


              ],),

              SizedBox(
                height: 16,
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {


                      //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                    },

                    child: Text(AppStrings.doNotHaveAccount.tr,style: AppStyles.subTitleStyle(bold: true,size: 15),),
                  ),
                  UiHelper.horizontalSpace(5),
                  GestureDetector(
                    onTap: () {
                      Get.toNamed(AppRouteNames.register);


                      //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                    },

                    child: Text(AppStrings.signUp.tr,style: AppStyles.primaryStyle(bold: true,size: 15),),
                  ),
                ],
              ),

              UiHelper.verticalSpaceLarge,


            ],
          ),
        ),
      )
    );
  }
}
