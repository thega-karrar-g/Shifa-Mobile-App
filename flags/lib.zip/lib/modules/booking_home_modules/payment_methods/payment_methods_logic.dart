import 'package:get/get.dart';

class PaymentMethodsLogic extends GetxController {

}
