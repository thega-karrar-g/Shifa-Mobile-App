
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/shared_in_ui/shared/different_dialogs.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_column.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'privacy_policy_logic.dart';

class PrivacyPolicyPage extends StatelessWidget {
  final PrivacyPolicyLogic logic = Get.put(PrivacyPolicyLogic());

   PrivacyPolicyPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: GetBuilder<PrivacyPolicyLogic>(builder: (logic) {
      return Stack(
        children: [
          Column(children: [
            myAppBar2(title: AppStrings.privacyPolicy),

            Expanded(child: SingleChildScrollView(

              child: DynamicColumn(children: [

                Text(PrivacyPolicyLogic.termsOfServicesText.tr,textAlign: TextAlign.justify,style: AppStyles.primaryStyle(size: 16,opacity: .8,height: 1.5),),

              ],),

            )),


            UiHelper.verticalSpaceLarge,


            // if(logic.showCheckBox)        Column(
            //           children: [
            //             RowCheck(title:AppStrings.agree.tr ,checked:logic.agree ,onTab: (){logic.updateAgree(!logic.agree);},),
            //
            //       UiHelper.verticalSpaceSmall,
            //           //  RowCheck(title:AppStrings.responsibility.tr ,checked:logic.responsibility ,onTab: (){logic.updateResponsibility(!logic.responsibility);},),
            //             //
            //             // UiHelper.verticalSpaceLarge,
            //
            //             Ui.primaryButton(title:  PatientDataLogic.paymentType=='insurance'? AppStrings.send:AppStrings.bookNow,color: logic.agree?AppColors.primaryColorGreen:AppColors.subTitleColor,onTab: (){
            //
            //             if(logic.agree) {
            //               logic.makeBookingWithFileDio();
            //             }
            //             else{
            //               logic.buildFailedSnackBar(msg: 'You should agree and  responsible to terms of services');
            //             }
            //
            //             }),
            //           ],
            //         )


          ],),
          if(logic.busy)
            Positioned.fill(
              // top: Get.height*.1,

              //   right: Get.width*.5,
                child: Align(
                  alignment: Alignment.center,
                  child: Column(
                    children: [
                      DifferentDialog.loadingDialog()                                    ],
                  ),
                ))

        ],
      );
    }));
  }
}
