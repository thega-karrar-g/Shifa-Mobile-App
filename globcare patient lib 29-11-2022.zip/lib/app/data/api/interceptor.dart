import 'package:dio/dio.dart';

class AppInterceptors extends Interceptor {
}
