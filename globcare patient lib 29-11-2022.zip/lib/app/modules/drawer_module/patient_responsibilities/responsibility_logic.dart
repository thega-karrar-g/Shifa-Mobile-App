import '../../../base_controller/base_controller.dart';

class ResponsibilityLogic extends BaseController {}
