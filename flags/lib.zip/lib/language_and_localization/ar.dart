import 'app_strings.dart';

Map<String, String> ar = {
  AppStrings.appTitle: 'GlobCare',
  AppStrings.appOwner: 'شركة شفاء العربية الطبية',
  AppStrings.welcome: ' مرحباً بك \n مجدداً ',
  AppStrings.hello: 'أهلاً',
  AppStrings.getStarted: 'ابدأ الآن',
  AppStrings.license: 'مرخصة من وزارة الصحة السعودية بأرقام ترخيص: '
      '\n'
      ' 1400030981  و  1400030375'



  ,
  AppStrings.haveNiceDay: 'طاب يومك',
  AppStrings.keepHealthUp: 'رعايتكم صحيا  أولوية عندنا',
  // AppStrings.covidPCR: 'فحص فايروس كورونا - PCR',
  // AppStrings.physiotherapist: 'العلاج الطبيعي وإعادة التأهيل بالمنزل',
   AppStrings.manHealth: 'صحة الرجل',
   AppStrings.serviceDetails: 'تفاصيل الخدمة',
   AppStrings.ourServices: ' خدماتنا',


   AppStrings.patientResponsibilities: ' مسؤوليات المريض',
   AppStrings.serviceInstruction: ' تفاصيل أكثر',
   AppStrings.serviceDescription: ' الوصف',
   AppStrings.moreDetails: ' تفاصيل إضافية',
  // AppStrings.woundCare: 'الرعاية بالجروح وقرح الفراش و القدم السكرية',
  // AppStrings.ivTherapy: 'المحاليل الوريدية',
  // AppStrings.labTechnician: ' تحاليل وأشعة بالمنزل ',
  // AppStrings.geriatricCare: 'برنامج رعاية كبار السن',
  // AppStrings.nurse: 'زيارة ممرضة و مقدمة رعاية بالمنزل',




  AppStrings.labTests: 'قائمة الفحوصات',
  AppStrings.notifications: 'قائمة الإشعارات',


  AppStrings.meetNow: 'اجتماع',
  AppStrings.startMeeting: 'بدء الاجتماع',
  AppStrings.meetTelemedicine: 'اجتماع استشارة طبية',
  AppStrings.muteAudio: 'كتم الصوت',
  AppStrings.muteVideo: ' كتم الفيديو',
  AppStrings.audioOnly: ' الصوت فقط',



  AppStrings.changePassword: 'تغيير كلمة المرور',
  AppStrings.passwordUpdateSuccessfully: 'تم تغيير كلمة المرور',
  AppStrings.gender: 'الجنس',
  AppStrings.general: 'طبيب عام',
  AppStrings.specialist: 'أخصائي',
  AppStrings.doctorGender: 'جنس المعالج',
  AppStrings.logIn: "تسجيل الدخول",
  AppStrings.signOut: "تسجيل الخروج",
  AppStrings.createAccount: "حساب جديد",
  AppStrings.signUp: "انشئ الآن",
  AppStrings.loginMsg: "الرجاء تعبئة بيانات الدخول لبدء استخدام التطبيق",
  AppStrings.loginRequired: "الرجاء  تسجيل الدخول لتتمكن من الحجز",
  AppStrings.firstStep: "الخطوة الأولى",
  AppStrings.nextStep: "الخطوة الثانية",
  AppStrings.fillAllRequiredFields: "الرجاء ملء الحقول الضرورية",
  AppStrings.nationalityRequired: "الرجاء اختيار الجنسية",
  AppStrings.save: "حفظ",
  AppStrings.doNotHaveAccount: "لا أمتلك حسابًا !",
  AppStrings.haveAccount: "لدي حساب بالفعل!",
  AppStrings.accountCreated: "تم إنشاء حسابك",
  AppStrings.successfully: "بنجاح",
  AppStrings.soon: "سيتم تفعيل هذه الخدمة قريبا",
  AppStrings.selectPermissionLocationMsg: 'الرجاء إعطاء إذن الوصول للموقع',
  AppStrings.selectLocationOutRangeMsg: 'عفواً'
      '\n'
      'خدماتنا غير متوفرة خارج مدينة الرياض في الوقت الحالي '
      '\n'
      'سنوفرها قريباً',


  AppStrings.almostDone: "أوشكت على الإنتهاء",
  AppStrings.fillRequiredInformation: "الرجاء تعبئة البيانات المطلوبة بالأسفل",

  AppStrings.register: ' إنشاء حساب جديد',
  AppStrings.continueAsGuest: 'استمرار كزائر',
  AppStrings.dob: 'تاريخ الميلاد',
  AppStrings.male: 'ذكر',
  AppStrings.female: 'أنثى',
  AppStrings.age: 'العمر',
  AppStrings.firstName: ' الاسم الأول',
  AppStrings.midName: ' الاسم الوسط',
  AppStrings.lastName: ' الاسم الأخير',
  AppStrings.fullName: ' الاسم الكامل',
  AppStrings.patientName: ' اسم المريض ',
  AppStrings.nationality: 'الجنسية',
  AppStrings.questionnaire: 'الاستبيان',
  AppStrings.requestSuccessMsg: 'تم استلام طلبك بنجاح وسيتم التواصل معك في أقرب وقت',
  AppStrings.fileErrorMsg: 'حجم الملف يجب أن يكون أقل من 1 ميجابايت',
  AppStrings.microphoneMsg: 'يجب منح الصلاحية للميكرفون ',

  AppStrings.saudi: 'سعودي',
  AppStrings.nonSaudi: 'غير سعودي',
  AppStrings.idNo: 'رقم الهوية',
  AppStrings.ssnHint: 'يجب أن يبدأ ب 1 أو 2',

  AppStrings.location: 'العنوان',
  AppStrings.phoneNumHint: "777 777 777 ",
  AppStrings.phoneNum: "رقم الهاتف",


  AppStrings.editPhoneNum: "تعديل رقم هاتفك",
  AppStrings.editPassword: "تعديل كلمة المرور",
  AppStrings.mustNotEmpty: " يجب أن لا يكون فارغاً ",
  AppStrings.passwordLengthHint: " كلمة المرور يجب أن تتكون من 6 رموز على الأقل ",

  AppStrings.name: "اسم",
  AppStrings.nameHint: "أدخل اسمك",
  AppStrings.email: "البريد الإلكتروني",
  AppStrings.currentEmail: "بريدك الإلكتروني",
  AppStrings.currentEmailHint: "أدخل بريدك الإلكتروني",
  AppStrings.newEmail: "البريد الإلكتروني الجديد",
  AppStrings.newEmailHint: "أدخل بريد الكتروني جديد",
  AppStrings.password: "كلمة السر",
  AppStrings.forgetPassword: "هل نسيت كلمة السر ؟",
  AppStrings.resetPassword: "إعادة ضبط كلمة السر",
  AppStrings.sendResetEmail: "إرسال إيميل لإعادة ضبط كلمة السر",
  AppStrings.resetPasswordLinkSuccessfullySend:
      "تم إرسال إيميل إعادة ضبط كلمة السر بنجاح",
  AppStrings.currentPassword: "كلمة المرور الحالية",
  AppStrings.newPassword: "كلمة المرور الجديدة",
  AppStrings.newPasswordHint: "أدخل كلمة سر جديدة",
  AppStrings.passwordHint: "أدخل كلمة السر",
  AppStrings.passwordConfirm: "تأكيد كلمة السر",
  AppStrings.passwordMatch: " كلمة السر يجب أن تكون متطابقة",
  AppStrings.passwordConfirmHint: "يرجى تأكيد كلمة السر",
  AppStrings.newPasswordConfirm: "تأكيد كلمة السر الجديدة",
  AppStrings.newPasswordConfirmHint: "يرجى تأكيد كلمة السر الجديدة",
  AppStrings.currentPasswordHint: "يرجى إدخال كلمة السر الحالية",
  AppStrings.requiredField: "يجب ملئ هذا الحقل",
  AppStrings.submit: "إرسال معلومات",
  AppStrings.continueText: "التالي",
  AppStrings.about: "من نحن؟",
  AppStrings.setting: "الإعدادات",

  AppStrings.selectTypeHint: "تسجيل الدخول كـ",
  AppStrings.searchHint: "بحث عن نادٍ جديد",
  AppStrings.seeAll: "عرض الكل",
  AppStrings.doubleClickToExitApp: 'انقر نقرًا مزدوجًا للخروج من التطبيق',
  AppStrings.home: "الرئيسية",
  //---------------
  AppStrings.changeUserName: "تغيير اسم المستخدم",
  AppStrings.changePhoneNum: "تغيير رقم الهاتف",
  AppStrings.changeLanguage: "تغيير اللغة",
  AppStrings.changeTheme: "تغيير الثيم",
  AppStrings.delete: "حذف",
  AppStrings.edit: "تعديل",
  AppStrings.checkInternet: "يرجى التأكد من اتصالك بالإنترنت",
  AppStrings.unexpectedError: "للأسف هناك خطأ غير متوقع",
  AppStrings.error: "خطأ",
  AppStrings.close: "إغلاق",
  AppStrings.skip: "تخطي",
  AppStrings.fillAllField: "*الرجاء ملئ جميع الحقول ",
  AppStrings.fillHWFields: "*الرجاء تعبئة حقلي الوزن والطول  ",
  AppStrings.invalidNum: "*رقم التأكيد غير صحيح",
  AppStrings.didNotReceiveCode: "لم يتم استلام رقم التأكيد",
  AppStrings.resend: "إعادة إرسال",
  AppStrings.clear: "حذف",
  AppStrings.showMore: "عرض التفاصيل",
  AppStrings.showLess: "عرض أقل",
  //------------------------------------
  AppStrings.yes: 'نعم',
  AppStrings.no: 'لا',
  AppStrings.from: 'من',
  AppStrings.to: 'إلى',
  AppStrings.or: 'أو',
  AppStrings.guest: 'الدخول كزائر',
  AppStrings.guest2: 'لتتمكن من حجز خدماتنا ,الرجاء',
  AppStrings.welcomeGuest: ' مرحبا ضيفنا العزيز'
      '\n'
      'يسعدنا أن تكون من عائلة جلوب كير و تستفيد من خدماتنا المميزة عن طريق ',
  AppStrings.noDataFound: 'لا يوجد بيانات',
  AppStrings.oops: 'عفوا !',
  AppStrings.noAppointment: 'لا يوجد مواعيد متاحة حاليا '
      '\n'
      'حاول مرة أخرى لاحقا',
  AppStrings.back: 'رجوع',
  AppStrings.next: 'التالي',
  AppStrings.finish: 'إنهاء',
  AppStrings.introCall: 'اتصل فيديو...',
  AppStrings.introVisit: 'اطلب...',
  AppStrings.introCheck: 'افحص...',
  AppStrings.introBook: 'احجز...',
  AppStrings.introReview: 'راجع...',
  AppStrings.introBody1: 'بأفضل الأطباء',
  AppStrings.introBody2: 'طبيبك إلى بيتك',
  AppStrings.introBody3: 'صحتك',
  AppStrings.introBody4: 'طبيبك',
  AppStrings.introBody5: 'كل فحوصاتك',
  AppStrings.add: 'إضافة',
  AppStrings.addMore: 'إضافة اكثر',
  AppStrings.ok: 'موافق',
  AppStrings.deletedSuccessfully: 'تم الحذف بنجاح',
  AppStrings.failedToDelete: 'فشل في الحذف',
  AppStrings.cancel: 'الغاء',
  AppStrings.search: 'بحث',
  AppStrings.completed: 'المكتملة',
  AppStrings.scheduled: 'تحت المراجعة',
  AppStrings.confirmed: 'المؤكدة',
  AppStrings.upcoming: 'الجديدة',
  AppStrings.canceled: 'الملغية',
  AppStrings.rebook: 'إعادة حجز',
  AppStrings.noMoreItem: 'لا يوجد خيارات أخرى',
  AppStrings.noItemsYet: 'لا يوجد خيارات',
  AppStrings.emergency: 'الإسعافات',
  AppStrings.myFamilyMember:  'أعضاء عائلتي',
  AppStrings.myEmergencyContacts:  ' جهات اتصالي للطوارئ',
  AppStrings.emergencyContacts:  ' جهات اتصال الطوارئ',
  AppStrings.emergencySubHeading: 'اتصل بالإسعاف القريب منك - 24 * 7',

  ///  home screen

  AppStrings.doctor: 'الطبيب',
  AppStrings.doctors: 'الأطباء',
  AppStrings.prescriptionList: 'قائمة الوصفات',
  AppStrings.appointmentList: 'قائمة المواعيد',
  AppStrings.labTestDivided: 'الفحوصات',
  AppStrings.radiology: 'الاشعة-والموجات الصوتية',
  AppStrings.individualTest: 'التحاليل المفردة',
  AppStrings.labPackages: 'باقات التحاليل ',
  AppStrings.pcr: 'فحص كورونا',
  AppStrings.medicalFile: 'الملف الطبي',
  AppStrings.bookNow: 'احجز الآن',
  AppStrings.appointments: 'المواعيد',
  AppStrings.medFileImageTest: ' الأشعة',
  AppStrings.medFileReport: ' التقرير الطبي',

  ////////  drawer

  AppStrings.myProfile: 'ملفي الشخصي',
  AppStrings.myMembers: ' التابعين',
  AppStrings.requestedPayments: ' طلبات الدفع',
  AppStrings.cardDetails: 'تفاصيل البطاقة',
  AppStrings.cardNumber: 'رقم البطاقة',
  AppStrings.addCard: 'إضافة بطاقة',
  AppStrings.expDate: 'تاريخ الإنتهاء',
  AppStrings.cvv: 'رقم التحقق',
  AppStrings.myWallet: 'محفظتي',
  AppStrings.editProfile: 'تعديل الملف الشخصي',
  AppStrings.editImage: 'تعديل الصورة',
  AppStrings.profileUpdated: ' تم تحديث الملف الشخصي',
  AppStrings.profileUpdateFailed: ' فشل في تحديث الملف الشخصي',
  AppStrings.language: 'اللغة',
  AppStrings.themeMode: 'الثيم',
  AppStrings.help: 'المساعدة والدعم',
  AppStrings.privacyPolicy: 'سياسة الخصوصية',
  AppStrings.logout: 'تسجيل الخروج',

  AppStrings.applicationPreferences: ' تفضيلات التطبيق',
  AppStrings.termsAndConditions: 'الشروط والأحكام',
  AppStrings.helpAndSupport: '  المساعدة والدعم',
  AppStrings.contactUs: 'تواصل معنا',
  AppStrings.faq: 'الأسئلة الشائعة',
  AppStrings.suggestion: ' اقتراحات',
  AppStrings.reportProblem: 'بلغ عن مشكلة',
  AppStrings.paymentType: 'نوع الدفع',
  AppStrings.pages: '  الصفحات',

  AppStrings.langAr: 'العربية',
  AppStrings.langEn: 'English',

  AppStrings.emergencyMessage:
      'لا يلزم ملء النموذج أدناه. يمكنك استدعاء سيارة الإسعاف على الفور.',

  AppStrings.familyMember: 'أعضاء العائلة',
  AppStrings.relation: 'القرابة',
  AppStrings.address: 'العنوان',
  AppStrings.dead: 'ميت',
  AppStrings.alive: 'حيَ',



  AppStrings.stepController: 'عداد الخطوات',
  AppStrings.pedestrian: 'حالةالمشي',
  AppStrings.stepTaken: 'عدد الخطوات',
  AppStrings.walking: 'يمشي',
  AppStrings.stopped: 'متوقف',
  AppStrings.today: 'اليوم',
  AppStrings.sat: 'السبت',
  AppStrings.sun: 'الأحَد',
  AppStrings.mon: 'الإثنين',
  AppStrings.tue: 'الثلاثاء',
  AppStrings.wed: 'الأربعاء',
  AppStrings.thu: 'الخميس',
  AppStrings.fri: 'الجمعة',
  AppStrings.speedAvg: 'معدل السرعة',
  AppStrings.distance: 'المسافة',
  AppStrings.calories: 'السعرات',



  AppStrings.pleaseWait: 'الرجاء الانتظار',
  AppStrings.martialStatus: 'الحالة الإجتماعية',


///  appointment

  AppStrings.doctorInfo: 'معلومات الطبيب',
  AppStrings.bookDoctor: 'حجز الطبيب',
  AppStrings.chooseDate: 'اختيار التاريخ',
  AppStrings.scheduleType: 'نوع الموعد',
  AppStrings.time: 'الوقت',
  AppStrings.morning: 'الصباح',
  AppStrings.afterNoon: 'بعد الظهر',
  AppStrings.evening: 'المساء',
  AppStrings.timeAM: 'ص',
  AppStrings.timePM: 'م',
  AppStrings.selectPeriodMsg: 'الرجاء اختيار فترة صحيحة',
  AppStrings.confirmAppointment: 'تأكيد الموعد',



  AppStrings.fillCertificateDetails: 'تعبئة بيانات الشهادة',
  AppStrings.certificateDetails: 'تفاصيل الشهادة',
  AppStrings.fillData: 'تعبئة البيانات',
  AppStrings.withCertificate: 'مع الشهادة',
  AppStrings.passport: 'جواز السفر',
  AppStrings.certificateDetailsHint: 'الرجاء تعبئة بيانات الأشخاص الذين سيتم أخذ عيناتهم لأخذ الشهادة ',
/// doctor
  AppStrings.topDoctors: 'أفضل الأطباء',
  AppStrings.aboutDr: 'عن الطبيب',
  AppStrings.doctorDetails: 'تفاصيل الطبيب',
  AppStrings.map: 'الخريطة',
  AppStrings.rating: 'التقييم',
  AppStrings.experience: 'الخبرة',
  AppStrings.doctorSchedule: 'جدول الطبيب',
  AppStrings.languages: 'اللغات',
  AppStrings.scientificExpertise: 'الخبرات العلمية',
  AppStrings.practicalExpertise: 'الخبرات العملية',
  AppStrings.medicalLicense: 'رقم الترخيص الطبي',
  AppStrings.country: 'الدولة',



  AppStrings.bookAppointment: 'حجز موعد',
  AppStrings.insuranceSoon: 'لا يوجد شركات تأمين في الوقت الحالي'
      '\n'
      'ستتوفر قريباً',



  /// labTests

  AppStrings.labTestDetails: 'تفاصيل \nالفحص',
  AppStrings.checkItOut: 'تحقق',
  AppStrings.recentTests: 'الفحوصات الأخيرة',
  AppStrings.test: 'اسم الفحص',
  AppStrings.result: 'النتيجة',
  AppStrings.normalRange: 'المعدل الطبيعي',
  AppStrings.unit: 'الوحدة',
  AppStrings.addedTax: 'ضريبة القيمة المضافة',
  AppStrings.personsCount: 'عدد الأشخاص',
  AppStrings.total: 'المجموع',
  AppStrings.priceWithTax: 'السعر',



  AppStrings.bookingServices: 'خدمات الحجز',
  AppStrings.bookingDetails: 'تفاصيل الحجز',
  AppStrings.telemedicineDoctors: 'استشارة طبية فيديو',
  AppStrings.telemedicine: 'استشارة طبية فيديو',
  AppStrings.covidPCR: 'فحص فايروس كورونا - PCR',
  AppStrings.laboratoryRadiology: 'التحاليل والأشعة بالمنزل',
  AppStrings.laboratory: 'التحاليل المخبرية',
  AppStrings.nurse: 'زيارة ممرضة بالمنزل',
  AppStrings.caregiver: 'مقدم رعاية طبية منزلية',
  AppStrings.diabeticCare: 'العناية بمرضى السكري',

  AppStrings.physiotherapist: 'العلاج الطبيعي وإعادة التأهيل بالمنزل',
  AppStrings.homeVisitDoctor: 'زيارة طبيب بالمنزل',
  AppStrings.doctorVisit: 'زيارة طبيب ',
  AppStrings.internalMedicineSpecialistHomeVisit: 'زيارة طبيب اخصائي الباطنة في المنزل ',
  AppStrings.generalPractitionerHomeVisi: 'زيارة الطبيب العام في المنزل',


  AppStrings.ivTherapy: 'المحاليل الوريدية',
  AppStrings.sleepMedicine: 'طب النوم',
  AppStrings.woundCare: 'الرعاية بالجروح',
  AppStrings.geriatricCare: 'برنامج رعاية كبار السن',
  AppStrings.vaccination: 'حقن العضل/الجلد/التطعيمات',

  AppStrings.vitaminIVDrips: 'محاليل فيتامينية منزلية',
  AppStrings.homeRadiology: 'الأشعة المنزلية',
  AppStrings.homeLaboratory: 'التحاليل المخبرية',
  AppStrings.patientData: 'بيانات المريض',
  AppStrings.medicalStatus: 'شرح الحالة الطبية',
  AppStrings.optional: '(اختياري)',
  AppStrings.mandatory: '(إجباري)',
  AppStrings.continueTo: 'متابعة',
  AppStrings.applePay: 'الدفع باستخدام  ',
  AppStrings.cardPay: 'الدفع باستخدام البطاقة ',
  AppStrings.physiotherapistServices: 'خدمات العلاج الطبيعي',
  AppStrings.nurseService: 'خدمات التمريض',
  AppStrings.payment: ' دفع',
  AppStrings.paymentDetails: ' تفاصيل الدفع',
  AppStrings.paymentOptions: 'خيارات الدفع',
  AppStrings.cancelPayment: 'هل تريد إلغاء عملية الدفع؟',
  AppStrings.choosePayment: 'حدد طريقة الدفع لتأكيد الحجز ',
  AppStrings.cardBrand: 'نوع البطاقة',
  AppStrings.orderAmount: 'المبلغ',
  AppStrings.orderDate: 'تاريخ الطلب',
  AppStrings.orderSummary: 'ملخص الطلب',
  AppStrings.invoiceOrder: 'رقم الفاتورة',
  AppStrings.transaction: 'العملية',
  AppStrings.newTransaction: 'عملية جديدة',
  AppStrings.tryAgain: ' حاول مرة أخرى',
  AppStrings.congratulations: 'تهانينا',

  AppStrings.paymentFailed: 'نأسف لإخبارك بأن عملية الدفع فشلت',


  AppStrings.send: ' إرسال',
  AppStrings.appointmentCreated: ' تم حجز الموعد',
  AppStrings.insurance: 'تأمين',
  AppStrings.insuranceCompanies: 'شركات التأمين',
  AppStrings.cash: 'نقد',
  AppStrings.confirm: 'تأكيد',
  AppStrings.selectLocation: 'حدد الموقع',
  AppStrings.selectedLocation: ' الموقع المحدد',
  AppStrings.selectMsg: 'يجب تحديد خدمة واحدة على الأقل',
  AppStrings.getBestHealthCareMsg: 'احصل على أفضل خدمات العناية الصحية',



  AppStrings.openMap: 'فتح الخريطة',
  AppStrings.openMapMsg: 'يمكنك النقر هنا لتحديد الموقع من الخريطة',
  AppStrings.aboutMsg: 'يمكنك النقر هنا للحصول على معلومات أكثر عن شفاء',
  AppStrings.invalidData: 'بيانات غير صحيحة '
      '\n'
      'الرجاء التأكد من البيانات',
  AppStrings.prescriptionDetails: 'تفاصيل الوصفة ',


  AppStrings.currency: 'ر.س',
  AppStrings.specialties: 'التخصصات',
  AppStrings.taskDetails: 'عرض تفاصيل الخدمة',

  AppStrings.telemedicineAppointments: 'مواعيد الإستشارات الطبية فيديو',
  AppStrings.pcrAppointments: 'مواعيد فحص كورونا ',
  AppStrings.homeVisitAppointments: 'مواعيد  زيارة طبيب للمنزل ',
  AppStrings.nurseAppointments: 'مواعيد الخدمات الطبية المنزلية',
  AppStrings.physiotherapistAppointments: 'مواعيد العلاج الطبيعي',
  AppStrings.sleepMedicineAppointments: 'مواعيد  طب النوم',
  AppStrings.menHealthAppointments: 'مواعيد  صحة الرجل',
  AppStrings.geriatricCareAppointments: 'مواعيد رعاية كبار السن',
  AppStrings.show: 'عرض',
  AppStrings.byClick: 'بالنقر على متابعة فأنك توافق على',

  AppStrings.backToHome: 'عودة إلى الرئيسية',
  AppStrings.paymentSuccess: 'تم الدفع و  حجز موعدك   ',
  AppStrings.paymentLoading: 'جار الإعداد للدفع ',
  AppStrings.insuranceSuccess: 'تم إرسال طلبك للمراجعة  ',
  AppStrings.appointmentSendSuccess: 'تم إرسال طلبك وسيتم التواصل معك قريباً  ',


  AppStrings.textNote: 'ملاحظة نصية',
  AppStrings.textNoteHint: ' اكتب ملاحظة نصية هنا',
  AppStrings.audioNote: 'ملاحظة صوتية',
  AppStrings.audioHint: 'اضغط هنا لتسجيل ملاحظة صوتية',
  AppStrings.languageHint: 'يمكنك الضغط هنا لتغيير اللغة',
  AppStrings.infoHint: 'اضغط هنا لعرض معلومات أكثر عن الخدمة',
  AppStrings.audioRequired: '   الملاحظة الصوتية مطلوبة',
  AppStrings.attachmentRequiredMsg: 'الرجاء إرفاق ملف على الأقل',
  AppStrings.attachments: 'المرفقات',
  AppStrings.uploadAttachmentHint: 'انقر هنا لإضافة مرفقات',
  AppStrings.openCameraHint: 'انقر هنا  لفتح الكاميرا',
  AppStrings.openCamera: 'فتح الكاميرا',
  AppStrings.openFiles: 'فتح الملفات',
  AppStrings.explainHealthProblem: 'اشرح المشكلة الصحية التي تعاني منها',
  AppStrings.tellDoctorSufferFromDiseases: 'الرجاء إخبار الطبيب إذا كنت تعاني من أمراض مزمنة أو حساسية أو إذا كنت تتناول أي أدوية',

  AppStrings.maximumServicesMsg: 'الحد الأقصى لاختيار الخدمات هو  ثلاث خدمات',







  AppStrings.questionnaireHintMsg: 'الرجاء الإجابة على الأسئلة التالية لنتمكن من مساعدتك',
  AppStrings.questions: 'الأسئلة',
  AppStrings.sleepQuestionnaire: 'استبيان النوم',
  AppStrings.height: 'الطول (سم)',
  AppStrings.weightKg: 'الوزن (كجم)',
  AppStrings.contactNo: 'رقم التواصل',
  AppStrings.neckCir: ' محيط العنق(سم)',


  AppStrings.vaccinationDescription: "حقن العضل والجلد/التطعيمات: أحد الخدمات التمريضية المميزة التي توفر الحُقن والتطعيمات في منزلك او في أي موقع بما يتناسب مع حالة الشخص/المريض وبناء على وصفة الطبيب.",
  AppStrings.woundCareDescription: "نوفر من خلال العناية المتقدمة بالجروح (تقرحات الفراش - جروح الإصابات - جروح السكري) العلاج المناسب باستخدام الضماد المناسب للجروح بالإضافة الى مواد متخصصة للجروح العميقة والأجهزة اللازمة لإعادة بناء انسجة الجروح والتي تساعد على التئام الجرح بشكل أسرع.",
  AppStrings.caregiverDescription: "نتميز بان نقدم كوادر مؤهلة للعناية بالمريض في منزلة تحت اشراف طبي وتمريضي مستمر والذي يقوم بوضع خطة الرعاية الطبية اللازمة للاعتناء بالمريض من قبل مقدم الرعاية ومتابعة ما يقدمه الكادر من خدمات من خلال منصات الاتصال الخاصة بملف المريض الإلكتروني.",
  AppStrings.ivTherapyDescription: "خدمة طبية متقدمة لتوفير المضادات والمحاليل الوريدية للمريض في منزلة بناء على وصفة الطبيب والتي تكفي المريض عناء الانتظار في العيادات الطبية او الإقامة الطويلة في المستشفى من خلال طاقم طبي متخصص.",
  AppStrings.homeLaboratoryDescription: "خدمة طبية أينما تكون توفر سحب وجمع العينات المخبرية اللازمة لمتابعة حالة الشخص/المريض الصحية بالإضافة الى قراءة النتائج من قبل الطبيب والتواصل من قبله لتوجيه النصائح والارشادات الطبية المناسبة.",
  AppStrings.diabeticCareDescription: "نقدم رعاية طبية متكاملة من خلال الفحص السريري والتحاليل المخبرية اللازمة لمتابعة مريض سكري الدم وتقديم خطة علاجية تناسب المرحلة العمرية للمصاب للارتقاء بنمط الحياة صحيا ونفسيا.",
  AppStrings.telemedicineDescription: "تم إيجاد  هذه الخدمة لتقديم استشارة طبية مشروعة من خلال أطباء متخصصين / أخصائي نفسي / أخصائي صحة متعاقد / ممرض ممارس"
      "\n"
      "مدة الاستشارة 15  دقيقة",
  AppStrings.nurseDescription: "مجموعة متنوعة من خدمات التمريض المنزلي المتخصصة وفقًا لحالة المريض وخطة العلاج / الوصفات الطبية.",
  AppStrings.hvdDescription: "تقوم خدمة الطبيب في المنزل بتوفير الرعاية الصحية إلى باب منزلك عن طريق الترتيب للحصول على طبيب متخصص مؤهل بدرجة عالية لزيارة المرضى في راحة منازلهم",
  AppStrings.pcrDescription: "نقوم بإجراء فحص كورونا من منزلك من خلال فريقنا بزيارتك في موقعك وأخذ العينة وستصلك النتيجة على التطبيق حال صدورها. كما يتم إصدار شهادة معتمدة للسفر عند الطلب.",
  AppStrings.geriatricDescription: "خدمة طبية شاملة مع خطة رعاية علاجية لكبار السن لتغطية احتياجاتهم السريرية (رعاية القسطرة ، إدارة الأدوية ، HTN & DM ، الرعاية التلطيفية ، وتقرح الفراش) من خلال الأطباء المتخصصين والممرضات والخدمات الصحية المساندة.",
  AppStrings.radiologyDescription: "تعتبر الاشعة المنزلية هى الحل المثالى لكبارالسن والمرضى الذين يصعب انتقالهم الى مراكز الاشعة.  يمكنك بمنتهى السهولة ان تطلب زيارة منزلية من اخصائي او استشارى اشعة على حسب احتياجات الحالة .",
  AppStrings.sleepDescription: "زيارة الطبيب والممرضة لفحص المريض وعمل الفحوصات المطلوبة وتشخيص امراض إضطراب  النوم ومن ثم علاج إضطرابات النوم السائدة في مجتمعنا.",
  AppStrings.manHealthDescription: "زيارة الطبيب والممرضة لفحص المريض وعمل الفحوصات المطلوبة وتشخيص امراض الذكورة وعلاجها وإعطاء المريض هرمون التيستوستيرون على أسس علمية ومتابعة المريض على مدار العام",
  AppStrings.physiotherapyDescription: "نقدم جلسات علاج منزلي بأحدث المعدات المتطورة وخطة رعاية مناسبة وفقًا للحالة السريرية للمريض من قبل أطباء خبراء ومدربين جيدًا.",






};
