import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/models/m_appointment.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

class AppointmentItem2 extends StatelessWidget {
  AppointmentItem2({this.appointment,this.homeService, Key? key}) : super(key: key);
  bool  ar=Get.locale.toString()=='ar';
  List<String>  status=['scheduled','completed','visit_done','canceled',];

  HomeService? homeService;
  final Appointment? appointment;
  final DateFormat dateFormat = DateFormat("dd MMM yyyy HH:mm a");

  bool isMeetPossible(String currentStatus){

    return status.contains(currentStatus.toLowerCase());
  }
  @override
  Widget build(BuildContext context) {


    double radius=15;
String time=appointment!.period.isNotEmpty?appointment!.period.capitalizeFirst!:DateFormat('HH:mm a',Get.locale.toString()).format((appointment!.appointmentDate));

    return ListTile(
      contentPadding: EdgeInsets.only(left: 0.0, right: 0.0,top: 5,bottom: 5),
      title: SizedBox(
        height: 100,
        child: GestureDetector(
          onTap: ()async{
print(appointment!.state);

            if(!isMeetPossible(appointment!.state.toLowerCase())&&homeService!.icon==AppImages.iconTeleMed){

// if(appointment!.videoLink.length>10) {
  // if (await Permission.microphone.request().isGranted ) {
    Get.toNamed(AppRouteNames.meetingPage,arguments: appointment);

  // }
  // else{
  //   BaseController().buildFailedSnackBar(msg: AppStrings.microphoneMsg.tr);
  // }

 // DifferentDialog.showTeleCallDialog(msg: appointment!.password,url: AppUrls.jitsiServerUrl+room);


// }
             // Launcher.launchInBrowser(AppStrings.zoomId);

            }

          },
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.primaryColorOpacity,
              borderRadius: BorderRadius.circular(radius)
            ),
            child: Row(
              children: [


                Container(
                  width: 90,
                  height: 100,
                  decoration: BoxDecoration(
                  color: AppColors.iconAppointmentColor,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular( ar?0: radius),
                      topRight: Radius.circular( ar?radius: 0),
                      bottomRight: Radius.circular(radius),
                      bottomLeft: Radius.circular(radius),

                  ),

                ),
                padding: EdgeInsets.all(10),
                child: Image.asset(homeService!.icon,),
                ),
                Expanded(child: Container(
                  height: 100,
                  padding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
                  decoration: BoxDecoration(
                    color: AppColors.primaryColorOpacity,
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular( ar?0: radius),
                      bottomRight: Radius.circular( ar?0: radius),

                      topLeft: Radius.circular( ar? radius:0),
                      bottomLeft: Radius.circular( ar? radius:0),


                    ),


                  ),
child: Column(children: [

  Row(children: [
    Expanded(child: Text('${appointment!.name}',maxLines: 1,overflow: TextOverflow.ellipsis,style: AppStyles.primaryStyle(bold: true,size: 16),))

  ],),
  UiHelper.verticalSpaceSmall,

  Row(children: [
    Expanded(child: Text('${appointment!.doctor}',maxLines: 1,overflow: TextOverflow.ellipsis,style: AppStyles.subTitleStyle(bold: true,size: 13),))

  ],),
  UiHelper.verticalSpaceSmall,

  Row(children: [
    Text( DateFormat(' d ',Get.locale.toString()).format((appointment!.appointmentDate)),style: AppStyles.primaryStyleGreen(bold: true,size: 12),),

    Text(DateFormat(' MMM ',Get.locale.toString()).format((appointment!.appointmentDate)),style: AppStyles.primaryStyleGreen(bold: true,size: 12),),
    Text( DateFormat(' yyyy ',Get.locale.toString()).format((appointment!.appointmentDate)),style: AppStyles.subTitleStyle(bold: true,size: 12),),

    Text( '  '+time,style: AppStyles.subTitleStyle(bold: true,size: 12),),



    UiHelper.horizontalSpaceMedium,SvgPicture.asset(AppImages.calendar,color: AppColors.primaryColorGreen,),

  ],),





],),

                )),

                if(!isMeetPossible(appointment!.state.toLowerCase())&&homeService!.icon==AppImages.iconTeleMed)

                Container(
                  width: 25,
                  height: 100,
                  alignment:   Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor,
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular( ar?0: radius),
                      bottomRight: Radius.circular( ar?0: radius),

                      topLeft: Radius.circular( ar? radius:0),
                      bottomLeft: Radius.circular( ar? radius:0),


                    ),

                  ),
                  padding: EdgeInsets.all(0),
                  child: RotatedBox(
                      quarterTurns: ar? 3:1,
                      child: Text( AppStrings.meetNow.tr,style: AppStyles.whiteStyle(),)),
                ),



              ],
            ),
          ),
        ),
      ),
    );





  }

  Widget buildVisitTypeButton(int? type, {bool past = false}) {
    switch (type) {
      case 1:
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            FaIcon(
              FontAwesomeIcons.video,
              size: 14,
              color:
                  !past ? Get.theme.colorScheme.secondary : AppColors.extraGrey,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Text(
                'video_visit',
                style: !past
                    ? Get.textTheme.subtitle2!.merge(
                        TextStyle(color: Get.theme.colorScheme.secondary))
                    : Get.textTheme.subtitle2!
                        .merge(TextStyle(color: AppColors.extraGrey)),
              ),
            ),
          ],
        );

      case 2:
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            FaIcon(
              FontAwesomeIcons.mapMarkerAlt,
              size: 14,
              color: AppColors.extraGrey,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Text(
                'clinic_visit',
                style: Get.textTheme.subtitle1!
                    .merge(TextStyle(color: AppColors.extraGrey)),
              ),
            ),
          ],
        );
      case 3:
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            FaIcon(
              FontAwesomeIcons.phoneAlt,
              size: 14,
              color: AppColors.extraGrey,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Text(
                'call_visit',
                style: Get.textTheme.subtitle1!
                    .merge(TextStyle(color: AppColors.extraGrey)),
              ),
            ),
          ],
        );
      default:
        return SizedBox.shrink();
    }
  }
}
