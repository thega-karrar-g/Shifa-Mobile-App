import 'package:auto_direction/auto_direction.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:readmore/readmore.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';

class ReadMoreWidget extends StatefulWidget {
  final String text;
  final int? trimLines;
  final AlignmentGeometry? alignment;
  final Function(bool)? onReadMore;
  final TextAlign? textAlign;

  const ReadMoreWidget({
    Key? key,
    required this.text,
    this.alignment,
    this.trimLines,
    this.onReadMore, this.textAlign,
  }) : super(key: key);

  @override
  _ReadMoreWidgetState createState() => _ReadMoreWidgetState();
}

class _ReadMoreWidgetState extends State<ReadMoreWidget> {
  late String text;
  bool isRTL = false;
  late String tempText;

  @override
  void initState() {
    super.initState();
    text = widget.text;
  }

  @override
  void didUpdateWidget(covariant ReadMoreWidget oldWidget) {
    if (oldWidget.text != widget.text) {
      setState(() {
        text = widget.text;
      });
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return AutoDirection(
      text: text,
      child: Align(
        alignment: widget.alignment ?? AlignmentDirectional.centerStart,
        child: ReadMoreText(
          widget.text,
          trimLines: widget.trimLines ?? 3,
          style: Get.textTheme.bodyText1!.copyWith(
          ),
          colorClickableText: Colors.blue,
          trimMode: TrimMode.Line,
          callback: widget.onReadMore,
          textAlign: widget.textAlign,
          trimCollapsedText: AppStrings.showMore.tr.capitalizeFirst ?? '',
          trimExpandedText: AppStrings.showLess.tr.capitalizeFirst ?? '',
        ),
      ),
    );
  }
}
