
import 'package:dio/dio.dart';

class AppInterceptors extends  Interceptor {

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    // TODO: implement onRequest
    print(options.headers.toString());
    print(options.data.toString());
    print(options.path.toString());

    super.onRequest(options, handler);

  }


}