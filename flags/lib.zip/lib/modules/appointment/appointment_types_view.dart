import 'package:flutter/material.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/modules/appointment/widgets/appointment_type_item.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_column.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';

class AppointmentTypesPage extends StatelessWidget {
   AppointmentTypesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: UiHelper.safeAreaPaddingHome,
      child: Column(
        children: [
          myAppBar3(title: AppStrings.appointmentList,withBack: false,h: 20),


          UiHelper.verticalSpaceSmall,


          Expanded(child: SingleChildScrollView(child: DynamicColumn(children: HomeService.appointmentTypes.map((e) => AppointmentTypeItem(homeService: e,)).toList(),)))

        ],
      ),
    );
  }
}
