import 'package:get/get.dart';
import '../../../base_controller/base_controller.dart';
import '../../../core/language_and_localization/app_strings.dart';
import '../../../data/enums.dart';
import '../../../data/models/home_service.dart';
import '../../../data/models/nurse_service.dart';
import '../../../data/repositories/service_repository.dart';
import '../../../routes/app_route_names.dart';
import '../../../utils/constants/booking_vars.dart';
import '../patient_data/patient_data_logic.dart';

class NurseServicesLogic extends BaseController {
  final ServiceRepository _serviceRepository = ServiceRepository();

  List<NurseService> selectedItems = [];

  List<NurseService> items = [], searchList = [];

  updateItems(NurseService item) {
    if (selectedItems.contains(item)) {
      selectedItems.remove(item);
    } else {
      if (selectedItems.isEmpty || selectedItems.length < 3) {
        selectedItems.add(item);
      } else {
        buildFailedSnackBar(msg: AppStrings.maximumServicesMsg.tr);
      }
    }

    update();
  }

  checkItem(NurseService item) {
    return selectedItems.contains(item);
  }

  @override
  search({String txt = ''}) {
    searchList.clear();

    searchList.addAll(items
        .where((element) =>
            element.name.toString().toLowerCase().contains(txt.toLowerCase()) ||
            element.nameAr.contains(txt))
        .toList());

    update();
  }

  navToTimeSlots() {
    PatientDataLogic.chooseDateType = ChooseDateType.other;

    if (selectedItems.isNotEmpty) {
      var services = '';
      // for (var element in selectedItems) {
      //   services+='- ${element.name} ';
      // }
      BaseController.service += ' $services';
      BookingVars.serviceId = selectedItems[0].id;
      BookingVars.service = selectedItems[0];
      if (selectedItems.length > 1) {
        BookingVars.service2 = selectedItems[1];
      } else {
        BookingVars.service2 = NurseService();
      }

      if (selectedItems.length > 2) {
        BookingVars.service3 = selectedItems[2];
      } else {
        BookingVars.service3 = NurseService();
      }
      BookingVars.price = 0.0;
      for (var element in selectedItems) {
        BookingVars.price += double.parse(element.price);
      }
      BookingVars.paymentAppointmentType = PaymentAppointmentTypes.hhc;

      BookingVars.serviceType = 'N';
      BookingVars.serviceCode = '';

      BookingVars.appointmentType = '-hhc';
      BookingVars.doctorName = '';
      BookingVars.doctor.name = '';
      BookingVars.doctor.nameAr = '';

      Get.toNamed(AppRouteNames.patientData);
    } else {
      buildFailedSnackBar(msg: AppStrings.selectMsg.tr);
    }
  }
  HomeService homeService = Get.arguments;

  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
    BookingVars.isPcr = false;

    print('******************************************* code: ${homeService.code}');

    setBusy(true);
    var data = await _serviceRepository.getServicesList();

    items.addAll(data.where((element) => element.type == homeService.code));

    print('******************************************* length data: ${data.length}');
    print('******************************************* length items: ${items.length}');

    searchList.addAll(items);

    setBusy(false);
    update();
  }
}
