import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/nurse_service.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/repositories/service_repository.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';

import '../../../utils/enums.dart';

class VaccinationLogic extends BaseController {

  final ServiceRepository _serviceRepository=ServiceRepository();

   List<NurseService> selectedItems=[];

  List<NurseService> items=[];


updateItems( NurseService item){
  if(selectedItems.contains(item))
  {
    selectedItems.remove(item);
  }
  else{
    selectedItems.clear();

    selectedItems.add(item);

  }


update();
}

  checkItem(NurseService item){

  return selectedItems.contains(item);

  }



   navToTimeSlots(){


     if(selectedItems.isNotEmpty){

       PatientDataLogic.serviceId=selectedItems[0].id;
       PatientDataLogic.serviceType='N';
       PatientDataLogic.serviceCode='V';
       PatientDataLogic.service=selectedItems[0];
       PatientDataLogic.price= double.parse( selectedItems[0].price);
       PatientDataLogic.doctor.name='';
       PatientDataLogic.doctor.nameAr='';
       PatientDataLogic.appointmentType='-hhc';
       PatientDataLogic.doctorName='';

       Get.toNamed(AppRouteNames.chooseDatePeriod);

     }else{
       buildFailedSnackBar(msg: AppStrings.selectMsg.tr);
     }


   }
@override
  void onInit() async{
    // TODO: implement onInit
    super.onInit();
    setBusy(true);
  var data=await  _serviceRepository.getServicesList();
    PatientDataLogic.paymentAppointmentType=PaymentAppointmentTypes.hhc;

  items.addAll(data.where((element) => element.code=='V'));


  setBusy(false);
  update();
  }

}
