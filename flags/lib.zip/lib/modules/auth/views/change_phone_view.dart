import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import '../auth_controller.dart';

class ChangePhonePage extends GetView<AuthController> {
  @override
  final controller = Get.put(AuthController());
  final  double  paddingHeight=25.0;

  ChangePhonePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final labelStyle=TextStyle(color: AppColors.primaryColor,fontWeight: FontWeight.bold,fontSize: 13);

    final OutlineInputBorder outlineInputBorder =OutlineInputBorder(
      borderRadius: BorderRadius.all(

          Radius.circular(0)),
      borderSide: BorderSide(
          color:
          AppColors.white),


    );
    return Ui.myScaffold(child: SingleChildScrollView(
      child: Stack(
        children: [
          Column(
            children: <Widget>[



              myAppBar3(title: AppStrings.phoneNum),
              SizedBox(height: 30),


              Container(
                color: AppColors.white,
                child: CountryCodePicker(
                  onChanged: (c){
                    print(c.code);
                  },
                  // Initial selection and favorite can be one of code ('IT') OR dial_code('+39')
                  initialSelection: 'SA',
                  favorite:const ['+966', 'SA'],
                  // flag can be styled with BoxDecoration's `borderRadius` and `shape` fields
                  flagDecoration: BoxDecoration(
                    // borderRadius: BorderRadius.circular(20),
                    //color: AppColors.registerFiled
                  ),

                  searchStyle: labelStyle,

                  builder: (c)=>Container(

                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20)
                        ,
                        border: Border.all(color: AppColors.subTitleColor)
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 25,vertical: 30),
                          decoration: BoxDecoration(
                              color: AppColors.registerFiled,
                              borderRadius: BorderRadius.circular(20)
                          ),
                          child: Row(children: [
                            //  Text('${c!.dialCode}'),
                            Image.asset(c!.flagUri.toString(),width: 30,height: 30,),
                            SizedBox(width: 5,),
                            Icon(Icons.keyboard_arrow_down_outlined,color: AppColors.primaryColor,)


                          ],),),
                        SizedBox(width: 5,),
                        Text('${c.dialCode}',style: labelStyle),

                        Expanded(child: TextFormField(

                          textInputAction: TextInputAction.next,
                          keyboardType:  TextInputType.number,
                          decoration: InputDecoration(
                              labelText: AppStrings.phoneNum.tr,
                              labelStyle: labelStyle,
                              hintStyle: AppStyles.subTitleStyle(bold: true,size: 15),

                              //filled: true,
                              contentPadding: EdgeInsets.symmetric(horizontal: 12,vertical: paddingHeight),
                              hintText: AppStrings.phoneNum.tr,
                              errorStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
                              errorBorder: outlineInputBorder,
                              //  hintStyle: TextStyle(color: Colors.black.withOpacity(0.7)),


                              border: outlineInputBorder,
                              focusedBorder:outlineInputBorder,
                              enabledBorder: outlineInputBorder,
                              disabledBorder: outlineInputBorder,
                              focusedErrorBorder: outlineInputBorder

                          ),
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            FilteringTextInputFormatter.deny( RegExp(r"\s\b|\b\s")),
                            LengthLimitingTextInputFormatter(10),


                          ],
                          style: AppStyles.subTitleStyle(bold: true,size: 15),

                        ))

                        ,SizedBox(width: 20,),


                      ],
                    ),
                  ),
                  showCountryOnly: false,
                  showFlagMain: true,
                  showFlag: true,
                  showDropDownButton: true,
                  backgroundColor: AppColors.registerFiled,
                  boxDecoration: BoxDecoration(

                      color: AppColors.registerFiled,
                      borderRadius: BorderRadius.circular(20)
                  ),
                  padding: EdgeInsets.all(20),


                ),
              ),
              SizedBox(height: Get.height*.2),


              Row(
                children: [
                  Expanded(
                      child:

                      GestureDetector(
                          onTap: (){
                            Get.back();
                          },

                          child: Text(AppStrings.cancel.tr,style: AppStyles.subTitleStyle(size: 20,bold: true),))
                  ),
                  Expanded(
                    child: Ui.primaryButton(title: AppStrings.save,radius: 15,hasIcon: false,marginH: 0,onTab: (){


                      // if(form.valid) {
                      //   controller!.mapUser.addAll(form.value);
                      //
                      //   Get.toNamed(AppRouteNames.completeRegister);
                      // }
                      // else{
                      //  // controller!.buildFailedSnackBar(msg: AppStrings.fillAllField.tr);
                      //   controller!.buildFailedSnackBar(msg: form.errors.toString());
                      //
                      // }



                    }),
                  ),
                ],
              ),


              // ChangePasswordForm(
              //   controller: controller,
              // ),



            ],
          ),
          // Positioned(
          //
          //     top: 50,
          //     left: 10,
          //     //   right: 20,
          //     child: GestureDetector(
          //         onTap: (){
          //           Get.back();
          //         },
          //         child: Icon(Icons.arrow_back_ios_outlined,color: AppColors.primaryColor,))),

        ],
      ),
    ));
  }
}
