import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/time_helper.dart';

class BookDoctorLogic extends BaseController {


  int  infoIndex=0;


  changeInfoIndex(int index){


    infoIndex=index;
    update();
  }

  DateTime selectedDay=DateTime.now().add(Duration(days: 1));
  var weekDays = List<DateTime>.generate(7, (i) =>
      DateTime.now().add(Duration(days: 1)).add(Duration(days: i)));

changeDay(DateTime dateTime){
  selectedDay=dateTime;
  var d=       DateFormat('EEEE').format(selectedDay);

  updateSlots(day: d);
  update();
}

@override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    selectedDay=weekDays[0];
    changeDay(selectedDay);
    var d=DateTime(selectedDay.year,selectedDay.month,selectedDay.day,0,0,0);

    PatientDataLogic.appointmentDate=DateFormat('yyyy-M-d HH:mm:ss').format(d);

  }
  List<String> doctorSlots=[];

String selectedTime='';

  updateSlots({String day=''}){
    var doctor=Get.arguments as Doctor;
    doctorSlots.clear();
    for (var element in doctor.availableLines!) {
      if(day==element.day) {
        DateTime start = DateFormat("HH:mm").parse(element.startTime!);
        DateTime end = DateFormat("HH:mm").parse(element.endTime!);

        TimeOfDay startTimeOfDay = TimeOfDay.fromDateTime(start);

        TimeOfDay endTimeOfDay = TimeOfDay.fromDateTime(end);

        doctorSlots.addAll(
          TimeHelper.  getSlots(start: startTimeOfDay.hour, end: endTimeOfDay.hour-1));
      }
    }

    update();
  }
updateAppointmentDate(String time){

  DateTime end = DateFormat("HH:mm a").parse(time);

  selectedTime=DateFormat('HH:mm a').format(end);


  var appointmentDate=DateTime(selectedDay.year,selectedDay.month,
      selectedDay.day
      ,
      end.hour,
      end.minute,
      0

  );

   selectedTime=DateFormat('yyyy-M-d HH:mm:ss').format(appointmentDate);
  PatientDataLogic.appointmentDate=selectedTime;

update();
}

checkTime(String time){
  DateTime end = DateFormat("HH:mm a").parse(time);



  var appointmentDate=DateTime(selectedDay.year,selectedDay.month,
      selectedDay.day
      ,
      end.hour,
      end.minute,
      0

  );

 return DateFormat('yyyy-M-d HH:mm:ss').format(appointmentDate);
}



navToPatientData() {
    var d=(PatientDataLogic.appointmentDate);

    try {

    if (d.substring(11)!='00:00:00' ) {
      Get.toNamed(AppRouteNames.patientData);
    }

    else {
      buildFailedSnackBar(msg: 'please select correct time');
    }
  }catch(e){
    buildFailedSnackBar(msg: 'please select correct time');


  }
}
}
