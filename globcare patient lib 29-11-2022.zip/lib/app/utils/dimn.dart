import 'package:get/get.dart';

class Dimensions {
  static double boxWidth = Get.height / 100;
  static double boxHeight = Get.width / 100;
}
