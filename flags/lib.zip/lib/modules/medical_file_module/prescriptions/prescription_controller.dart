import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/m_prescription.dart';
import 'package:sehati_app/repositories/prescription_repository.dart';

class PrescriptionController extends BaseController {

  final PrescriptionRepository _prescriptionRepository=PrescriptionRepository();




  Future<List<Prescription>>  getPrescription() async {

    return await _prescriptionRepository.getPrescriptionList();

  }


}
