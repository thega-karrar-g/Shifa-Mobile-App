import 'package:get/get.dart';

import '../../../base_controller/base_controller.dart';
import '../../../data/enums.dart';
import '../../../data/models/nurse_service.dart';
import '../../../data/repositories/service_repository.dart';
import '../../../routes/app_route_names.dart';
import '../../../utils/constants/app_images.dart';
import '../../../utils/constants/booking_vars.dart';
import '../patient_data/patient_data_logic.dart';

class ServiceDetailsLogic extends BaseController {
  static String serviceCode = 'MH';
  static String icon = AppImages.homeVisitDoctor;

  final ServiceRepository _serviceRepository = ServiceRepository();

  List<NurseService> services = [];

  NurseService? nurseService;

  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
    BookingVars.showFiles = true;
    BookingVars.service2 = NurseService();
    BookingVars.service3 = NurseService();
    BookingVars.isPcr = false;

    setBusy(true);
    services = await _serviceRepository.getServicesList();
    BookingVars.doctorName = '';
    BookingVars.paymentAppointmentType = PaymentAppointmentTypes.hhc;

    for (var element in services) {
      if (element.type == serviceCode) {
        nurseService = element;
        break;
      }
    }
    setBusy(false);

    update();
  }

  navToNext() {
    final ar = Get.locale.toString() == 'ar';

    BookingVars.price = double.parse(nurseService!.price);
    BookingVars.serviceId = nurseService!.id;
    BookingVars.serviceName = ar ? nurseService!.nameAr : nurseService!.name;
    BookingVars.appointmentType = '-hhc';
    BookingVars.serviceCode = '';
    BookingVars.doctor.name = '';
    BookingVars.doctor.nameAr = '';
    BookingVars.service = nurseService!;

    if (nurseService!.code == 'IVT') {
      BookingVars.serviceCode = 'IVT';
    }

    if (nurseService!.code == 'SM') {
      PatientDataLogic.chooseDateType = ChooseDateType.hide;

      Get.toNamed(AppRouteNames.patientData, arguments: nurseService!.code);
    } else if (nurseService!.code == 'Car') {
      PatientDataLogic.chooseDateType = ChooseDateType.hide;

      Get.toNamed(AppRouteNames.patientData, arguments: nurseService!.code);
    } else {
      PatientDataLogic.chooseDateType = ChooseDateType.other;

      Get.toNamed(AppRouteNames.patientData, arguments: nurseService!.code);
    }
  }

  bool showPrice() {
    var t = ['SM', 'Car'];
    var s = !t.contains(nurseService!.code);

    return s;
  }
}
