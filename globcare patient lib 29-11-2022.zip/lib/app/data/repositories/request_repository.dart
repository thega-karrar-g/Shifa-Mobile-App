import '../../utils/constants/api_keys.dart';
import '../api/request_api.dart';
import '../models/request_model.dart';

class RequestRepository {
  static final _requestRepository = RequestRepository._internal();

  factory RequestRepository() {
    return _requestRepository;
  }

  RequestRepository._internal();

  final RequestApi _requestService = RequestApi();

  Future<List<RequestModel>> getRequestList({String id = ''}) async {
    try {
      var response = await _requestService.getRequests(id: id);

      if (response!.data[ApiKeys.responseSuccess] == 1) {
        var d = response.data['data'] as List;
        //   log(response.data.toString());
        var dd = d.map((dr) {
          return RequestModel.fromJson((dr));
        }).toList();

        return dd;
      } else {
        return [];
      }
    } catch (e) {
      print('err   ***************************  ${e.toString()}');
      return [];
    }
  }

  Future<dynamic> updateFcmToken(Map<String, String> data) async {
    var response = await _requestService.updateFcmToken(data);

    try {
      return response!.data;
    } catch (_) {
      return response!.data;
    }
  }
  Future<dynamic> setPaymentStatus(Map<String, String> data) async {
    var response = await _requestService.setPaymentStatus(data);

    try {
      return response!.data;
    } catch (_) {
      return response!.data;
    }
  }

  Future<dynamic> createInstantCon(Map<String, String> data) async {
    try {
      var response = await _requestService.createInstantCon(data);

      return response!.data;
    } catch (_) {
      return null;
    }
  }

  Future<dynamic> rateConsultation(Map<String, String> data) async {
    var response = await _requestService.rateConsultation(data);

    try {
      return response!.data;
    } catch (_) {
      return response!.data;
    }
  }
}
