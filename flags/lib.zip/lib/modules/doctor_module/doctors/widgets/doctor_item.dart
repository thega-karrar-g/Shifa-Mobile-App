import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/modules/doctor_module/doctors/views/doctor_details.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

class DoctorItem extends StatelessWidget {
   DoctorItem({this.doctor,this.isTopItem=false, Key? key}) : super(key: key);

  final Doctor? doctor;

final  bool  isTopItem;

  @override
  Widget build(BuildContext context) {

    return GestureDetector(

      onTap: (){
        BaseController.doctorId=doctor!.id;

        if(isTopItem){
          Get.to(DoctorDetailsPage(doctor: doctor,));

        }
      },

      child: Container(
        //  height: 120,
        width:  isTopItem? Get.width/2:Get.width,
        padding:  EdgeInsets.only(left: isTopItem?8.0: 25.0, right:isTopItem?8.0: 25.0,bottom: 20),
        child: Container(
          decoration: BoxDecoration(boxShadow: [
            BoxShadow(

                color:isTopItem  ?AppColors.white.withOpacity(.5) :AppColors.stepCounterCircleBg.withOpacity(.5), blurRadius: 10)
          ],
              color: isTopItem? AppColors.white :AppColors.stepCounterCircleBg, borderRadius: BorderRadius.circular(15.0)),
          // margin: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),
          padding: const EdgeInsets.all(8.0),
          child:
          Stack(
            children: [



              Row(
                children: <Widget>[

                  Ui.circluarImg(url: '',size:isTopItem? 65:75,margin: 3),
                  SizedBox(
                    width: 9,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SizedBox(height: 15,),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              flex: 1,
                              fit: FlexFit.tight,
                              child: Text(
                                "${doctor!.name}",
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.filedBg,fontSize: isTopItem?13:15,fontWeight: FontWeight.bold)),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0,top: 5),
                          child: Text(
                            "${doctor!.speciality}",
                            style: Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.bottomNavIcon,fontSize: isTopItem?13:15)),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 8,top: 5),
                          child: Row(
                            //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.center,
                                children: [
                                  SvgPicture.asset(AppImages.star,width: 18,height: 18,),
                                  SizedBox(
                                    width: 4,
                                  ),
                                  Text("${doctor!.rating}",
                                      style: Get.textTheme.bodyText2!.merge(TextStyle(fontSize:15))                                  ),
                                  SizedBox(
                                    width: 4,
                                  ),
                                ],
                              ),
                              Icon(Icons.remove,color: AppColors.blackTxt,size: 15,),
                              Text("${doctor!.reviewCount} Reviews",
                                  style: Get.textTheme.bodyText2!.merge(TextStyle(fontSize:isTopItem? 11:13))
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 8,top: 5),
                          child: Row(
                            //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Icon(Icons.monetization_on_outlined,color: AppColors.primaryColor,size: 20,),

                              SizedBox(width: 5,),
                              Text("${doctor!.price} "+AppStrings.currency.tr,
                                  style: Get.textTheme.bodyText2!.merge(TextStyle(fontSize:14,fontWeight: FontWeight.bold,color: AppColors.primaryColor))
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 10,)
                      ],
                    ),
                  ),
                ],
              ),

              Get.locale.toString()=='ar'?Positioned(
                  left: 10,
                  top: 30,
                  child:

                  isTopItem ?  Container() : GestureDetector(

                      onTap: (){
                        BaseController.doctorId=doctor!.id;

                        Get.to(DoctorDetailsPage(doctor: doctor,));
                      },
                      child: RotatedBox(
                          quarterTurns: 2,
                          child: SvgPicture.asset(AppImages.arrowBlue,color: AppColors.primaryColor,width: 30,height: 30,)))):
              Positioned(
                  right: 10,
                  top: 30,
                  child:

                  isTopItem ?  Container() : GestureDetector(

                      onTap: (){
                        BaseController.doctorId=doctor!.id;

                        Get.to(DoctorDetailsPage(doctor: doctor,));
                      },
                      child: SvgPicture.asset(AppImages.arrowBlue,color: AppColors.primaryColor,width: 30,height: 30,)))

            ],
          ),
        ),
      ),
    );


  }
}
