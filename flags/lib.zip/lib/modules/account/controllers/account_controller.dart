import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';

class AccountController extends BaseController {



  // User currentUser = User(
  //   name: 'Ali',
  //   email: 'ali@gmail.com',
  //   password: '123',
  //   username: 'Ali Ali',id:1,imageUrl: ''
  //
  // );



  void navigateToWorkersWidget() {
    // Get.toNamed(Routes.WORKERS, arguments: currentUser.value);
  }

  void navigateToProfile() {
    // Get.toNamed(AppRouteNames.prescriptions, arguments: currentUser.value);
  }
  void navigateToLogin() {
    Get.offAndToNamed(AppRouteNames.login,);
  }



}
