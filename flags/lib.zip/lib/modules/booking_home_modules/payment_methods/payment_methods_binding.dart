import 'package:get/get.dart';

import 'payment_methods_logic.dart';

class PaymentMethodsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => PaymentMethodsLogic());
  }
}
