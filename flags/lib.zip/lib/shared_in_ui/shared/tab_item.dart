import 'package:flutter/material.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
import 'package:get/get.dart';

class TabItem extends StatelessWidget {
  const TabItem({Key? key,required this.name,required this.onTab,this.selected=false,this.fontSize=15.0}) : super(key: key);
  final  String name;
 final bool  selected;
 final Function onTab;
 final double fontSize;
  @override
  Widget build(BuildContext context) {
    return                   GestureDetector(
        onTap: (){
          onTab();
        },
        child: IntrinsicWidth(
          child: Column(children: [

            Text(name.tr,style: selected?AppStyles.primaryStyle(bold: true,size: fontSize):AppStyles.subTitleStyle(bold: true,size: fontSize),),
            if(selected)

Row(children: [
  Expanded(child: Container(
    margin: EdgeInsets.only(top: 5,bottom: 5,),
    height: 5,
    decoration: BoxDecoration(color: AppColors.primaryColorGreen,
    borderRadius: BorderRadius.circular(5)
    ),
  ))

],)

            else Container(height: 20,)


          ],),
        ))
    ;
  }
}
