import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/pcr_model.dart';
import 'package:sehati_app/repositories/service_repository.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';

class PCRServicesLogic extends BaseController {

  final ServiceRepository _serviceRepository=ServiceRepository();

  late PcrModel? selectedItem;

 final List<PcrModel> items=[
];


updateItemsAdd( PcrModel item){
  if(item.quantity<10) {
    items[ items.indexOf(item)].quantity++;
  }
update();
}

  updateItemsSub( PcrModel item){

  if(item.quantity>1) {
    items[ items.indexOf(item)].quantity--;
  }
    update();
  }


   navToTimeSlots(){
     if(selectedItem!=null){

       Get.toNamed(AppRouteNames.bookingPeriod);

     }else{
       buildFailedSnackBar(msg: AppStrings.selectMsg.tr);
     }


   }
   @override
  void onInit() async{
    // TODO: implement onInit
    super.onInit();
    setBusy(true);

    var data=await  _serviceRepository.getPCRServicesList();

    print(data.length);
    items.addAll(data.where((element) => element.type=='PCR'));



    setBusy(false);
    update();
  }


}
