/*
 * Copyright (c) 2020 .
 */

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AccountLinkWidget extends StatelessWidget {
  final IconData? icon;
  final Widget? text;
  final VoidCallback? onTap;

  const AccountLinkWidget({
    Key? key,
    this.icon,
    this.text,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      // onTap: (){
      //   if(onTap!=null){
      //   onTap!.call(e);}
      // },
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 15),
        child: Row(
          children: [
        Container(


        //   height: 44,
        margin: EdgeInsets.symmetric(horizontal: 5),

        padding: EdgeInsets.symmetric(vertical: 7,horizontal: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Get.theme.colorScheme.secondary.withAlpha(45),

        ),
        child: Icon(
          icon,
          color:Get.theme.colorScheme.secondary,
        ),
      ),

            Container(
              margin: EdgeInsets.symmetric(horizontal: 5),
              width: 1,
              height: 24,
              color: Get.theme.focusColor.withOpacity(0.3),
            ),
            Expanded(
              child: text!,
            ),
            Icon(
              Icons.arrow_forward_ios,
              size: 12,
              color: Get.theme.hintColor.withOpacity(.2),
            ),
          ],
        ),
      ),
    );
  }
}
