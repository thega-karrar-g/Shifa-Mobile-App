

import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/models/nurse_service.dart';
import 'package:sehati_app/models/schedule_model.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/modules/doctor_module/doctors/doctors_controller.dart';
import 'package:sehati_app/repositories/doctor_repository.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/group_by.dart';
class DoctorScheduleLogic extends BaseController {


final  DoctorRepository _doctorRepository=DoctorRepository();
  DateTime selectedDay =DateTime.now();

  int currentIndex=0;

  List <ScheduleModel> scheduleList=[],list=[];

  String selectedSlot='';

var doctor=Get.arguments as Doctor ;




    int infoIndex=0;

  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
    setBusy(true);
PatientDataLogic.doctorName=doctor.name!;
PatientDataLogic.doctor=doctor;

// if(DoctorsController.doctorType=='TD') {
//   PatientDataLogic.price = double.parse(doctor.telePrice.toString());
// }
// else{
//   PatientDataLogic.price = double.parse(doctor.hvdPrice.toString());
//
// }

    list=await _doctorRepository.getScheduleList(id: '${doctor.id}');

var l=list.groupBy((p0) => p0.date).entries.toList();


for (var element in l) {

  List<String> t =[];
for (var s in element.value) {

  if(s.date==element.key){

    t.addAll(s.times!);
  }
}

scheduleList.add(ScheduleModel(date: element.key,times: t));


}



    if(scheduleList.isNotEmpty){
      selectedDay=scheduleList[0].date;
    }

    setBusy(false);
  }


  changeDay(int index){

    selectedDay=scheduleList[index].date;
    currentIndex=index;

    PatientDataLogic.appointmentDate=DateFormat('yyyy-M-d').format(selectedDay) +' $selectedSlot:00' ;

    update();


  }

  changeSlot(String time){


    selectedSlot=time;





    PatientDataLogic.appointmentDate=DateFormat('yyyy-M-d').format(selectedDay) +' $time:00' ;

    update();


  }

  checkSlot(String time,DateTime date)=>time==selectedSlot&&date==selectedDay  ;

  void navToPatientData() {

    if(scheduleList.isNotEmpty&&selectedSlot.isNotEmpty){

      Get.toNamed(AppRouteNames.patientData);

   //   print(PatientDataLogic.appointmentDate);
    }

    else{
      buildFailedSnackBar(msg: AppStrings.selectTimeMsg.tr);
    }


  }


  changeInfoIndex(int i){

    infoIndex=i;
    update();
  }


}
