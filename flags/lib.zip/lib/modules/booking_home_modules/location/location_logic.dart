import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/models/nurse_service.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/shared_in_ui/shared/different_dialogs.dart';
import 'package:sehati_app/utils/constants/app_images.dart';

import '../../../language_and_localization/app_strings.dart';
import '../../../utils/constants/app_route_names.dart';
import '../../doctor_module/doctors/doctors_controller.dart';

class LocationLogic extends BaseController {
  Completer<GoogleMapController> controller = Completer();

  GoogleMapController? mapController;
  // final kInitialPosition = LatLng(15.3579753, 44.2004929);

  CameraPosition kGooglePlex = CameraPosition(
    target: LatLng(24.7098869, 46.681247),
    zoom: 12.4746,
    bearing: 0,
  );

  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  MarkerId selectedMarkerId = MarkerId('markerId_1');

  LatLng? markerPosition;

  static  LatLng? currentLatLng;
  String? _currentAddress;
  static final addressController = TextEditingController(text: '');

  String nextRoute = '', code = '';

  var markerIcon = BitmapDescriptor.fromAssetImage(
      ImageConfiguration(size: Size(30, 30)), AppImages.marker);
  var greenIcon = BitmapDescriptor.fromAssetImage(
      ImageConfiguration(size: Size(50, 50)), AppImages.markerSelected);





  updateMapController(GoogleMapController controller){
    mapController=controller;
    update();
  }

  getCurrentLocation2() async {
    setBusy(true);
    await Future.delayed(Duration(milliseconds: 1500),(){

      CameraPosition(
        target: LatLng(15.3579753, 44.2004929),
        zoom: 12.4746,
        bearing: 0,
      );
setBusy(false);
    });

  }
  getCurrentLocation() async {
    setBusy(true);
    await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
        .then((Position position) async {
      currentLatLng = LatLng(position.latitude, position.longitude);

      kGooglePlex = CameraPosition(
        target: currentLatLng!,
        zoom: 12.4746,
        bearing: 0,
      );

      await getAddress(currentLatLng!);
      setBusy(false);
      update();
    }).catchError((e) {});
  }

  // Method for retrieving the current address
  getAddress(LatLng latLng) async {
    try {
      currentLatLng = latLng;
      List<Placemark> p = await placemarkFromCoordinates(
          latLng.latitude, latLng.longitude,
          localeIdentifier: Get.locale.toString());

      Placemark place = p[0];
      _currentAddress =
          "${place.street}, ${place.subLocality ?? ''}, ${place.locality ?? ''} , ${place.administrativeArea ?? ''}, ${place.country}";
      addressController.text = _currentAddress!;


      print(_currentAddress);

      final Marker marker = Marker(
        markerId: selectedMarkerId,
        position: currentLatLng!,
        // icon: bitmapIcon,
        //  infoWindow: InfoWindow(title: AppStrings.selectedLocation.tr,
        //
        //       snippet: addressController.text
        //  ,onTap: ()async{
        // var c= await  controller.future;
        // c.hideMarkerInfoWindow(selectedMarkerId);
        //
        //      }
        //  ),
        onTap: () => _onMarkerTapped2(selectedMarkerId),
        // consumeTapEvents: true,
        // draggable: true
        // onDragEnd: (LatLng position) => _onMarkerDragEnd(markerId, position),
        //onDrag: (LatLng position) => _onMarkerDrag(markerId, position),
      );
      markers[selectedMarkerId] = marker;

      update();
    } catch (_) {}
  }







  @override
  void onInit() async{
    // TODO: implement onInit
    super.onInit();
 //   mapController=GoogleMapController();
    HomeService homeService = Get.arguments;
    PatientDataLogic.audioFile = null;
    PatientDataLogic.attachFile = null;
    PatientDataLogic.cameraFile = null;
    PatientDataLogic.service2 = NurseService();
    PatientDataLogic.service3 = NurseService();
    PatientDataLogic.showFiles = true;
    PatientDataLogic.patientComment.clear();
    PatientDataLogic.doctor.name='';
    PatientDataLogic.doctor.nameAr='';
    nextRoute = homeService.next;
    // var slide=Slide.slides.where((element) => element.code==homeService.code,).first;
    //
    //
    // Future<Null>.delayed(Duration.zero, () {
    //   DifferentDialog.showServiceInfoSnackBar(description: slide.description!.tr,title: slide.title!.tr,image: slide.image!);
    // });
//getUserLocation();
    if (currentLatLng==null) {
      getCurrentLocation();

    }
    else{
      kGooglePlex = CameraPosition(
        target: currentLatLng!,
        zoom: 12.4746,
        bearing: 0,
      );

      await getAddress(currentLatLng!);
    }
  }

  void _onMarkerTapped2(MarkerId markerId) async {
    DifferentDialog.selectedLocationBottomSheet(desc: addressController.text);
  }

  Future<bool> isLocationAvailable() async {
    List<Placemark> p = await placemarkFromCoordinates(
        currentLatLng!.latitude, currentLatLng!.longitude,
        localeIdentifier: Get.locale.toString());
    Placemark place = p[0];

    if (place.locality.toString().trim() == 'Riyadh' ||
        place.locality.toString().trim() == 'الرياض') {
      return true;
    } else {
      return false;
    }
  }

  navToNext() async {
    if (addressController.text.isNotEmpty) {
      PatientDataLogic.location = LocationLogic.addressController.text;

      if (await isLocationAvailable()) {
        if (nextRoute == AppRouteNames.register) {
          Get.back(result: LocationLogic.addressController.text);
        } else {
          if (nextRoute == AppRouteNames.doctors) {
            DoctorsController.doctorType = 'HVD';
          }
          Get.toNamed(nextRoute, arguments: nextRoute);
        }
      } else {
        buildFailedSnackBar(
            msg: AppStrings.selectLocationOutRangeMsg.tr, duration: 8);
      }
    } else {
      buildFailedSnackBar(msg: AppStrings.selectLocationMsg.tr);
    }
  }

  Future<bool> loading() async {
    await Future.delayed(Duration(seconds: 6));
    return true;
  }
}
