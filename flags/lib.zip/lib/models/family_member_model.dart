class FamilyMember {
  FamilyMember({
    required this.name,
    required this.relation,
    required this.age,
     this.deceased=false,
  });

  String name;
  String relation;
  int age;
  bool deceased;

  factory FamilyMember.fromJson(Map<String, dynamic> json) => FamilyMember(
        name: json["name"],
        relation: json["relation"],
        age: json["age"],
        deceased: json["deceased"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "relation": relation,
        "age": age,
        "deceased": deceased,
      };
}
