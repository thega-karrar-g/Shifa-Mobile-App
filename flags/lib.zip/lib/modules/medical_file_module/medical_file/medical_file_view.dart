import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/modules/medical_file_module/medical_file/widgets/medical_file_item.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_grid.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/grid_aspect_ratio.dart';

import 'medical_file_logic.dart';

class MedicalFilePage extends StatelessWidget {
  final logic = Get.put( MedicalFileLogic());

   MedicalFilePage({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: UiHelper.safeAreaPaddingHome,
      child: SizedBox(
        // color: AppColors.bodyBgColor.withOpacity(.9),
        child: Column(
          children: [


            myAppBar3(title: AppStrings.medicalFile,withBack: false,h: 20),

            UiHelper.verticalSpaceMedium,

            Expanded(
              child:
              DynamicGridView(
                data: logic.services,
                count: 2,
                mainSpacing: 50,
                crossSpacing: 15,

                aspectRatio: GridAspectRatio.aspectRatio(count: 2,height: 180),
                itemBuilder: (item){
                  return MedicalFileItem(homeService: item as HomeService,);
                },
              )


              // GridView.builder(
              //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              //     crossAxisCount: 2,
              //     crossAxisSpacing: 15.0,
              //     mainAxisSpacing: 35.0,
              //     childAspectRatio: GridAspectRatio.aspectRatio(count: 2,height: 240),
              //   ),
              //   itemCount: logic.services.length,
              //   itemBuilder: (bc,index)=>MedicalFileItem(homeService: logic.services[index],),
              //
              //   padding: const EdgeInsets.symmetric(horizontal: 0,vertical: 20),
              //
              //
              //   primary: false,
              //
              // ),

            ),

          ],
        ),
      ),
    );
  }
}
