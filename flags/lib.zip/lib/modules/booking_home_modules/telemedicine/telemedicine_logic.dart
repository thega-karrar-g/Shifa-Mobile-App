import 'package:get/get.dart';

class TelemedicineLogic extends GetxController {

}
