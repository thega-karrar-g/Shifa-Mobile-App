import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_fonts.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import '../controllers/language_controller.dart';

class LanguageView extends GetView<LanguageController> {
  final bool hideAppBar;

  LanguageView({Key? key, this.hideAppBar = false}) : super(key: key);
  @override
  final controller = Get.put(LanguageController());

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: ListView(
      primary: true,
      children: [

        myAppBar2(title: AppStrings.changeLanguage),

        Column(
          children: List.generate(controller.languages.length, (index) {
            var _lang = controller.languages.elementAt(index);
             bool selected=_lang==Get.locale.toString();

            return Container(
              margin: EdgeInsets.symmetric(vertical: 5),
              child: Theme(
                data: ThemeData(unselectedWidgetColor: AppColors.primaryColor,

                fontFamily: AppFonts.mainFontFamily

                ),
                child: RadioListTile(

                  activeColor:  AppColors.white,
                 // selectedTileColor: AppColors.primaryColorGreen,
                  tileColor:selected? AppColors.primaryColor:AppColors.primaryColorOpacity,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                  value: _lang,
                  groupValue: Get.locale.toString(),
                  onChanged: (value) {
                    controller.updateLocale(value);
                  },
                  title: Text(_lang.tr, style: selected?AppStyles.whiteStyle(bold: true):AppStyles.primaryStyle(bold: true)),
                ),
              ),
            );
          }).toList(),
        )
      ],
    ));
  }
}
