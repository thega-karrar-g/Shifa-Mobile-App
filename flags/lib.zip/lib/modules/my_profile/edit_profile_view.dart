import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/my_profile/widgets/edit_profile_form.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'my_profile_logic.dart';

class EditProfilePage extends StatelessWidget {
  final MyProfileLogic logic = Get.put(MyProfileLogic());
  final double paddingHeight = 25.0;

  final String fullNameKey = 'name';
  final String emailKey = 'name';
  final String ssnKey = 'ssn';

  final labelStyle = TextStyle(
      color: AppColors.black54, fontWeight: FontWeight.bold, fontSize: 13);
  final OutlineInputBorder outlineInputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.all(
        Radius.circular(25)),
    borderSide: BorderSide(
        color:
        AppColors.registerFiled)
    ,
  );

   EditProfilePage({Key? key}) : super(key: key);

  FormGroup buildForm() =>
      fb.group(<String, Object>{
        fullNameKey: FormControl<String>(
          value: logic.currentUser!.name,
          validators: [
            Validators.required,
          ],
        ),

        emailKey: FormControl<String>(
          value: logic.currentUser!.email,

          validators: [
            Validators.required,
          ],
        ),


        ssnKey: FormControl<String>(
          value: logic.currentUser!.ssn,

          validators: [Validators.required, Validators.number],
        ),
        // 'dob': FormControl<DateTime>(),


      });

  final TextStyle style =
  Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.white));

  final radius=50.0;
  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: SizedBox(
      // color: AppColors.bodyBgColor.withOpacity(.9),
      child: GetBuilder<MyProfileLogic>(builder: (logic) {
        return GestureDetector(
          onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
          child: Column(
            children: [


              myAppBar2(title: AppStrings.editProfile,),


              Stack(
                clipBehavior: Clip.none,
                children: [

                  Container(
                    padding: EdgeInsets.all(3),
                    decoration: BoxDecoration(
                        color: AppColors.primaryColorOpacity,

                        shape: BoxShape.circle
                    ),
                    child: Ui.circluarImgRadiusBase64(url: logic.currentUser!
                        .imageUrl!, size: 100,rTR: radius,rTL: radius,rBR: radius,rBL: radius,margin: 0),

                  ),

                  Positioned.fill(
                      bottom: 5,
                      child: Align(
                          alignment: Get.locale.toString() == 'ar' ? Alignment
                              .bottomLeft : Alignment.bottomRight,
                          child: GestureDetector(
                            onTap: () {
                              logic.pickFiles();
                            },

                            child: Container(
                              padding: EdgeInsets.all(5),
                              //  height: 25,
                              decoration: BoxDecoration(
                                  color: AppColors.primaryColorGreen,
                                  borderRadius: BorderRadius.circular(10)
                              ),
                              child: Icon(
                                Icons.edit, size: 18, color: AppColors.white,),


                            ),
                          ))),


                ],),
              UiHelper.verticalSpaceSmall,
              Text(AppStrings.editImage.tr, style: AppStyles.primaryStyle(),),

              UiHelper.verticalSpaceSmall,
              Expanded(child: SingleChildScrollView(child: EditProfileForm()))


            ],
          ),
        );
      }),
    ));
  }
}
