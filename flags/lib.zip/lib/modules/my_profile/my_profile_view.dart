import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/modules/medical_file_module/medical_file/widgets/medical_file_item.dart';
import 'package:sehati_app/modules/my_profile/widgets/profile_row.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_grid.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/grid_aspect_ratio.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'my_profile_logic.dart';

class MyProfilePage extends StatelessWidget {
  final MyProfileLogic logic = Get.put(MyProfileLogic());

   MyProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      minimum: UiHelper.safeAreaPaddingHome,
      child: SizedBox(
        // color: AppColors.bodyBgColor.withOpacity(.9),
        child: GetBuilder<MyProfileLogic>(builder: (logic) {

          var nationality=logic.currentUser!.nationality!.contains('KSA')?AppStrings.saudi.tr:AppStrings.nonSaudi.tr;
  return
    logic.checkUserSignIn?
    Column(
          children: [


            myAppBar3(title: AppStrings.myProfile,withBack: false,h: 20),

UiHelper.verticalSpaceSmall,

            Container(
              decoration: BoxDecoration(
                  color: AppColors.primaryColorOpacity,
                  borderRadius: BorderRadius.circular(10)
              ),
              child: IntrinsicHeight(
                child: Column(
                  children: [
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.only( left: 20,right: 20,top: 15),
                              child: Column(
                                children: [

                                  Row(
                                    children: [
                                      Expanded(child: Text(logic.currentUser!.name,style: AppStyles.primaryStyle(bold: true,size: 16),)),
                                    ],
                                  ),
                                  UiHelper.verticalSpaceSmall,
                                  ProfileRow(iconData: AppImages.phoneCall,title: logic.currentUser!.phone,),


                                  ProfileRow(iconData: AppImages.nationality,title: nationality,),

                                ],
                              ),
                            ),
                          ),
                          UiHelper.horizontalSpaceSmall,

Column(children: [

  GestureDetector(
    onTap: (){
logic.navToEdit();
    },
    child: Stack(
     clipBehavior: Clip.none ,
      children: [

      Container(
        decoration: BoxDecoration(
          color: AppColors.primaryGreenOpacityColor,
          borderRadius: BorderRadius.circular(10)
        ),
        child:
        //Container()
        Ui.circluarImgRadiusBase64(url: logic.currentUser!.imageUrl!,rTL: 10,rBR: 10,rBL: 10,rTR: 10,margin: 0),

      ),

      Positioned.fill(
          bottom: -15,
          child: Align(
          alignment:Get.locale.toString()=='ar'? Alignment.bottomRight:Alignment.bottomLeft,
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 3,horizontal: 10),
            height: 25,
            decoration: BoxDecoration(
              color: AppColors.primaryColorGreen,
              borderRadius: BorderRadius.only(
                      topRight: Radius.circular( Get.locale.toString()=='ar'? 0:15),
                      topLeft: Radius.circular( Get.locale.toString()=='ar'? 15:0),
                      bottomRight: Radius.circular( 15),
                      bottomLeft: Radius.circular( 15),
              )
            ),
            child: Icon(Icons.edit,size: 18,color: AppColors.white,),


          )))

    ],),
  ),


  Spacer()

],)

                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric( horizontal: 20,vertical: 0),
                      child: Column(
                        children: [
                          ProfileRow(iconData: AppImages.email,title: logic.currentUser!.email,),
                        //  ProfileRow(iconData: AppImages.location,title: logic.currentUser!.location,),
                        ],
                      ),
                    ),

                    UiHelper.verticalSpaceMedium,

                  ],
                ),
              ),

            ),
            Expanded(
              child:

                  DynamicGridView(
                    data: logic.services,
                    count: 2,
                    mainSpacing: 35,
                    crossSpacing: 15,

                    aspectRatio: GridAspectRatio.aspectRatio(count: 2,height: 170),
                    itemBuilder: (item){
                      return MedicalFileItem(homeService: item as HomeService,);
                    },
                  )


              // GridView.builder(
              //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              //     crossAxisCount: 2,
              //     crossAxisSpacing: 15.0,
              //     mainAxisSpacing: 35.0,
              //     childAspectRatio: GridAspectRatio.aspectRatio(count: 2,height: 240),
              //   ),
              //   itemCount: logic.services.length,
              //   itemBuilder: (bc,index)=>MedicalFileItem(homeService: logic.services[index],primary: index==0||index==3,),
              //
              //   padding: const EdgeInsets.symmetric(horizontal: 0,vertical: 20),
              //
              //
              //   primary: false,
              //
              // ),

            ),




          ],
        ):Container();
}),
      ),
    );
  }
}
