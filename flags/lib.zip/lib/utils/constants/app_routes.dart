import 'package:get/get.dart';
import 'package:sehati_app/modules/aboutus/about_view.dart';
import 'package:sehati_app/modules/account/views/account_view.dart';
import 'package:sehati_app/modules/appointment/appointment_view.dart';
import 'package:sehati_app/modules/auth/views/change_password_view.dart';
import 'package:sehati_app/modules/auth/views/change_phone_view.dart';
import 'package:sehati_app/modules/auth/views/complete_register_view.dart';
import 'package:sehati_app/modules/auth/views/login_view.dart';
import 'package:sehati_app/modules/auth/views/profile_view.dart';
import 'package:sehati_app/modules/auth/views/register2_view.dart';
import 'package:sehati_app/modules/auth/views/register_guest_view.dart';
import 'package:sehati_app/modules/auth/views/success_register.dart';

import 'package:sehati_app/modules/booking_home_modules/book_doctor_period/book_doctor_period_binding.dart';
import 'package:sehati_app/modules/booking_home_modules/book_doctor_period/book_doctor_period_view.dart';
import 'package:sehati_app/modules/booking_home_modules/book_invoice/book_invoice_view.dart';
import 'package:sehati_app/modules/booking_home_modules/choose_date_period/choose_date_period_binding.dart';
import 'package:sehati_app/modules/booking_home_modules/choose_date_period/choose_date_period_view.dart';
import 'package:sehati_app/modules/booking_home_modules/home_visit/home_visit_view.dart';
import 'package:sehati_app/modules/booking_home_modules/insurance/insurance_view.dart';
import 'package:sehati_app/modules/booking_home_modules/location/location_view.dart';
import 'package:sehati_app/modules/booking_home_modules/meeting/meeting_view.dart';
import 'package:sehati_app/modules/booking_home_modules/nurse_services/nurse_services_view.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_view.dart';
import 'package:sehati_app/modules/booking_home_modules/payment_methods/payment_methods_binding.dart';
import 'package:sehati_app/modules/booking_home_modules/payment_methods/payment_methods_view.dart';
import 'package:sehati_app/modules/booking_home_modules/payment_methods_details/payment_methods_details_binding.dart';
import 'package:sehati_app/modules/booking_home_modules/payment_methods_details/payment_methods_details_view.dart';
import 'package:sehati_app/modules/booking_home_modules/pcr/choose_date/choose_date_binding.dart';
import 'package:sehati_app/modules/booking_home_modules/pcr/choose_date/choose_date_view.dart';
import 'package:sehati_app/modules/booking_home_modules/pcr/fill_data/fill_data_view.dart';
import 'package:sehati_app/modules/booking_home_modules/pcr/pcr_services/pcr_services_view.dart';
import 'package:sehati_app/modules/booking_home_modules/physiotherapist/physiotherapist_view.dart';
import 'package:sehati_app/modules/booking_home_modules/radiology_lab/radiology_lab_files/radiology_lab_files_view.dart';
import 'package:sehati_app/modules/booking_home_modules/radiology_lab/radiology_lab_services/radiology_lab_services_view.dart';
import 'package:sehati_app/modules/booking_home_modules/radiology_lab/radiology_lab_types/radiology_lab_types_view.dart';
import 'package:sehati_app/modules/booking_home_modules/service_details/service_details_view.dart';
import 'package:sehati_app/modules/booking_home_modules/sleep_questionnaire/sleep_questionnaire_view.dart';
import 'package:sehati_app/modules/booking_home_modules/telemedicine/book_doctor/book_doctor_binding.dart';
import 'package:sehati_app/modules/booking_home_modules/telemedicine/book_doctor/book_doctor_view.dart';
import 'package:sehati_app/modules/booking_home_modules/vaccination/vaccination_view.dart';
import 'package:sehati_app/modules/doctor_module/doctor_schedule/doctor_schedule_view.dart';
import 'package:sehati_app/modules/doctor_module/doctors/views/doctor_details.dart';
import 'package:sehati_app/modules/doctor_module/doctors/views/doctors_view.dart';
import 'package:sehati_app/modules/drawer_module/contactus/contactus_view.dart';
import 'package:sehati_app/modules/drawer_module/faq/faq_view.dart';
import 'package:sehati_app/modules/drawer_module/our_services/our_services_view.dart';
import 'package:sehati_app/modules/drawer_module/patient_responsibilities/responsibility_view.dart';
import 'package:sehati_app/modules/drawer_module/privacy_policy/privacy_policy_view.dart';
import 'package:sehati_app/modules/drawer_module/settings/views/language_view.dart';
import 'package:sehati_app/modules/drawer_module/settings/views/theme_mode_view.dart';
import 'package:sehati_app/modules/drawer_module/terms_of_services/terms_of_services_view.dart';

import 'package:sehati_app/modules/home_screen/home_screen_view.dart';

// import 'package:sehati_app/modules/booking/booking_view.dart';
// import 'package:sehati_app/modules/doctors/doctors_view.dart';
// import 'package:sehati_app/modules/emergency/emergency_view.dart';
import 'package:sehati_app/modules/home_tabs/home_tabs_view.dart';
import 'package:sehati_app/modules/medical_file_module/lab_test/views/labtest_view.dart';
import 'package:sehati_app/modules/medical_file_module/medical_file/medical_file_binding.dart';
import 'package:sehati_app/modules/medical_file_module/medical_file/medical_file_view.dart';
import 'package:sehati_app/modules/medical_file_module/prescriptions/views/prescription_view.dart';

import 'package:sehati_app/modules/my_profile/edit_profile_view.dart';
import 'package:sehati_app/modules/my_profile/my_profile_view.dart';
import 'package:sehati_app/modules/notifications/notifications_binding.dart';
import 'package:sehati_app/modules/notifications/notifications_view.dart';
import 'package:sehati_app/modules/payment/views/payment_confirm.dart';
import 'package:sehati_app/modules/payment/views/payment_view.dart';

import 'package:sehati_app/utils/constants/app_route_names.dart';

import '../../modules/booking_home_modules/receipt_payment/receipt_page.dart';

class AppRoutes {

  static const transition=Transition.leftToRightWithFade;
  static const duration=Duration(milliseconds: 500);
  static const durationHome=Duration(milliseconds: 500);

  static final List<GetPage> allRoutes = [
    GetPage(
      name: AppRouteNames.intro,
      page: () => OurServices(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.login,
      page: () => LoginPage(),
      transitionDuration: duration,
      transition: transition
    ),
    GetPage(
      name: AppRouteNames.home,
      page: () => HomeTabsView(),
    ),
    GetPage(
      name: AppRouteNames.doctors,
      page: () => DoctorsPage(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.doctorsDetails,
      page: () => DoctorDetailsPage(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.prescriptions,
      page: () => PrescriptionsPage(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.homeAppointment,
      page: () => AppointmentPage(),
      transition: Transition.leftToRight,
      transitionDuration: durationHome

    ),
    GetPage(
      name: AppRouteNames.homeBookNow,
      page: () => HomeScreenView(),
      transition: Transition.leftToRight,
        transitionDuration: durationHome

    ),
    GetPage(
      name: AppRouteNames.homeMedicalFile,
      page: () => MedicalFilePage(),
      transition: Transition.leftToRight,
        transitionDuration: durationHome

    ),
    GetPage(
      name: AppRouteNames.homeProfile,
      page: () => MyProfilePage(),
      transition: Transition.leftToRight,
        transitionDuration: durationHome

    ),

    GetPage(
      name: AppRouteNames.payment,
      page: () => PaymentPage(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.insurance,
      page: () => InsurancePage(),
        transitionDuration: duration,
        transition: transition
    ),

    GetPage(
      name: AppRouteNames.confirmPayment,
      page: () => PaymentConfirm(),
    ),

    GetPage(
      name: AppRouteNames.labTest,
      page: () => LabTestPage(),
        transitionDuration: duration,
        transition: transition
    ),



    GetPage(
      name: AppRouteNames.themeMode,
      page: () => ThemeModeView(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.language,
      page: () => LanguageView(),
        transitionDuration: duration,
        transition: transition
    ),
    // GetPage(name: AppRouteNames.emergncy, page: () => EmergencyPage(),),
    GetPage(
      name: AppRouteNames.register,
      page: () => Register2Page(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.successRegister,
      page: () => SuccessRegister(),
    ),
    GetPage(
      name: AppRouteNames.completeRegister,
      page: () => CompleteRegisterPage(),
    ),


    GetPage(
      name: AppRouteNames.account,
      page: () => AccountView(),

    ),
    GetPage(
      name: AppRouteNames.profile,
      page: () => ProfilePage(),
        transitionDuration: duration,
        transition: transition
    ),





    ////////////
    GetPage(
      name: AppRouteNames.map,
      //page: () => LocationTestPage(),
      page: () => LocationPage(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.nurseServices,
      page: () => NurseServicesPage(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.vaccination,
      page: () => VaccinationPage(),
        transitionDuration: duration,
        transition: transition
    ),
    GetPage(
      name: AppRouteNames.physiotherapistServices,
      page: () => PhysiotherapistPage(),
        transitionDuration: duration,
        transition: transition
    ),



    GetPage(
        name: AppRouteNames.editPassword,
        page: () => ChangePasswordPage(),
        transition: transition,
        transitionDuration: duration
    ),


    GetPage(
        name: AppRouteNames.editPhone,
        page: () => ChangePhonePage(),
        transition: transition,
        transitionDuration: duration
    ),














    GetPage(
        name: AppRouteNames.doctorBook,
        page: () => BookDoctorPage(),
        binding:  BookDoctorBinding(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.paymentMethods,
        page: () => PaymentMethodsPage(),
        binding:  PaymentMethodsBinding(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.paymentMethodDetails,
        page: () => PaymentMethodDetailsPage(),
        binding:  PaymentMethodDetailsBinding(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.bookingPeriod,
        page: () => BookDoctorPeriodPage(),
        binding:  BookDoctorPeriodBinding(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.patientData,
        page: () => PatientDataPage(),
        transition: transition,
        transitionDuration: duration
    ),

    GetPage(
        name: AppRouteNames.notifications,
        page: () => NotificationsPage(),
        binding:  NotificationsBinding(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.medicalFile,
        page: () => MedicalFilePage(),
        binding:  MedicalFileBinding(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.editProfile,
        page: () => EditProfilePage(),
        transition: transition,
        transitionDuration: duration
    ),


    GetPage(
        name: AppRouteNames.termsOfService,
        page: () => TermsOfServicesPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.pcrService,
        page: () => PCRServicesPage(),
        transition: transition,
        transitionDuration: duration
    ),


    GetPage(
        name: AppRouteNames.chooseDate,
        page: () => ChooseDatePage(),
        binding:  ChooseDateBinding(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.chooseDatePeriod,
        page: () => ChooseDatePeriodPage(),
        binding:  ChooseDatePeriodBinding(),
        transition: transition,
        transitionDuration: duration
    ),


    GetPage(
        name: AppRouteNames.fillData,
        page: () => FillDataPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.serviceDetails,
        page: () => ServiceDetailsPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.homeVisit,
        page: () => HomeVisitPage(),
        transition: transition,
        transitionDuration: duration
    ),


    GetPage(
        name: AppRouteNames.contactUs,
        page: () => ContactusPage(),
        transition: transition,
        transitionDuration: duration
    ),


    GetPage(
        name: AppRouteNames.aboutUs,
        page: () => AboutPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.patientResponsibilities,
        page: () => ResponsibilityPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.privacyPolicy,
        page: () => PrivacyPolicyPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.faq,
        page: () => FAQPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.doctorSchedule,
        page: () => DoctorSchedulePage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.invoicePage,
        page: () => BookInvoicePage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.meetingPage,
        page: () => MeetingPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.radiologyPage,
        page: () => RadiologyLabServicesPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.labRadiologyTypesPage,
        page: () => RadiologyLabTypesPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.sleepQuestionnaire,
        page: () => SleepQuestionnairePage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.receiptPage,
        page: () => ReceiptPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.registerGuest,
        page: () => RegisterGuestPage(),
        transition: transition,
        transitionDuration: duration
    ),
    GetPage(
        name: AppRouteNames.radiologyLabFiles,
        page: () => RadiologyLabFilesPage(),
        transition: transition,
        transitionDuration: duration
    ),



  ];
}
