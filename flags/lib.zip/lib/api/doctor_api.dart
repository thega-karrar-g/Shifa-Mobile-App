import 'package:dio/dio.dart';
import 'package:sehati_app/utils/constants/app_urls.dart';
import 'base_api.dart';
import 'package:http/http.dart' as http;

class DoctorApi extends BaseApi {
  static final _doctorApi = DoctorApi._internal();

  factory DoctorApi() => _doctorApi;

  DoctorApi._internal();
  var doctorsUrl = AppUrls.doctors;

  Future<http.Response?> getDoctors({String  drType='TD'}) async {
    try {
       doctorsUrl += drType;
print(doctorsUrl);
      var response = await api.httpGet(doctorsUrl,);
      return response;
    } on DioError catch (_) {
      return null;

      //
    }
  }
  Future<Response?> getDoctors1({String  drType='TD'}) async {
    try {
      var response = await api.dioGet(       AppUrls.doctors + drType);
     // print(response.data.toString());
      return response;
    } on DioError catch (e) {
      return e.response;
    }
  }
  Future<Response?> getScheduleList({String  id='TD'}) async {
    try {
      var response = await api.dioGet(       AppUrls.doctorSchedule + id);
      return response;
    } on DioError catch (e) {
      return e.response;
    }
  }
}
