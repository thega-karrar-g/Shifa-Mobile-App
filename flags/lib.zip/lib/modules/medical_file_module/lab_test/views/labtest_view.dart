import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_labtest.dart';
import 'package:sehati_app/modules/medical_file_module/lab_test/widgets/labtest_list.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';

import '../../../../shared_in_ui/shared/loading.dart';
import '../labtest_controller.dart';

class LabTestPage extends GetView<LabTestController> {
  @override
  final controller = Get.put(LabTestController());

  LabTestPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: Column(
      children: [
        myAppBar2(title: AppStrings.labTests),



        Expanded(
          child: FutureBuilder<List<LabTest>>(
            future: controller.getLabTestList(),
            builder: (bc, snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                return LabTestList(
                  labtests: snapshot.data,
                );
              } else if (snapshot.connectionState ==
                  ConnectionState.waiting) {
                return Center(child: MyLoadingWidget());
              }

              return Container();
            },
          ),
        ),
      ],
    ));
  }



}
