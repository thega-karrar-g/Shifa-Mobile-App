import 'dart:convert';

import 'package:sehati_app/api/prescription_api.dart';
import 'package:sehati_app/models/m_prescription.dart';

class PrescriptionRepository {
  static final _prescriptionRepository = PrescriptionRepository._internal();

  factory PrescriptionRepository() {
    return _prescriptionRepository;
  }

  PrescriptionRepository._internal();
  final PrescriptionApi _prescriptionApi=PrescriptionApi();

  Future<List<Prescription>> getPrescriptionList() async {
   // try {
        var response= await  _prescriptionApi. getPrescriptionsHttp() ;


        var jsonData=json.decode(response!.body.toString());
        var d = jsonData['data'] as List;
      var dd = d.map((dr) {
        return Prescription.fromJson((dr));
      }).toList();


      return dd;
    // } catch (e) {
    // }

  }

  var d = [
    {
      "id": 3,
      "name": "PR0003",
      "patient": "[HP0002] Ahmed Ali ",
      "doctor": "فياض القصير جدا",
      "date": "2021-10-11 05:34:59",
      "info": "",
      "prescription_line": [
        {
          "name": "acetazolamide",
          "indication": "Cholera",
          "dose": "1",
          "start_treatment": "2021-10-02 10:58:15",
          "end_treatment": ""
        }
      ]
    },
    {
      "id": 2,
      "name": "PR0002",
      "patient": "[HP0002] Ahmed Ali ",
      "doctor": "عمر الطويل",
      "date": "2021-10-11 05:34:59",
      "info": "",
      "prescription_line": []
    },
    {
      "id": 1,
      "name": "PR0001",
      "patient": "[HP0002] Ahmed Ali ",
      "doctor": "فياض القصير جدا",
      "date": "2021-10-11 05:34:59",
      "info": "",
      "prescription_line": []
    }
  ];
}
