import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/models/m_prescription.dart';
import 'package:sehati_app/modules/medical_file_module/prescriptions/views/prescription_details.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

class PrescriptionItem2 extends StatelessWidget {
   PrescriptionItem2({this.prescription,Key? key}) : super(key: key);

 final Prescription? prescription;
  bool  ar=Get.locale.toString()=='ar';

  @override
  Widget build(BuildContext context) {

    double radius=15;

    return ListTile(
      onTap: (){
        Get.to(()=>PrescriptionDetails(prescription: prescription,));
      },
      contentPadding: EdgeInsets.only(left: 0.0, right: 0.0,top: 5,bottom: 5),
      title: SizedBox(
        height: 100,
        child: Container(
          decoration: BoxDecoration(
              color: AppColors.primaryColorOpacity,
              borderRadius: BorderRadius.circular(radius)
          ),
          child: Row(
            children: [


              Container(
                width: 90,
                height: 100,
                decoration: BoxDecoration(
                  color: AppColors.iconAppointmentColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular( Get.locale.toString()=='ar'?0: radius),
                    topRight: Radius.circular( Get.locale.toString()=='ar'?radius: 0),
                    bottomRight: Radius.circular(radius),
                    bottomLeft: Radius.circular(radius),

                  ),

                ),
                padding: EdgeInsets.all(10),
                child: SvgPicture.asset(AppImages.telemedicine,color: AppColors.primaryColor,),
              ),
              Expanded(child: Container(
                height: 100,
                padding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
                decoration: BoxDecoration(
                  color: AppColors.primaryColorOpacity,

                ),
                child: Column(children: [

                  Row(children: [
                    Expanded(child: Text('${prescription!.doctor}',maxLines: 1,overflow: TextOverflow.ellipsis,style: AppStyles.primaryStyle(bold: true,size: 16),))

                  ],),
                  UiHelper.verticalSpaceSmall,

                  Row(children: [
                    Expanded(child: Text('${prescription!.name}',maxLines: 1,overflow: TextOverflow.ellipsis,style: AppStyles.subTitleStyle(bold: true,size: 13),))

                  ],),
                  UiHelper.verticalSpaceSmall,

                  Row(children: [
                    Text(DateFormat(' MMM ').format((prescription!.date)),style: AppStyles.primaryStyleGreen(bold: true,size: 12),),
                    Text( DateFormat(' yyyy ').format((prescription!.date)),style: AppStyles.subTitleStyle(bold: true,size: 12),),
                    Text( DateFormat(' d ').format((prescription!.date)),style: AppStyles.primaryStyleGreen(bold: true,size: 12),),
                    Text( DateFormat(' HH:mm a').format((prescription!.date)),style: AppStyles.subTitleStyle(bold: true,size: 12),),



                    UiHelper.horizontalSpaceMedium,SvgPicture.asset(AppImages.calendar),

                  ],),

                ],),

              )),
              Container(
                width: 30,
                height: 100,


                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.primaryColorGreen,
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular( ar?0: radius),
                    bottomRight: Radius.circular( ar?0: radius),

                    topLeft: Radius.circular( ar? radius:0),
                    bottomLeft: Radius.circular( ar? radius:0),
                  ),

                ),
                padding: EdgeInsets.symmetric(horizontal: 5),
                child: CircleAvatar(
                    backgroundColor: AppColors.white,
                    radius: 15,
                    child: Icon(Icons.arrow_forward_ios_rounded,size: 18,color: AppColors.primaryColorGreen,)),
              ),



            ],
          ),
        ),
      ),
    );





  }
}
