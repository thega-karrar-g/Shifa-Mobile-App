import 'dart:convert';

import 'package:sehati_app/api/labtest_api.dart';
import 'package:sehati_app/models/m_labtest.dart';

class LabTestRepository{


  static final _labTestRepository = LabTestRepository._internal();
  factory LabTestRepository() {
    return _labTestRepository;

  }

  LabTestRepository._internal();


  final LabTestApi _prescriptionApi=LabTestApi();


  Future< List<LabTest>> getLabTestList()async{


    try{


     var response= await  _prescriptionApi. getLabTest() ;

      var jsonData = json.decode(response!.body.toString());

     var d = jsonData['data'] as List;


      var dd = d.map((dr) {
        return LabTest.fromJson((dr));

      }).toList();


      return dd;






    }catch(_){

    }


    return [];
  }
  Future< List<LabTest>> getLabTestList1()async{


    try{


      var response= await  _prescriptionApi. getlabTest1() ;

      var d=response?.data['data'] as List;

      var dd = d.map((dr) {
        return LabTest.fromJson((dr));

      }).toList();


      return dd;






    }catch(_){

    }


    return [];
  }

var d= [
  {
    "id": 2,
    "name": "LT000002",
    "patient": "[HP0002] Ahmed Ali ",
    "pathologist": "سعيد  صالح",
    "test_type": "Semen Analysis",
    "requestor": "",
    "date_requested": "2021-10-11 10:59:28",
    "date_analysis": "2021-10-11 11:00:57",
    "results": "",
    "state": "Test In Progress",
    "lab_test_criteria": [
      {
        "name": "Physical Examination",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Color",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Volume",
        "result": "",
        "normal_range": "1.0 - 6.5",
        "unit": "mL"
      },
      {
        "name": "Reaction",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Viscosity",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Liquefaction Time",
        "result": "",
        "normal_range": "20 - 60",
        "unit": "minutes"
      },
      {
        "name": "Microscopic Examination",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Motility",
        "result": "",
        "normal_range": "> 50",
        "unit": "%"
      },
      {
        "name": "Progressive",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Non Progressive",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Non Motile",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Total Sperm Count",
        "result": "",
        "normal_range": "60-150",
        "unit": "Millions/cc"
      },
      {
        "name": "Morphology",
        "result": "",
        "normal_range": "> 4",
        "unit": "%"
      },
      {
        "name": "Pus Cells",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "RBCs",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Epithelial Cells",
        "result": "",
        "normal_range": "",
        "unit": "False"
      },
      {
        "name": "Spermatogonic Cells",
        "result": "",
        "normal_range": "",
        "unit": "False"
      }
    ]
  },
  {
    "id": 1,
    "name": "LT000001",
    "patient": "[HP0002] Ahmed Ali ",
    "pathologist": "سعيد  صالح",
    "test_type": "Complete Blood Count",
    "requestor": "",
    "date_requested": "2021-10-11 10:39:59",
    "date_analysis": "2021-10-13 10:40:02",
    "results": "",
    "state": "Draft",
    "lab_test_criteria": [
      {
        "name": "Hemoglobin",
        "result": "13",
        "normal_range": "11.0 - 16.0",
        "unit": "g/dL"
      },
      {
        "name": "RBC",
        "result": "4.2",
        "normal_range": "3.5 - 5.5",
        "unit": "10^6/uL"
      },
      {
        "name": "HCT",
        "result": "45",
        "normal_range": "37.0 - 50.0",
        "unit": "%"
      },
      {
        "name": "MCV",
        "result": "80",
        "normal_range": "82 - 95",
        "unit": "fl"
      },
      {
        "name": "MCH",
        "result": "30",
        "normal_range": "27 - 31",
        "unit": "pg"
      },
      {
        "name": "MCHC",
        "result": "34",
        "normal_range": "32.0 - 36.0",
        "unit": "g/dL"
      },
      {
        "name": "RDW-CV",
        "result": "12",
        "normal_range": "11.5 - 14.5",
        "unit": "%"
      },
      {
        "name": "RDW-SD",
        "result": "38",
        "normal_range": "35 - 56",
        "unit": "fl"
      },
      {
        "name": "WBC",
        "result": "8",
        "normal_range": "4.5 - 11",
        "unit": "10^3/uL"
      },
      {
        "name": "NEU%",
        "result": "50",
        "normal_range": "40 - 70",
        "unit": "%"
      },
      {
        "name": "LYM%",
        "result": "35",
        "normal_range": "20 - 45",
        "unit": "%"
      },
      {
        "name": "MON%",
        "result": "8",
        "normal_range": "2 - 10",
        "unit": "%"
      },
      {
        "name": "EOS%",
        "result": "3",
        "normal_range": "1 - 6",
        "unit": "%"
      },
      {
        "name": "BAS%",
        "result": "1",
        "normal_range": "0 - 2",
        "unit": "%"
      },
      {
        "name": "LYM#",
        "result": "2",
        "normal_range": "1.5 - 4.0",
        "unit": "10^3/uL"
      },
      {
        "name": "GRA#",
        "result": "6",
        "normal_range": "2.0 - 7.5",
        "unit": "10^3/uL"
      },
      {
        "name": "PLT",
        "result": "320",
        "normal_range": "150 - 450",
        "unit": "10^3/uL"
      },
      {
        "name": "ESR",
        "result": "16",
        "normal_range": "Up to 15",
        "unit": "mm/hr"
      }
    ]
  }
];

}