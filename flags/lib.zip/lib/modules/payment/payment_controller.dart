
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/repositories/appointment_repository.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';

class PaymentController extends BaseController {

 static int? doctorId=0;
 final AppointmentRepository _appointmentRepository=AppointmentRepository();

 TextEditingController cardNumberController=TextEditingController(text: '');
 TextEditingController cvcController=TextEditingController(text: '');
 TextEditingController expDteController=TextEditingController(text: '');

static String  route='';


 bool  isLoad=false;
  isLoading(bool load){
  isLoad=load;
  update();

}


bool isValid(){


    if(cardNumberController.text.length==19&&cvcController.text.length==3&&expDteController.text.length==5) {
      return true;
    }

    return false;
}





 makeBooking()async{

   //var data={'patient_id':int.parse(authService.currentUser!.id??'0'),'doctor_id':doctorId,'appointment_date':appointmentDate};
   var data={'patient_id':authService.currentUser!.id,'doctor_id':'${BaseController.doctorId}',
     'appointment_date':BaseController.appointmentDate,'payment_type':'cash',
     'service':BaseController.service,
     'location':BaseController.location,


   };


   try {
     isLoading(true);
   var result=await  _appointmentRepository.makeBooking(data: data);
buildSuccessSnackBar(msg: result);

if(result.contains('successfully')){

  Get.offAndToNamed(AppRouteNames.confirmPayment);

}
     isLoading(false);
   }
   catch(_){
     isLoading(false);
   }

 }

  setCvc(String txt){

    cvcController.text=txt;
    update();
  }
  setCardNumber(String txt){

    cardNumberController.text=txt;
    update();
  }
  setExpDate(String txt){

    expDteController.text=txt;
    update();
  }

@override
  void onInit() {
    // TODO: implement onInit
    super.onInit();

    print('from  payment');
    print(BaseController.appointmentDate);

  }
}
