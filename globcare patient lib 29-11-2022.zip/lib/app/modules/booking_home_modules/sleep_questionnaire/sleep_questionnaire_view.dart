import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:reactive_forms/reactive_forms.dart';

import '../../../core/language_and_localization/app_strings.dart';
import '../../../core/theme_helper/app_colors.dart';
import '../../../global_widgets/form_widgets/reactive_text_form.dart';
import '../../../global_widgets/shared/dynamic_column.dart';
import '../../../global_widgets/shared/my_appbar.dart';
import '../../../global_widgets/shared/ui_helpers.dart';
import '../../../global_widgets/ui.dart';
import 'sleep_questionnaire_logic.dart';
import 'widgets/question_row.dart';

class SleepQuestionnairePage extends StatelessWidget {
  final SleepQuestionnaireLogic logic = Get.put(SleepQuestionnaireLogic());
  final double paddingHeight = 25.0;
  final labelStyle = TextStyle(
      color: AppColors.subTitleColor,
      fontWeight: FontWeight.bold,
      fontSize: 13);
  final OutlineInputBorder outlineInputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(15)),
    borderSide: BorderSide(color: AppColors.subTitleColor),
  );

  final TextStyle style =
      Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.white));

  SleepQuestionnairePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(
        child: Column(
      children: [
        myAppBar2(title: AppStrings.sleepQuestionnaire),
        UiHelper.verticalSpaceMedium,
        Expanded(
          child: SingleChildScrollView(
            child: GetBuilder<SleepQuestionnaireLogic>(builder: (logic) {
              return DynamicColumn(
                children: [
                  ReactiveForm(
                    formGroup: logic.form,
                    child: Column(
                      children: [
                        // Column(
                        //   mainAxisAlignment: MainAxisAlignment.start,
                        //   children: [
                        //     Row(children: [
                        //       Ui.titleGreenUnderLine(
                        //           AppStrings.patientData.tr, bottomPadding: 8),
                        //
                        //     ],),
                        //   ],),
                        // UiHelper.verticalSpaceSmall,
                        //
                        //
                        // Row(children: [
                        //   ReactiveTextForm.reactiveTextFieldSleepQu(
                        //       formControlName: logic.nameKey,
                        //       validationMessage: AppStrings
                        //           .fillRequiredInformation.tr,
                        //       fillColor: AppColors.white,
                        //
                        //       lable: AppStrings.patientName.tr,
                        //       iconData: Icons.lock,
                        //       lableStyle: labelStyle,
                        //
                        //       outlineInputBorder: outlineInputBorder
                        //   ),
                        //
                        // ],),
                        // UiHelper.verticalSpaceMedium,
                        //
                        //
                        // Row(children: [
                        //   ReactiveTextForm.reactiveTextFieldSleepQu(
                        //       formControlName: logic.contactKey,
                        //       validationMessage: AppStrings
                        //           .fillRequiredInformation.tr,
                        //       fillColor: AppColors.white,
                        //       //  isSSN: true,
                        //       isPhone: true,
                        //       isNumber: true,
                        //
                        //       length: 12,
                        //       lable: AppStrings.contactNo.tr,
                        //       iconData: Icons.lock,
                        //       lableStyle: labelStyle,
                        //
                        //       outlineInputBorder: outlineInputBorder
                        //   ),
                        //
                        // ],),
                        // UiHelper.verticalSpaceMedium,
                        //
                        // Row(children: [
                        //
                        //
                        //   Expanded(
                        //     child: QuestionRow(
                        //         questionnaire: logic.nationality, onTab: () {
                        //       logic.updateNationality();
                        //     }),
                        //   )
                        //
                        // ],),
                        // UiHelper.verticalSpaceLarge,

                        // Column(
                        //   mainAxisAlignment: MainAxisAlignment.start,
                        //   children: [
                        //     Row(children: [
                        //       Ui.titleGreenUnderLine(
                        //           AppStrings.questionnaire.tr, bottomPadding: 8),
                        //
                        //     ],),
                        //     // Row(
                        //     //   children: [
                        //     //     Expanded(child: Text(AppStrings.questionnaireHintMsg.tr,
                        //     //       style: AppStyles.subTitleStyle(),)),
                        //     //   ],
                        //     // )
                        //   ],),
                        // UiHelper.verticalSpaceSmall,

//                       Row(children: [
//                         ReactiveTextForm.reactiveTextFieldSleepQu(
//                             formControlName: logic.neckKey,
//                             validationMessage: AppStrings
//                                 .fillRequiredInformation.tr,
//                             isPhone: true,
//                             isNumber: true,
//                             widthTitle: 70,
// length: 2,
//                             lable: AppStrings.neckCir.tr,
//                             iconData: Icons.lock,
//                             lableStyle: labelStyle,
//                             fillColor: AppColors.white,
//                             outlineInputBorder: outlineInputBorder
//                         ),
//
//                       ],),
//                       UiHelper.verticalSpaceMedium,

                        Row(
                          children: [
                            ReactiveTextForm.reactiveTextFieldSleepQu(
                                formControlName: logic.heightKey,
                                validationMessage:
                                    AppStrings.fillRequiredInformation.tr,
                                isPhone: true,
                                isNumber: true,
                                noStartZero: true,
                                lable: AppStrings.height.tr,
                                iconData: Icons.lock,
                                lableStyle: labelStyle,
                                fillColor: AppColors.white,
                                outlineInputBorder: outlineInputBorder),
                            UiHelper.horizontalSpaceMedium,
                            ReactiveTextForm.reactiveTextFieldSleepQu(
                                formControlName: logic.weightKey,
                                validationMessage:
                                    AppStrings.fillRequiredInformation.tr,
                                fillColor: AppColors.white,
                                isNumber: true,
                                noStartZero: true,
                                length: 3,
                                isPhone: true,

                                // isSSN: true,
                                lable: AppStrings.weightKg.tr,
                                iconData: Icons.lock,
                                lableStyle: labelStyle,
                                outlineInputBorder: outlineInputBorder),
                          ],
                        ),
                      ],
                    ),
                  ),
                  UiHelper.verticalSpaceLarge,
                  ListView.builder(
                      physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: logic.questions.length,
                      itemBuilder: (bc, index) => QuestionRow(
                            questionnaire: logic.questions[index],
                            logic: logic,
                            onTab: () {
                              logic.updateQuestion(logic.questions[index]);
                            },
                          ))
                ],
              );
            }),
          ),
        ),
        Ui.primaryButton(
            title: AppStrings.send,
            marginV: 20,
            onTab: () {
              logic.send();
            })
      ],
    ));
  }
}
