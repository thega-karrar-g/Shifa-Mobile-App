import 'dart:io';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../base_controller/base_controller.dart';
import '../../core/language_and_localization/app_strings.dart';
import '../../data/api/config_api.dart';
import '../../data/models/home_service.dart';
import '../../data/models/nurse_service.dart';
import '../../data/models/slides_model.dart';
import '../../global_widgets/project_widget/marquee/speed.dart';
import '../../global_widgets/shared/different_dialogs.dart';
import '../../routes/app_route_names.dart';
import '../../utils/constants/api_keys.dart';
import '../../utils/constants/app_images.dart';
import '../../utils/constants/booking_vars.dart';
import '../booking_home_modules/instant_consultation_module/instant_consultation_home/instant_consultation_home_view.dart';
import '../booking_home_modules/service_details/service_details_logic.dart';
import '../doctor_module/doctors/doctors_controller.dart';

class HomeScreenController extends BaseController with WidgetsBindingObserver {
  List<Slide> slides = <Slide>[];
  static int storeVersion = 0;
  static bool isAppInForeground = false;

  final ConfigApi _configApi = ConfigApi();
  String appGoogleId = 'com.globcare.app';

  GetStorage boxVersion = GetStorage();

  final ScrollController scrollController = ScrollController();
  final Speed speed = Speed.slow;

  List<String> assetsSlides = [
    AppImages.bg1,
    AppImages.bg2,
    AppImages.bg3,
  ];

  RxInt index = 0.obs;

  updateIndex(int current) {
    index.value = current;
    update();
  }

  navToInstantCon() {
    // soonMessage();

    Get.toNamed(
      InstantConsultationHomePage.routeName,
    );
    //
  }

//   void getAvailability() async {
//
//     final updateAvailability = await getUpdateAvailability();
//
//
//     final bool  available= updateAvailability.fold(
//       available: () =>true,
//
//       notAvailable: () => false,
//       unknown: () =>false
//     );
//
// if (available) {
//   DifferentDialog.showUpdateAppDialog();
// }
// }

  Future checkVersion() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    int currentVersion = int.parse(packageInfo.buildNumber);

    var config = await _configApi.getAppVersion();

    if (config[ApiKeys.responseSuccess] != 0) {
      String platform = Platform.isAndroid ? 'Android' : 'IOS';
      if (int.tryParse(config['data'][platform]) != null) {
        storeVersion = int.parse(config['data'][platform]);
        boxVersion.write('version', storeVersion);
      }
    } else {
      storeVersion = boxVersion.read('version') ?? 0;
    }

    if (storeVersion > currentVersion) {
      DifferentDialog.showUpdateAppDialog();
    }



  }

//
// @override
//   void onInit() async{
//     // TODO: implement onInit
//     super.onInit();
//     checkVersion();
// //getInfo();
//
//   }
//

  void navToDoctors() {
    BookingVars.serviceName = AppStrings.telemedicine.tr;
    BookingVars.service = NurseService(
        name: AppStrings.telemedicine, nameAr: 'استشارة طبية فيديو');
    BookingVars.appointmentType = '';
    DoctorsController.doctorType = 'TD';
    BookingVars.serviceCode = '';

    // Get.to(LocationTestPage(),arguments: AppRouteNames.doctorBook);
    Get.toNamed(AppRouteNames.doctors, arguments: AppRouteNames.doctorBook);
  }



  navToServices(HomeService homeService)async{


    if (homeService.next.isNotEmpty) {
      if (homeService.code == 'Tel') {
        BookingVars.serviceName = AppStrings.telemedicine.tr;
        BookingVars.service = NurseService(
            name: AppStrings.telemedicine, nameAr: 'استشارة طبية فيديو');
        BookingVars.appointmentType = '';
        DoctorsController.doctorType = 'TD';
        BookingVars.serviceCode = '';
        Get.toNamed(homeService.next, arguments: homeService);
      } else {



        if(homeService.route==AppRouteNames.map){
          print('***************************   map');

          var p=await Geolocator.checkPermission();

          if(p ==LocationPermission.whileInUse||p==LocationPermission.always){
            print('***************************   checked ok');

            ServiceDetailsLogic.serviceCode = homeService.code;
            ServiceDetailsLogic.icon = homeService.icon;
            Get.toNamed(homeService.route, arguments: homeService);

          }
          else{

            print('***************************   checked no');

            var request= await Geolocator.requestPermission();

            if(request ==LocationPermission.whileInUse||request==LocationPermission.always){

              print('***************************   request ok');

              ServiceDetailsLogic.serviceCode = homeService.code;
              ServiceDetailsLogic.icon = homeService.icon;
              Get.toNamed(homeService.route, arguments: homeService);

            }
            else{
              buildFailedSnackBar(msg: AppStrings.selectPermissionLocationMsg.tr);

            await  Geolocator.openAppSettings();

            }

          }


        }else{



          print('***************************  not map');
          ServiceDetailsLogic.serviceCode = homeService.code;
          ServiceDetailsLogic.icon = homeService.icon;
          Get.toNamed(homeService.route, arguments: homeService);
        }

      }
    } else {
      soonMessage();
    }

  }
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      Future.doWhile(_scroll);
    });
    checkVersion();
  }

  Future<bool> _scroll() async {
    await Future.delayed(speed.pauseDuration);
    if (scrollController.hasClients) {
      scrollController.animateTo(scrollController.position.maxScrollExtent,
          duration: speed.animationDuration, curve: Curves.easeOut);
    }
    await Future.delayed(speed.pauseDuration);
    if (scrollController.hasClients) {
      scrollController.animateTo(scrollController.position.minScrollExtent,
          duration: speed.backDuration, curve: Curves.easeOut);
    }
    return true;
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
    WidgetsBinding.instance.removeObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    switch (state) {
      case AppLifecycleState.paused:
        {
          isAppInForeground = true;
        }
        // await player.play();
        break;
      case AppLifecycleState.inactive:
        {
          isAppInForeground = false;
        }
        //await player.stop();
        break;
      case AppLifecycleState.resumed:
        {
          isAppInForeground = false;
        }
        //  await player.stop();
        break;
      case AppLifecycleState.detached:
        {
          isAppInForeground = false;
        }
        // await player.stop();
        // TODO: Handle this case.
        break;
    }
  }
}

///.. can be separated into service class
