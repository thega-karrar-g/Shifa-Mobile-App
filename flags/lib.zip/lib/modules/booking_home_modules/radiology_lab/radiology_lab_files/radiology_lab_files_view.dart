import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/models/m_file.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/widgets/file_item.dart';
import 'package:sehati_app/modules/booking_home_modules/radiology_lab/radiology_lab_files/widgets/file_item.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_list.dart';
import 'package:sehati_app/shared_in_ui/shared/loading.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/no_data.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/download_controller.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

import 'radiology_lab_files_logic.dart';

class RadiologyLabFilesPage extends StatelessWidget {
  final logic = Get.put(RadiologyLabFilesLogic());
  final download = Get.put(DownloadController());


  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: GetBuilder<RadiologyLabFilesLogic>(builder: (logic) {
      return Column(
        children: [
          myAppBar2(title: logic.title,),


          UiHelper.verticalSpaceLarge,

          Expanded(
              child: (logic.granted)
                  ?
            logic.files.isNotEmpty?  DynamicListView(
                  //key: logic.key,
                  data: logic.files,
                  itemBuilder: (item)=>
                   LabRadiologyFileItem(myFile: item as MyFile,dir: logic.dir,logic: logic,)
              ):NoDataFound()
                  : Center(child: Container())
          ),


        ],
      );
    }));

  }
}
