import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/booking_home_modules/book_doctor_period/week_item_period.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'book_doctor_period_logic.dart';

class BookDoctorPeriodPage extends GetView<BookDoctorPeriodLogic> {
  const BookDoctorPeriodPage({Key? key}) : super(key: key);

 // final logic = Get.find<BookDoctorLogic>();


  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: SingleChildScrollView(
      child: Column(children: [

        myAppBar2(title: AppStrings.bookingDoctor),
        UiHelper.verticalSpaceMassive,




        GetBuilder<BookDoctorPeriodLogic>(builder: (controller) {
          return Column(
            children: [



              UiHelper.verticalSpaceLarge,

              Container(
                color: AppColors.white,

                child: Column(children: [
                  UiHelper.verticalSpaceMedium,

                  Row(children: [
                    Text(DateFormat('MMMM').format(controller.selectedDay),style: AppStyles.primaryStyle(bold: true,size: 18),),

                    UiHelper.horizontalSpaceSmall,
                    Text(DateFormat('yyyy').format(controller.selectedDay),style: AppStyles.subTitleStyle(bold: true,size: 15),),
                  ],),

                  UiHelper.verticalSpaceMedium,

                  SizedBox(
                    height: 100,
                    child: ListView.builder(
                      itemCount: controller.weekDays.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (bc,index)=>WeekItemPeriod(weekName: DateFormat('EE').format(controller.weekDays[index],)
                        ,
                        weekNo:'${controller.weekDays[index].day}' ,

                        onTab: (){
                          controller.changeDay(controller.weekDays[index]);
                        },
                        selected:controller.weekDays[index]==controller.selectedDay ,
                      ),

                    ),
                  ),
                  UiHelper.verticalSpaceMedium,

                  SizedBox(
                    height: 30,
                    child:   ListView.builder( scrollDirection: Axis.horizontal,itemCount:
                    controller.periods.length, itemBuilder: (bc,index)=>
                        GestureDetector(
                          onTap: (){

                            controller.selectPeriod(p:controller.periods[index]);
                          },
                          child: Container(
                            margin: EdgeInsets.symmetric(horizontal: 10),
                            padding: EdgeInsets.symmetric(horizontal: 15,vertical: 5),

                            decoration: BoxDecoration(

                                borderRadius: BorderRadius.circular(10),
                                color: controller.periods[index]==controller.selectedPeriod?AppColors.primaryColor:AppColors.white,
                                border: Border.all(color: AppColors.primaryColor)

                            ),

                            child: Text(controller.periods[index].capitalizeFirst.toString(),style:
                            controller.periods[index]==controller.selectedPeriod?  AppStyles.whiteStyle(bold: true) :     AppStyles.subTitleStyle(bold: true),

                            ),

                          ),
                        )),
                  ),



                ],),

              ),




            ],
          );
        })
        ,              UiHelper.verticalSpaceMassive,

        Ui.primaryButton(title: AppStrings.bookDoctor,radius: 20,marginH: 0,onTab: (){

          controller.navToPatientData();
        },color: AppColors.primaryColorGreen)


      ],),
    ));
  }



}
