import 'dart:io';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import '../../../core/language_and_localization/app_strings.dart';
import '../../../core/theme_helper/app_colors.dart';
import '../../../core/theme_helper/app_styles.dart';
import '../../../global_widgets/project_widget/price_item.dart';
import '../../../global_widgets/shared/different_dialogs.dart';
import '../../../global_widgets/shared/my_appbar.dart';
import '../../../global_widgets/shared/ui_helpers.dart';
import '../../../global_widgets/ui.dart';
import '../../../routes/app_route_names.dart';
import '../../../utils/constants/app_images.dart';
import '../../../utils/constants/booking_vars.dart';
import '../../auth/widgets/reactive_login_form.dart';
import '../../auth/widgets/reactive_register_form.dart';
import '../../qr_scanner/qr_scanner_logic.dart';
import 'book_invoice_logic.dart';

class BookInvoicePage extends StatelessWidget {
  final BookInvoiceLogic logic = Get.put(BookInvoiceLogic());

  BookInvoicePage({Key? key}) : super(key: key);
  final FocusNode _focusNode =
      FocusNode(); //1 - declare and initialize variable

  OutlineInputBorder outlineInputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(5.h)),
    borderSide: BorderSide(color: AppColors.registerFiled),
  );
  final double paddingHeight = 25.0.h;
  final labelStyle = TextStyle(
      color: AppColors.subTitleColor,
      fontWeight: FontWeight.bold,
      fontSize: 13.sp);

  @override
  Widget build(BuildContext context) {
    final ar = Get.locale.toString() == 'ar';


    return Ui.myScaffold(
        child: Column(
      children: [
        myAppBar2(title: AppStrings.bookingDetails),
        Expanded(
          child: GetBuilder<BookInvoiceLogic>(builder: (logic) {
            logic.vat = 0.0;


            if (logic.currentUser != null) {
              if (logic.currentUser!.nationality != null) {
                if (!logic.currentUser!.nationality!.contains('KSA')) {
                  logic.vat = BookingVars.price * .15;
                  //  BookingVars.price+= vat;
                }
              }
            }

            return SingleChildScrollView(
              padding: EdgeInsets.zero,
              child: Wrap(
                children: [
                  Column(
                    children: [
                      if (logic.currentUser == null)
                        Column(
                          children: [
                            Ui.primaryButton(
                                title: AppStrings.logIn,
                                onTab: () {
                                  BookingVars.fromPatientData = true;

                                  Get.bottomSheet(
                                          Padding(
                                            padding: UiHelper.safeAreaPadding,
                                            child: SizedBox(
                                                height: (Get.height * .7).h,
                                                child: ReactiveLoginForm(
                                                  title: AppStrings.logIn,
                                                )),
                                          ),
                                          backgroundColor: AppColors.white,
                                          isScrollControlled: true,
                                          enterBottomSheetDuration:
                                              Duration(milliseconds: 750),
                                          exitBottomSheetDuration:
                                              Duration(milliseconds: 750),
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.only(
                                                  topRight:
                                                      Radius.circular(10.h),
                                                  topLeft:
                                                      Radius.circular(10.h))))
                                      .then((value) {
                                    logic.update();
                                  });
                                }),
                            SizedBox(
                              height: 16.h,
                            ),
                            Row(
                              children: [
                                Expanded(
                                    child: Divider(
                                  color: AppColors.subTitleColor,
                                )),
                                UiHelper.horizontalSpaceMedium,
                                Text(
                                  AppStrings.or.tr,
                                  style: AppStyles.primaryStyle(bold: true),
                                ),
                                UiHelper.horizontalSpaceMedium,
                                Expanded(
                                    child: Divider(
                                  color: AppColors.subTitleColor,
                                )),
                              ],
                            ),
                            SizedBox(
                              height: 16.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    BookingVars.fromPatientData = true;

                                    Get.bottomSheet(
                                            Padding(
                                              padding: UiHelper.safeAreaPadding,
                                              child: SizedBox(
                                                  height: (Get.height * .8).h,
                                                  child:
                                                      ReactiveRegisterForm()),
                                            ),
                                            backgroundColor: AppColors.white,
                                            isScrollControlled: true,
                                            enterBottomSheetDuration:
                                                Duration(milliseconds: 750),
                                            exitBottomSheetDuration:
                                                Duration(milliseconds: 750),
                                            shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.only(
                                                    topRight:
                                                        Radius.circular(10.h),
                                                    topLeft:
                                                        Radius.circular(10.h))))
                                        .then((value) {
                                      logic.update();
                                    });

                                    //  Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPasswordScreen()));
                                  },
                                  child: Text(
                                    AppStrings.register.tr,
                                    style: AppStyles.primaryStyle(
                                        bold: true, size: 15),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),

                      Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            margin: EdgeInsets.only(
                                top: logic.currentUser != null ? 10.h : 10.h,
                                bottom: 25.h),
                            decoration: BoxDecoration(
                                color: AppColors.primaryColorOpacity,
                                borderRadius: BorderRadius.circular(10.h)),
                            child: Column(
                              children: [
//                         Padding(
//
//                             padding: EdgeInsets.symmetric(horizontal: 20.w),
//                             child: Column(children: [
//
// if(logic.currentUser!=null)
//                               UiHelper.verticalSpace(80)
// else
//   UiHelper.verticalSpace(16),
//
//
//                               if(BookingVars.doctor.name!.isNotEmpty)
//   UiHelper.verticalSpace(10),
//
//                               if(BookingVars.doctor.name!.isNotEmpty)
//                               invoiceRow(title: AppStrings.doctor,value: ar?BookingVars.doctor.nameAr!:BookingVars.doctor.name!,),
//                               invoiceRow(title:ar? '- '+BookingVars.service.nameAr:'- '+BookingVars.service.name,value: ' ${price.toStringAsFixed(0)}   '+AppStrings.currency.tr,),
//                               if(BookingVars.service2.id!=0)
//                               invoiceRow(title:ar? '- '+BookingVars.service2.nameAr:'- '+BookingVars.service2.name,value: ' ${ double.parse( BookingVars.service2.price).toStringAsFixed(0)}   '+AppStrings.currency.tr,),
//                               if(BookingVars.service3.id!=0)
//
//                                 invoiceRow(title:ar?'- '+ BookingVars.service3.nameAr:'- '+BookingVars.service3.name,value: ' ${ double.parse( BookingVars.service3.price).toStringAsFixed(0)}   '+AppStrings.currency.tr,),
//
//                               Row(children: [
//                                 Text( DateFormat(' d ').format((d)),style: AppStyles.primaryStyleGreen(bold: true,size: 12),),
//
//                                 Text(DateFormat(' MMM ',Get.locale.toString()).format((d)),style: AppStyles.primaryStyleGreen(bold: true,size: 12),),
//                                 Text( DateFormat(' yyyy ').format((d)),style: AppStyles.subTitleStyle(bold: true,size: 12),),
//
//                               if(BookingVars.appointmentDate.length>10)
//                                 Text( DateFormat(' HH:mm a',Get.locale.toString()).format((d)),style: AppStyles.subTitleStyle(bold: true,size: 12),)
//                                 else
//                                 Padding(
//                                   padding:  EdgeInsets.symmetric(horizontal: 20.w),
//                                   child: Text(BookingVars.period.tr,style: AppStyles.subTitleStyle(bold: true,size: 12),),
//                                 ),
//
//
//
//
//                                 UiHelper.horizontalSpaceMedium,SvgPicture.asset(AppImages.calendar,width: 25.w,height: 25.h,color: AppColors.primaryColorGreen,),
//
//                               ],),
//
// UiHelper.verticalSpaceMedium,
//                             //  invoiceRow(title: AppStrings.addedTax,value: '10 '+AppStrings.currency.tr),
//
//
//
//                                 invoiceRow(title: AppStrings.addedTax,value: '${logic.vat.toStringAsFixed(2)}    ${AppStrings.currency.tr}',)
//
//                               ,
//                            //   invoiceRow(title: AppStrings.personsCount,value: '1',marginV: 20),
//
//
//                             ],)),
//
//                         Container(
//                           padding: EdgeInsets.symmetric(horizontal: 20.w),
//                           height: 60.h,
//
//                           decoration: BoxDecoration(
//                               color: AppColors.primaryColor,
//                               borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10.w),
//
//                                   bottomRight: Radius.circular(10.w)
//                               )
//                           ),
//
//                           child: Column(
//                             mainAxisAlignment: MainAxisAlignment.center,
//                             children: [
//                               Row(children: [
//
//                                 Text(AppStrings.total.tr,style: AppStyles.whiteStyle(size: 15,bold: false),),
//
//                                 Spacer(),
//                                 Text(' ${(BookingVars.price+logic.vat).toStringAsFixed(2)}   '+AppStrings.currency.tr,style: AppStyles.whiteStyle(size: 15,bold: true),),
//
//                               ],),
//                               UiHelper.verticalSpaceSmall,
//                               // Row(children: [
//                               //
//                               //   Text(AppStrings.addedTax.tr,style: AppStyles.whiteStyle(size: 15,bold: false),),
//                               //
//                               //   Spacer(),
//                               //   if(logic.checkUserSignIn)
//                               //   Text( '${logic.currentUser!.ssn.startsWith('1')? '0':  ( BookingVars.price)*.15}  ${AppStrings.currency.tr}',style: AppStyles.whiteStyle(size: 15,bold: true),)
//                               //  else
//                               //   Text(  ' 0  ${AppStrings.currency.tr}',style: AppStyles.whiteStyle(size: 15,bold: true),)
//                               //
//                               // ],),
//                             ],
//                           ),
//
//                         ),

                                Row(
                                  children: [
                                    if (logic.currentUser != null)
                                      RotatedBox(
                                        quarterTurns: ar ? 2 : 0,
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(5.h),
                                          child: Container(
                                            alignment: Alignment.centerLeft,
                                            height: 100.h,
                                            width: (Get.width - 60.w),
                                            decoration: BoxDecoration(
                                              // color: AppColors.primaryColor,
                                              // borderRadius: BorderRadius.circular(10.h)
                                              image: DecorationImage(
                                                // colorFilter: ColorFilter.mode(AppColors.primaryColor.withOpacity(0.3), BlendMode.dstATop),

                                                image: AssetImage(
                                                  AppImages.invoiceBgPng,
                                                ),
                                                fit: BoxFit.fitWidth,
                                              ),
                                            ),
                                            child: Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 15.w,
                                                  vertical: 15.h),
                                              child: RotatedBox(
                                                  quarterTurns: ar ? 2 : 0,
                                                  child: Text(
                                                    BookingVars.patient!.name,
                                                    style: AppStyles.whiteStyle(
                                                        bold: true),
                                                  )),
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      vertical: 5.h, horizontal: 10.w),
                                  decoration: BoxDecoration(
                                      color: AppColors.primaryColorOpacity,
                                      borderRadius:
                                          BorderRadius.circular(10.h)),
                                  child: Column(
                                    children: [
                                      UiHelper.verticalSpaceSmall,

                                      Text(
                                        AppStrings.scanCodeDiscountMsg.tr,
                                        style: AppStyles.primaryStyle(
                                            bold: false, size: 13, height: 1.5),
                                      ),

                                      //    UiHelper.verticalSpaceMedium,

                                      Row(
                                        children: [
                                          Expanded(
                                            flex: 3,
                                            child: TextFormField(
                                              textInputAction:
                                                  TextInputAction.newline,
                                              keyboardType:
                                                  TextInputType.multiline,
                                              maxLines: null,
                                              focusNode: _focusNode,
                                              style: AppStyles.primaryStyle(
                                                  color:
                                                      AppColors.subTitleColor),
                                              controller: QrScannerLogic.qrCtrl,
                                              decoration: InputDecoration(
                                                //  labelText: lable.tr,
                                                labelStyle:
                                                    AppStyles.primaryStyle(
                                                        bold: true),
                                                filled: true,
                                                fillColor: AppColors
                                                    .primaryColorOpacity,
                                                contentPadding:
                                                    EdgeInsets.symmetric(
                                                        horizontal: 12.w,
                                                        vertical: 15.h),
                                                hintText:
                                                    AppStrings.enterCode.tr,
                                                errorStyle: TextStyle(
                                                    color: Colors.white
                                                        .withOpacity(0.7)),
                                                errorBorder: outlineInputBorder,
                                                hintStyle:
                                                    AppStyles.subTitleStyle(
                                                  bold: true,
                                                ),
                                                border: outlineInputBorder,
                                                focusedBorder:
                                                    outlineInputBorder,
                                                enabledBorder:
                                                    outlineInputBorder,
                                              ),
                                            ),
                                          ),
                                          UiHelper.horizontalSpaceSmall,
                                          Text(
                                            AppStrings.or.tr,
                                            style: AppStyles.primaryStyle(
                                                bold: false, size: 15),
                                          ),
                                          UiHelper.horizontalSpaceSmall,
                                          Expanded(
                                              flex: 2,
                                              child: Ui.primaryButton(
                                                  title: AppStrings.scan,
                                                  icon: FontAwesomeIcons.qrcode,
                                                  fontSize: 13,
                                                  iconSize: 18,
                                                  paddingV: 10,
                                                  marginV: 5,
                                                  radius: 5,
                                                  paddingH: 5,
                                                  onTab: () {
                                                    DifferentDialog
                                                        .showScanQRDialog();
                                                  })),
                                        ],
                                      ),

                                      Ui.primaryButton(
                                          title: AppStrings.verify,
                                          fontSize: 15,
                                          radius: 5,
                                          paddingV: 10,
                                          marginV: 10,
                                          color: AppColors.primaryColorGreen,
                                          onTab: () {}),

                                      UiHelper.verticalSpaceMedium,
                                    ],
                                  ),
                                ),

                                PriceItem(
                                  appUser: BookingVars.patient!,
                                  discount: 0,
                                  controller: logic,
                                  isInvoice: true,
                                  isPCR: BookingVars.isPcr,
                                )
                              ],
                            ),
                          ),
                          // Positioned(
                          //     top: -50.h,
                          //     child: Row(
                          //       children: [
                          //
                          //         if(logic.currentUser!=null)
                          //
                          //         RotatedBox(
                          //           quarterTurns: ar? 2:0,
                          //           child: ClipRRect(
                          //             borderRadius: BorderRadius.circular(10.h),
                          //             child: Container(
                          //               alignment: Alignment.centerLeft,
                          //               height: 100.h,width: (Get.width-60.w),
                          //               decoration: BoxDecoration(
                          //
                          //                 // color: AppColors.primaryColor,
                          //                 // borderRadius: BorderRadius.circular(10.h)
                          //                 image:  DecorationImage(
                          //
                          //                   // colorFilter: ColorFilter.mode(AppColors.primaryColor.withOpacity(0.3), BlendMode.dstATop),
                          //
                          //                   image:  AssetImage(AppImages.invoiceBgPng,), fit: BoxFit.fitWidth,),
                          //
                          //               ),
                          //
                          //               child: Padding(
                          //                 padding:  EdgeInsets.symmetric(horizontal: 15.w,vertical: 15.h),
                          //                 child: RotatedBox(
                          //                     quarterTurns: ar?2:0,
                          //
                          //                     child: Text(  logic.currentUser!.name,style: AppStyles.whiteStyle(bold: true),)),
                          //               ),
                          //
                          //             ),
                          //           ),
                          //         ),
                          //       ],
                          //     )
                          // ),
                        ],
                      ),

                      // Column(
                      //   children: [
                      //     Row(
                      //       children: [
                      //         Text(AppStrings.paymentType.tr,style: AppStyles.primaryStyle(bold: true,size: 16),),
                      //       ],
                      //     ),
                      //     Ui.greenLine(),
                      //
                      //
                      //     Row(
                      //       children: [
                      //
                      //         genderButton(title: AppStrings.cash,selected: logic.index==0,onTab: (){logic.changePaymentType(0);}),
                      //         UiHelper.horizontalSpaceMedium,
                      //         genderButton(title: AppStrings.insurance,selected: logic.index==1,onTab: (){logic.changePaymentType(1);}),
                      //         UiHelper.horizontalSpaceMassive,
                      //
                      //
                      //       ],
                      //     )
                      //   ],
                      // ),

                      //   UiHelper.verticalSpaceMedium,

                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.w),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text.rich(
                                TextSpan(
                                    text: '${AppStrings.byClick.tr} ',
                                    style: AppStyles.subTitleStyle(
                                      size: 13,
                                    ),
                                    children: [
                                      TextSpan(
                                          text:
                                              AppStrings.termsAndConditions.tr,
                                          style: AppStyles.primaryStyle(
                                              size: 13,
                                              bold: true,
                                              height: 1.5),
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {
                                              Get.toNamed(
                                                  AppRouteNames.termsOfService);
                                            })
                                    ]),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Row(
                      //   children: [
                      //     Expanded(
                      //     child: Ui.primaryButton(title: AppStrings.cardPay,fontSize: 15,color: logic.currentUser!=null?AppColors.primaryColor:AppColors.subTitleColor,onTab: (){
                      //
                      //       logic.navToPayment();
                      //
                      //     }),
                      //   ),
                      //
                      //
                      //
                      //
                      //   ],
                      // ),

                      //  if(logic.isIos)
                      Ui.primaryButton(
                          title: AppStrings.cardPay,
                          fontSize: 15,
                          capitalize: false,
                          marginV: Platform.isIOS ? 15 : 20,
                          color: AppColors.primaryColor,
                          onTab: () {
                            logic.navToPayment();
                          }),

                      if (logic.isIos)
                        Ui.primaryButton(
                            title: '',
                            fontSize: 15,
                            icon: FontAwesomeIcons.applePay,
                            marginV: 15,
                            color: AppColors.black,
                            onTab: () {
                              logic.navToPayment(applePay: true);
                            })
                    ],
                  )
                ],
              ),
            );
          }),
        ),
      ],
    ));
  }

  invoiceRow({String title = '', String value = '', double marginV = 15}) {
    return Padding(
      padding: EdgeInsets.only(left: 0, bottom: marginV.h),
      child: Row(
        children: [
          Expanded(
              child: Text(
            title.tr,
            style: AppStyles.primaryStyle(),
          )),
          Text(
            value.tr,
            textAlign: TextAlign.center,
            style: AppStyles.primaryStyle(bold: true, size: 13),
          ),
        ],
      ),
    );
  }

  genderButton({String title = '', bool selected = false, Function? onTab}) {
    return GestureDetector(
      onTap: () {
        if (onTab != null) {
          onTab();
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        decoration: BoxDecoration(
            color: selected
                ? AppColors.primaryColor
                : AppColors.primaryColorOpacity,
            borderRadius: BorderRadius.circular(10)),
        child: Text(
          title.tr,
          style: selected
              ? AppStyles.whiteStyle(bold: true, size: 15)
              : AppStyles.primaryStyle(size: 15, opacity: .8),
        ),
      ),
    );
  }
}
