import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/nurse_service.dart';
import 'package:sehati_app/modules/booking_home_modules/nurse_services/widgets/service_item.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_list.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/no_data.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_fonts.dart';

import '../../../shared_in_ui/shared/loading.dart';
import 'nurse_services_logic.dart';

class NurseServicesPage extends StatelessWidget {
  final NurseServicesLogic logic = Get.put(NurseServicesLogic());

final  GlobalKey globalKey=GlobalKey();
   NurseServicesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return GetBuilder<NurseServicesLogic>(builder: (logic) {
  return Ui.myScaffold(child: Column(
    children: [

      myAppBarServices(title: AppStrings.nurseService,code: 'N'),

      if(logic.busy)  Center(child: MyLoadingWidget()) else
        Expanded(



          child:

          logic.items.isNotEmpty?

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child:


                DynamicListView(
                    key: globalKey,
                    data: logic.items,
                    itemBuilder: (item)=>GestureDetector(

                        onTap: (){

                          logic.updateItems(item as NurseService );


                        },
                        child: ServiceItem(nurseService: item as NurseService,selected: logic.checkItem(item),))),
              )



              ,

              Ui.primaryButton(title: AppStrings.continueText,color: logic.selectedItems.isNotEmpty?AppColors.primaryColor:AppColors.extraGrey , onTab: () {
                logic.navToTimeSlots();
              })
            ],
          ):NoDataFound(),
        ),
    ],
  ));
});
  }


 TextStyle customTStyle({double size=14,isBold=false,Color color=AppColors.black}){

    return   TextStyle(color: color.withOpacity(.8),fontSize: size,fontWeight: isBold?FontWeight.bold:FontWeight.normal,fontFamily: AppFonts.mainFontFamily);


 }

}
