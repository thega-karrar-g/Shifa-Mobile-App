import 'package:get/get.dart';

import 'book_doctor_logic.dart';

class BookDoctorBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => BookDoctorLogic());
  }
}
