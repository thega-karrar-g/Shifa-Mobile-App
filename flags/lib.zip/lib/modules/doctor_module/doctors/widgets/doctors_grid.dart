import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/modules/doctor_module/doctors/widgets/tele_doctor.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_grid.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/grid_aspect_ratio.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

class DoctorsGrid extends StatelessWidget {
   DoctorsGrid({this.deptDoctors, Key? key}) : super(key: key);

  final List<DeptDoctor>? deptDoctors;

  @override
  Widget build(BuildContext context) {


    return

      ListView.builder(

          itemCount: deptDoctors!.length,
          itemBuilder: (bc,index){


        return           Container(
          margin: EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.primaryColor,width: 1)
          ),
          child: Wrap(
            children: [

              Container(
                padding: EdgeInsets.symmetric(vertical: 15,horizontal: 10),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: BorderRadius.only(topRight: Radius.circular(8),topLeft: Radius.circular(8))

                ),
                child: Row(children: [

                  Expanded(child: Text(Get.locale.toString()=='ar'?deptDoctors![index].nameAr:deptDoctors![index].name,style: AppStyles.whiteStyle(bold: true,size: 13),))

                ],),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: DynamicGridView(data: deptDoctors![index].doctors,
scrollable: false,
                    padding: UiHelper.doctorGridViewPadding,
                    count: Get.width~/300,
                    aspectRatio: GridAspectRatio.aspectRatio(count: Get.width~/300,height: 130),

                    mainSpacing: 0,
                    crossSpacing: 0,

                    itemBuilder: (item){
                      return TeleDoctorItemList(

                        doctor: item as Doctor,
                      );
                    }),
              ),
            ],
          ),
        );

      });

    //   GridView.builder(
    //   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
    //
    //     crossAxisCount: Get.width~/300,
    //     childAspectRatio: GridAspectRatio.aspectRatio(count: Get.width~/300,height: 145),
    //
    //       mainAxisSpacing: 15,
    //     crossAxisSpacing: 15,
    //
    //   ),
    //   itemCount: deptDoctors?.length,
    //   // physics: NeverScrollableScrollPhysics(),
    //   itemBuilder: (bc, index) => TeleDoctorItemList(
    //
    //     doctor: deptDoctors?[index],
    //   ),
    // );
  }
}
