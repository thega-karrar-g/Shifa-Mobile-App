import 'package:flutter/material.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/models/m_appointment.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_list.dart';
import 'package:sehati_app/shared_in_ui/shared/no_data.dart';

import 'appointment_item2.dart';
  class AppointmentList extends StatelessWidget {
    const AppointmentList({this.appointments,this.homeService,Key? key}) : super(key: key);

  final  List<Appointment>? appointments;


 final HomeService? homeService;


    @override
    Widget build(BuildContext context) {


      return

appointments!.isNotEmpty?
        DynamicListView(
          data: appointments!,
          itemBuilder: (item,) {
            return AppointmentItem2(appointment: item as Appointment,homeService: homeService,);
          },
        ):NoDataFound();

        // appointments!.isNotEmpty ? ListView.builder(
        //   itemCount: appointments?.length,
        //   itemBuilder: (bc,index)=>AppointmentItem2(appointment: appointments?[index],)):NoDataFound();
        //
        //

    }
  }
