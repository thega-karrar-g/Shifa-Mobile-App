import 'package:sehati_app/base_controller/base_controller.dart';

class LoginScreenLogic extends BaseController {

  // @override
  // void onInit() {
  //   super.onInit();
  // }

}