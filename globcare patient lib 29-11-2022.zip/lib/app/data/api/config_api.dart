import 'package:dio/dio.dart';


import '../../utils/constants/api_keys.dart';
import '../../utils/constants/app_urls.dart';
import 'base_api.dart';

class ConfigApi extends BaseApi {
  static final _configApi = ConfigApi._internal();

  factory ConfigApi() => _configApi;

  ConfigApi._internal();

  Future<dynamic> getAppVersion() async {
    try {
      var response = await api.dioGet(
        AppUrls.appVersion,
      );
      return response.data;
    } on DioError catch (_) {
      //
    }
    return {ApiKeys.responseSuccess: 0};
  }
}
