import 'dart:convert';
import 'package:get/get.dart';
import 'package:flutter/services.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/base_controller/helpers_methods.dart';
import 'package:sehati_app/models/slides_model.dart';
import 'package:sehati_app/utils/constants/app_images.dart';

class HomeScreenController extends BaseController {
  List<Slide> slides = <Slide>[];





List <String> assetsSlides=[
  AppImages.bg1,
  AppImages.bg2,
  AppImages.bg3,
];


RxInt index=0.obs;


updateIndex(int current){

  index.value=current;
  update();

}



  Future<void> listenForSlides() async {
    await getSlides().then((List<Slide> slidesRes) {
      // logger.d(slidesRes.length);
      slides.addAll(slidesRes);
      update();
    }).catchError((e) {
      logger.d(e);
    });
  }
}

///.. can be separated into service class
Future<List<Slide>> getSlides() async {
  String data = await rootBundle.loadString('assets/mock-data/slides.json');
  return List<Slide>.from(
      HelpersMethod.getData(json.decode(data) as Map<String, dynamic>)
              .mapUser((x) => Slide.fromJSON(x as Map<String, dynamic>))
          as Iterable<dynamic>);
}
