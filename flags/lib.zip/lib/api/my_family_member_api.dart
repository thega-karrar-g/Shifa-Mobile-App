import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:sehati_app/models/family_member_model.dart';
import 'package:sehati_app/utils/constants/app_urls.dart';
import 'base_api.dart';

class MyFamilyMemberApi extends BaseApi {
  static final _instance = MyFamilyMemberApi._internal();

  factory MyFamilyMemberApi() => _instance;

  MyFamilyMemberApi._internal();

  Future getMyFamilyMember() async {
    try {
      // logger.d(myFamilyMemberUrl);
      var response = await api.dioGet(AppUrls.familyMemberList);

      logger.d(response.data);

      if (response.statusCode == 200) {
        dynamic data = response.data;

        var decodedJsonData = jsonDecode(jsonEncode(data));

        return decodedJsonData['data'];
      }
    } on DioError catch (e) {
      // logger.d(e.response);
      return e.message;
    }
  }

  addNewFamilyMember(FamilyMember member) async {
    try {

      var response =
      await api.dioPost(AppUrls.addNewFamilyMember, body: member.toJson());

      logger.d(response.data);

      if (response.statusCode == 200) {
        dynamic data = response.data;

        var decodedJsonData = jsonDecode(jsonEncode(data));
        if (decodedJsonData['success'] ?? false) {
          return true;
        }
      }
    } on DioError catch (e) {
      logger.d(e.response);
      return e.message;
    }
  }
}
