

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/models/m_prescription.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
class MedicineItem extends StatelessWidget {
   MedicineItem({Key? key,required this.prescriptionLine,this.primary}) : super(key: key);
  bool  ar=Get.locale.toString()=='ar';

 final PrescriptionLine prescriptionLine;

final bool? primary;

  @override
  Widget build(BuildContext context) {
    return Container(
     // height: 200,
      margin: EdgeInsets.symmetric(vertical: 20),

      child: Column(
        children: [

item(prescriptionLine.name!, AppImages.pills,withArrow: true),
        SizedBox(height: 10,),

          Row(
            children: [
              Expanded(
                child: item(convertDate( prescriptionLine.endTreatment!), AppImages.period)
                ,
              ),

              SizedBox(width: 20,),
              Expanded(
                child: item(prescriptionLine.dose!, AppImages.frequency),

              ),






            ],
          ),
          SizedBox(height: 10,),

          item(prescriptionLine.indication!, AppImages.comment),

        ],
      ),
    );
  }


  item(String title,String icon,{Color color=AppColors.white,bool withArrow=false}){
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(

          padding: EdgeInsets.symmetric(horizontal: 15,vertical: 15),
          //  margin: EdgeInsets.symmetric(horizontal: 0,vertical: 10),

          decoration: BoxDecoration(
              color: primary! ?AppColors.primaryColorOpacity: AppColors.primaryGreenOpacityColor,

              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.cardBackgroundColor)
          ),
          child: Row(
            children: [

              SvgPicture.asset(icon,width: 23,height: 23,color: primary! ?  AppColors.primaryColor:AppColors.primaryColorGreen,),
              SizedBox(width: 10,),
              Expanded(child: Text(title,maxLines: 1,overflow: TextOverflow.ellipsis,style: primary! ? AppStyles.primaryStyle():AppStyles.primaryStyleGreen(),)),


            ],
          ),

        ),



        if(withArrow)

          Positioned.fill(
            right:ar?0: 30,
            left:ar?30: 0,
            top: -3,
            child: Align(
              alignment:ar?Alignment.topLeft: Alignment.topRight,
              child: Container(
                width: 100,
                height: 5,
                padding: EdgeInsets.symmetric(horizontal: 5,vertical: 10),
                decoration: BoxDecoration(
                    color: primary! ?AppColors.primaryColor:AppColors.primaryColorGreen,
                    borderRadius: BorderRadius.circular(10)

                ),

              ),
            ),
          ),




      ],
    );
  }


  String convertDate(DateTime date){
    String d='';

    try{
      d= DateFormat('d MMM, yyyy',Get.locale.toString()).format(date);



    }catch(_){}

    return d;
  }



  Widget cardItem(String txt){
    return Expanded(
      child: Container(
margin: EdgeInsets.symmetric(horizontal: 5),
        padding: EdgeInsets.all(5),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.only(bottomLeft: Radius.circular(10),bottomRight: Radius.circular(10)),
          boxShadow: [BoxShadow(color:AppColors.primaryColor .withOpacity(.3), blurRadius: 3)],
        ),

        child: Text(txt),


      ),
    );

  }


}
