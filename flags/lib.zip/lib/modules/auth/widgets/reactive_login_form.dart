import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/shared_in_ui/form_widgets/reactive_text_form.dart';

import '../../../language_and_localization/app_strings.dart';
import '../../../shared_in_ui/shared/ui_helpers.dart';
import '../../../shared_in_ui/ui.dart';
import '../../../utils/helpers/theme_helper/app_colors.dart';
import '../../../utils/helpers/theme_helper/app_styles.dart';
import '../auth_controller.dart';

class ReactiveLoginForm extends StatelessWidget {
   ReactiveLoginForm({Key? key,required this.title}) : super(key: key);

  final  double  paddingHeight=15.0;
  final String title;
  final String usernameKey='username';
  final String passwordKey='password';

  final requiredFields=' '

      '${AppStrings.idNo.tr} *\n'
      '${AppStrings.password.tr} *\n'
      ''
      '';

  FormGroup buildForm() => fb.group(<String, Object>{
    usernameKey: FormControl<String>(
      validators: [
        Validators.required,


      ],
    ),
    passwordKey: ['', Validators.required, Validators.minLength(6)],
    'rememberMe': false,
  });

  @override
  Widget build(BuildContext context) {
    return               GetBuilder<AuthController>(
        builder: (logic) {

          return ReactiveFormBuilder(
            form: buildForm,
            builder: (context, form, child) {

              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [

                    UiHelper.verticalSpace(Get.height*.05),


                    Row(children: [

                    Ui.titleGreenUnderLine(title,fontSize: 33,fontHeight: 1.5)
                    ],),

                    Row(
                      children: [
                        Text(AppStrings.loginMsg.tr,style: AppStyles.subTitleStyle(),),
                      ],
                    ),
                  //   UiHelper.verticalSpace(Get.height*.05),

UiHelper.verticalSpaceMedium,
                    ReactiveTextForm.reactiveRegisterTextField(
                        formControlName: usernameKey,
                        label: AppStrings.idNo,
                        isSSN: true,
                        length: 10


                    ),

                    const SizedBox(height: 15.0),
                    ReactiveTextForm.reactiveRegisterPasswordTextField(
                      formControlName: passwordKey,
                      logic: logic,
                      label: AppStrings.password,


                    ),

                    Ui.primaryButton(
                        title: AppStrings.logIn.tr.capitalizeFirst.toString(),

                        onTab: (){
                          if (form.valid) {
                            logic.login2(form.value);
                          } else {
                            // print(form.errors.toString());
                            //  form.markAllAsTouched();
                            logic.  buildFailedSnackBar(msg: AppStrings.fillAllRequiredFields.tr+'\n\n'+requiredFields+'\n'+AppStrings.passwordLengthHint.tr);
                          }
                        }
                    ),

                    SizedBox(
                      height: 10,
                    ),




                    //   SizedBox(height: 60),

                  ],
                ),
              );
            },
          );
        }
    )
    ;
  }
}
