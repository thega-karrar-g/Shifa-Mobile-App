
import 'package:sehati_app/models/model_helper.dart';

class MyFile{


  MyFile({
    this.id,
    this.name='',
    this.date='',
    this.url='',
    this.isExist=false

  });

  int? id;
  String name='',date='',url='';
  bool isExist=false;

  factory MyFile.fromJson(Map<String, dynamic> json) => MyFile(
      id: json["id"] as int,
      name:ModelHelper.checkString( json["name"]) ,
      date:ModelHelper.checkString( json["date"]) ,
      url:ModelHelper.checkString( json["url"]) ,
        );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "date": date,
    "url": url,

  };



}
