import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/booking_home_modules/book_doctor_period/week_item_period.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_list.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/no_appointment.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import '../../../shared_in_ui/shared/loading.dart';
import 'choose_date_period_logic.dart';

class ChooseDatePeriodPage extends GetView<ChooseDatePeriodLogic> {
   ChooseDatePeriodPage({Key? key}) : super(key: key);

   GlobalKey globalKey=GlobalKey();
 // final logic = Get.find<BookDoctorLogic>();


  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: SingleChildScrollView(
      child: Column(children: [

        myAppBar2(title: AppStrings.chooseDate),




        GetBuilder<ChooseDatePeriodLogic>(builder: (controller) {
          return


          controller.busy?MyLoadingWidget():  Column(
            children: [


              if(controller.route==AppRouteNames.physiotherapistServices)
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    Ui.titleGreenUnderLine(AppStrings.doctorGender),

                    Row(
                      children: [

                        genderButton(title: AppStrings.male,selected: controller.genderIndex==0,onTab: (){controller.updateGender(0);}),
                        UiHelper.horizontalSpaceMedium,
                        genderButton(title: AppStrings.female,selected: controller.genderIndex==1,onTab: (){controller.updateGender(1);}),
                        UiHelper.horizontalSpaceMassive,

                        Icon(FontAwesomeIcons.male,color: controller.genderIndex==0?AppColors.primaryColor:AppColors.subTitleColor,),
                        Icon(FontAwesomeIcons.female,color: controller.genderIndex==1?AppColors.primaryColor:AppColors.subTitleColor,),

                      ],
                    )

                  ],
                ),

              UiHelper.verticalSpaceLarge,
if(controller.periodItems.isNotEmpty)
              Container(
                color: AppColors.white,

                child: Column(children: [
                  UiHelper.verticalSpaceMedium,

                  Row(children: [
                    Text(DateFormat('MMMM',Get.locale.toString()).format(controller.selectedDay),style: AppStyles.primaryStyle(bold: true,size: 18),),

                    UiHelper.horizontalSpaceSmall,
                    Text(DateFormat('yyyy').format(controller.selectedDay),style: AppStyles.subTitleStyle(bold: true,size: 15),),
                  ],),

                  UiHelper.verticalSpaceMedium,

                  SizedBox(
                    height: 100,
                    child: ListView.builder(
                      itemCount: controller.periodItems.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (bc,index)=>WeekItemPeriod(weekName: DateFormat('E',Get.locale.toString()).format(controller.periodItems[index].date,)
                        ,
                        weekNo:'${controller.periodItems[index].date.day}' ,

                        onTab: (){

                          controller.changeDay(index);
                        },
                        selected:controller.periodItems[index].date==controller.selectedDay ,
                      ),

                    ),
                  ),
                  UiHelper.verticalSpaceMedium,

                  if(controller.dayPeriods.isNotEmpty)
                  SizedBox(
                    height: 45,
                    child:   DynamicListView(
                      key: globalKey,
                        axis: Axis.horizontal,
                    data:
                    controller.dayPeriods, itemBuilder:(item)=>  GestureDetector(
                      onTap: (){

                        controller.selectPeriod(p:item as String);
                      },
                      child: Container(
                        alignment: Alignment.topCenter,
                        margin: EdgeInsets.symmetric(horizontal: 10),
                        padding: EdgeInsets.symmetric(horizontal: 15,vertical: 2),


                        decoration: BoxDecoration(

                            borderRadius: BorderRadius.circular(10),
                            color: item==controller.selectedPeriod?AppColors.primaryColor:AppColors.white,
                            border: Border.all(color: AppColors.primaryColor)

                        ),

                        child: Text(item.toString().toLowerCase().tr.capitalizeFirst.toString()+'\n'+controller.periodTime(item.toString().toLowerCase()),
                          textAlign: TextAlign.center,
                          style:
                        item.toString()==controller.selectedPeriod?  AppStyles.whiteStyle(bold: true,height: 1.5,size: 11) :     AppStyles.subTitleStyle(bold: true,height: 1.5,size: 11),

                        ),

                      ),
                    )
                       ),
                  ),

                  if(controller.dayPeriods.isNotEmpty)

                  Ui.primaryButton(title: AppStrings.continueTo,marginH: 0,onTab: (){

                    controller.navToPatientData();
                  })

                ],),

              )

              else NoAppointmentTimes()

              ,






            ],
          );
        })
        ,


        UiHelper.verticalSpaceLarge,






      ],),
    ));
  }

  genderButton({String title='',bool selected=false,Function? onTab}){


    return  GestureDetector(

      onTap: (){
        if(onTab!=null){

          onTab();

        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15,horizontal: 20),
        decoration: BoxDecoration(
            color: selected?AppColors.primaryColor:AppColors.primaryColorOpacity,
            borderRadius: BorderRadius.circular(10)
        ),
        child: Text(title.tr,style: selected?AppStyles.whiteStyle(bold: true,size: 15):AppStyles.primaryStyle(size: 15,opacity: .8),),

      ),
    );

  }


}
