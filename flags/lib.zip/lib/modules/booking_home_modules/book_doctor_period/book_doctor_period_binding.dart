import 'package:get/get.dart';

import 'book_doctor_period_logic.dart';

class BookDoctorPeriodBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => BookDoctorPeriodLogic());
  }
}
