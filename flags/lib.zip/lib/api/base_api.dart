import 'package:get/get.dart';
import 'package:logger/logger.dart';
import 'package:sehati_app/models/user_model.dart';
import 'package:sehati_app/services/session_service.dart';

import 'api.dart';

class BaseApi {
  Api api = Api();
  var authService = Get.find<SessionService>();
  AppUser? get currentUser {
    return Get.find<SessionService>().currentUser;
  }
  final logger = Logger();
}
