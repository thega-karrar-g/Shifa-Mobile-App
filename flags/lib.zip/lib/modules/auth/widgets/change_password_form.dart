import 'package:flutter/material.dart';

import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/auth_controller.dart';
import 'package:sehati_app/shared_in_ui/form_widgets/reactive_text_form.dart';
import 'package:get/get.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

class ChangePasswordForm extends StatelessWidget {
  ChangePasswordForm({Key? key, this.controller}) : super(key: key);
  final AuthController? controller;

 static const currentPassword='password';
static  const newPassword='new_password';

  final  double  paddingHeight=25.0;
  final labelStyle=TextStyle(color: AppColors.subTitleColor,fontWeight: FontWeight.bold,fontSize: 13);
  final OutlineInputBorder outlineInputBorder =OutlineInputBorder(
    borderRadius: BorderRadius.all(
        Radius.circular(10)),
    borderSide: BorderSide(
        color:
        AppColors.subTitleColor)
    ,
  );
  FormGroup buildForm() => fb.group(<String, Object>{
        currentPassword: FormControl<String>(
          validators: [
            Validators.required,
            Validators.minLength(6),          ],
        ),
        newPassword: FormControl<String>(

        ),



      });

  final TextStyle style =
      Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.white));

  @override
  Widget build(BuildContext context) {
    return ReactiveFormBuilder(
      form: buildForm,
      builder: (context, form, child) {
        return Column(
          children: [






            ReactiveTextForm.reactiveTextFieldAuth(
               formControlName: currentPassword,
preventSpace: true,
               validationMessage: AppStrings.passwordHint.tr,
               isPassword: true,

               lable: AppStrings.currentPassword.tr,
             iconData: Icons.lock,
             lableStyle: labelStyle,
fillColor: AppColors.white,
           outlineInputBorder: outlineInputBorder
           ),
            ReactiveTextForm.reactiveTextFieldAuth(
                formControlName: newPassword,
                preventSpace: true,
                validationMessage: AppStrings.passwordHint.tr,
                isPassword: true,
                fillColor: AppColors.white,

                lable: AppStrings.newPassword.tr,
                iconData: Icons.lock,
                lableStyle: labelStyle,

                outlineInputBorder: outlineInputBorder
            ),


            SizedBox(
              height: 30,
            ),


           Row(children: [


             Expanded(child:  GestureDetector(onTap: (){
               Get.back();
             },

             child: Text(AppStrings.cancel.tr,style: AppStyles.subTitleStyle(bold: true,size: 20),),

             ),),
             Expanded(child:  Ui.primaryButton(title: AppStrings.save,radius: 10,marginH: 0,hasIcon: false,onTab: (){


               if(form.valid) {

                 Map<String,dynamic> data={'type':'1','username':controller!.currentUser!.phone};

                 data.addAll(form.value);

                 controller!.changePassword(data);



               //  Get.toNamed(AppRouteNames.completeRegister);
               }
               else{
                // controller!.buildFailedSnackBar(msg: AppStrings.fillAllField.tr);
                 controller!.buildFailedSnackBar(msg: form.errors.toString());

               }



             }),),

           ],)
,











            SizedBox(
              height: 30,
            ),
          ],
        );
      },
    );
  }
}
