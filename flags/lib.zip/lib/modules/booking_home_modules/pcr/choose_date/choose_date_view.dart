import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';

import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import '../../../../shared_in_ui/shared/dynamic_column.dart';
import '../../../../shared_in_ui/shared/dynamic_list.dart';
import '../../../../shared_in_ui/shared/loading.dart';
import '../../../../shared_in_ui/shared/no_data.dart';
import '../../book_doctor_period/week_item_period.dart';
import 'choose_date_logic.dart';

class ChooseDatePage extends GetView<ChooseDateLogic> {
 // final logic = Get.find<BookDoctorLogic>();
  bool ar=Get.locale.toString()=='ar';

  ChooseDatePage({Key? key}) : super(key: key);
GlobalKey globalKey=GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: SingleChildScrollView(
      child: Column(children: [

        myAppBar2(title: AppStrings.chooseDate),




        GetBuilder<ChooseDateLogic>(builder: (logic) {
          return           Column(
            children: [


              UiHelper.verticalSpaceMedium,

              SizedBox(

                child:  logic.busy?MyLoadingWidget():


                (logic.scheduleList.isNotEmpty)?

                DynamicColumn(children: [

                  Row(children: [
                    Text(DateFormat('MMMM',Get.locale.toString()).format(logic.selectedDay),style: AppStyles.primaryStyle(bold: true,size: 18),),

                    UiHelper.horizontalSpaceSmall,
                    Text(DateFormat('yyyy').format(logic.selectedDay),style: AppStyles.subTitleStyle(bold: true,size: 15),),
                  ],),

                  SizedBox(
                    height: 100,
                    child: ListView.builder(
                      itemCount: logic.scheduleList.length,
                      scrollDirection: Axis.horizontal,

                      itemBuilder: (bc, index) =>
                          SizedBox(
                            height: 200,
                            child: WeekItemPeriod(weekName: DateFormat('E',Get.locale.toString()).format(logic.scheduleList[index].date,),

                              weekNo: '${logic.scheduleList[index].date.day}',

                              onTab: () {
                                logic.changeDay(index);
                              },
                              selected: logic.scheduleList[index].date ==
                                  logic.selectedDay,
                            ),
                          ),

                    ),
                  ),


                  SizedBox(
                    height: 30,
                    child:   DynamicListView(

                       key: globalKey,
                        axis: Axis.horizontal,data:
                    logic.scheduleList[logic.currentIndex].times!, itemBuilder: (item){
                      var time=item as String;
                      return
                        GestureDetector(
                          onTap: (){

                            logic.changeSlot(time);
                          },
                          child: Container(
                            margin: EdgeInsets.symmetric(horizontal: 10),
                            padding: EdgeInsets.symmetric(horizontal: 15,vertical: 5),

                            decoration: BoxDecoration(

                                borderRadius: BorderRadius.circular(10),
                                color: logic.checkSlot(time,logic.scheduleList[logic.currentIndex].date)?AppColors.primaryColor:AppColors.white,

                                border: Border.all(color: AppColors.primaryColor)

                            ),

                            child: Text(time,style:
                            logic.checkSlot(time,logic.scheduleList[logic.currentIndex].date)?  AppStyles.whiteStyle(bold: true) :     AppStyles.subTitleStyle(bold: true),

                            ),

                          ),
                        );}

                    ),
                  ),


                  UiHelper.verticalSpaceSmall,

                  UiHelper.verticalSpaceMassive,

                  // Row(
                  //   children: [
                  //     IntrinsicWidth(
                  //       child: Column(
                  //         mainAxisAlignment: MainAxisAlignment.start,
                  //         crossAxisAlignment: CrossAxisAlignment.start,
                  //         children: [
                  //           Row(
                  //             mainAxisAlignment: MainAxisAlignment.start,
                  //             crossAxisAlignment: CrossAxisAlignment.start,
                  //             children: [
                  //             Text(AppStrings.certificateDetails.tr,style: AppStyles.primaryStyle(bold: true,size: 20),)
                  //
                  //           ],),
                  //           Row(children: [
                  //             Expanded(child: Container(
                  //               margin: EdgeInsets.only(top: 5,bottom: 5,),
                  //               height: 5,
                  //               decoration: BoxDecoration(color: AppColors.primaryColorGreen,
                  //                   borderRadius: BorderRadius.circular(5)
                  //               ),
                  //             ))
                  //
                  //           ],)
                  //
                  //         ],
                  //       ),
                  //     ),
                  //   ],
                  // ),
                  // Row(children: [
                  //   Expanded(child: Text(AppStrings.certificateDetailsHint.tr,style: AppStyles.subTitleStyle(bold: false,size: 16),))
                  //
                  // ],),
                  Ui.primaryButton(title: AppStrings.continueTo,radius: 10,marginH: 0,onTab: (){
logic.navToPatientData();

                  },color: AppColors.primaryColor)


                ],)
                    :

                Center(child: NoDataFound(),),),


            ],
          )
          ;
        })
        ,              UiHelper.verticalSpaceMassive,



      ],),
    ));
  }



}
