import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:persian_datepicker/persian_datepicker.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

// import '../../../utils/custom_date/persian_datepicker.dart';


class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  HomeState createState() {
    return  HomeState();
  }
}

class HomeState extends State<Home> {

  // our text controller
  final TextEditingController textEditingController = TextEditingController();

  late PersianDatePickerWidget persianDatePicker;

  @override
  void initState() {
var d=DateTime.now();
var min=DateTime(1922,1,1);
    /*Simple DatePicker*/
    persianDatePicker = PersianDatePicker(
      controller: textEditingController,
showGregorianDays: true,
currentDayBackgroundColor: AppColors.primaryColorOpacity,
selectedDayBackgroundColor: AppColors.primaryColor,
selectedDayTextStyle: AppStyles.whiteStyle(bold: true),
headerTodayTextStyle: AppStyles.whiteStyle(bold: true),
headerTodayIcon: Icon(FontAwesomeIcons.calendarDay,color: AppColors.white,),
weekCaptionsBackgroundColor: AppColors.primaryColor,
headerTodayBackgroundColor: AppColors.primaryColorGreen,
monthSelectionBackgroundColor: AppColors.primaryColorOpacity,
monthSelectionHighlightBackgroundColor: AppColors.primaryColorGreen,
monthSelectionTextStyle: AppStyles.primaryStyle(),
monthSelectionHighlightTextStyle: AppStyles.whiteStyle(),

      yearSelectionBackgroundColor: AppColors.primaryColorOpacity,
      yearSelectionHighlightBackgroundColor: AppColors.primaryColorGreen,
      yearSelectionTextStyle: AppStyles.primaryStyle(),
      yearSelectionHighlightTextStyle: AppStyles.whiteStyle(),



 maxDatetime: '${d.year}/${d.month}/${d.day}',
 finishDatetime: '${d.year}/${d.month}/${d.day}',
 gregorianDatetime: '${d.year}-${d.month}-${d.day}',
 minDatetime: '${min.year}/${min.month}/${min.day}',



// maxSpan: Duration(days: 1),
// minSpan: Duration(days: 0),
farsiDigits: false,
headerTodayCaption: AppStrings.today,
// datetime: DateFormat('yyyy/MM/dd').format(DateTime.now()),
// finishDatetime: DateFormat('yyyy/MM/dd').format(DateTime.now().add(Duration(days: 0))),
//         gregorianFinishDatetime: DateFormat('yyyy-MM-dd').format(DateTime.now().add(Duration(days: 0))),
// gregorianDatetime: DateFormat('yyyy-MM-dd').format(DateTime.now().add(Duration(days: 0))),
//       onChange: (String oldText, String newText) {  },


//      datetime: '1397/06/09',
    ).init()!;
    int shamsiDaysOfMonth =  DateTimeRange(
        start: d,
        end: DateTime(d.year, d.month + 1))
        .duration
        .inDays;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(''),),
      body: Builder(builder: (BuildContext context) {


        return TextField(
          enableInteractiveSelection: false, // *** this is important to prevent user interactive selection ***
          onTap: () {
            FocusScope.of(context).requestFocus( FocusNode()); // to prevent opening default keyboard
            showModalBottomSheet(
                context: context,
                builder: (BuildContext context) {
                  return persianDatePicker;
                });
          },
          controller: textEditingController,
        );



      }),
    );
  }
}