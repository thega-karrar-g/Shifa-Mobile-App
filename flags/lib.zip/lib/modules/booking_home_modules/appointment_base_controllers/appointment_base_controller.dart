
import 'dart:convert';
import 'dart:core';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/repositories/appointment_repository.dart';
import 'package:sehati_app/shared_in_ui/shared/different_dialogs.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:urwaypayment/urwaypayment.dart';



class AppointmentBaseController  extends BaseController{


  final AppointmentRepository _appointmentRepository=AppointmentRepository();





  // To show Selected Item in Text.
  String holder = '' ;
  String actionHolder = '1' ;
  String cardOperHolder = '' ;

//  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();

  TextEditingController queryPhone =TextEditingController() ;
  TextEditingController queryOrderId=TextEditingController() ;
  TextEditingController queryAmt=TextEditingController() ;
  TextEditingController queryAction=TextEditingController() ;
  TextEditingController queryTokenOperation=TextEditingController() ;
  TextEditingController querytokentype=TextEditingController() ;
  TextEditingController queryudf1=TextEditingController(text: 'https://glob-care.com/') ;
  TextEditingController queryudf2=TextEditingController(text: 'https://glob-care.com/') ;
  TextEditingController queryudf3=TextEditingController(text: 'https://glob-care.com/') ;
  TextEditingController queryudf4=TextEditingController(text: 'https://glob-care.com/') ;
  TextEditingController queryudf5=TextEditingController(text: 'https://glob-care.com/') ;
  TextEditingController querycompanyName=TextEditingController() ;
  TextEditingController queryshipping=TextEditingController() ;

  TextEditingController queryMerchantIdentifier=TextEditingController() ;


  makeBookingWithFileDio()async{

    //var data={'patient_id':int.parse(authService.currentUser!.id??'0'),'doctor_id':doctorId,'appointment_date':appointmentDate};
    // var data=[
    //   MapEntry('patient_id',authService.currentUser!.id) ,
    //   MapEntry('doctor_id','${BaseController.doctorId}') ,
    //   MapEntry('appointment_date',BaseController.appointmentDate) ,
    //   MapEntry('service',BaseController.service) ,
    //   MapEntry('location',BaseController.location) ,
    //   MapEntry('payment_type','insurance') ,
    //
    // ];
    //var data={'patient_id':int.parse(authService.currentUser!.id??'0'),'doctor_id':doctorId,'appointment_date':appointmentDate};
    Map<String, String> data={'patient_id':authService.currentUser!.id,
      'doctor_id':'${PatientDataLogic.doctorId !=0?PatientDataLogic.doctorId:28}',
      'appointment_date':PatientDataLogic.appointmentDate,
      // 'service_id':'10',
      'service_id':'${PatientDataLogic.service.id}',
      if(PatientDataLogic.service2.id!=0)
        'service_id_2':'${PatientDataLogic.service2.id}',
      if(PatientDataLogic.service3.id!=0)

        'service_id_3':'${PatientDataLogic.service3.id}',
      'type':PatientDataLogic.serviceType,

      'location':PatientDataLogic.location,
      'consultancy_type':PatientDataLogic.consultancyType,
      'consultancy_price':'${PatientDataLogic.price}',
      'period':PatientDataLogic.period.toLowerCase(),
      'hour':PatientDataLogic.hour.toLowerCase().split(':')[0].trim(),
      'gender':PatientDataLogic.doctorGender,
      'patient_followers':PatientDataLogic.patientFollowers,
      'patient_comment':PatientDataLogic.patientComment.text.toString(),
      //'payment_type':PatientDataLogic.paymentType
      'payment_type':'pay',


    };
print(data);

    try {
      setBusy(true);
      DifferentDialog.showProgressDialog();
      var result=await  _appointmentRepository.makeBookingWithFileDio(data);
      // buildSuccessSnackBar(msg: result);
      Get.back();

      var jsonData = (result);


      print('************************************************   $jsonData ');
      var msg='';
      var success = jsonData['success'] as int;


      if (success == 1) {
        msg = '${jsonData!['data']['message']}';
        var  id = '${jsonData!['data']['id']}';

        PatientDataLogic.audioFile=null;
        PatientDataLogic.attachFile=null;
        PatientDataLogic.cameraFile=null;
        PatientDataLogic.serviceCode='';
        PatientDataLogic.uploadFiles.clear();
        PatientDataLogic.service2.id=0;
        PatientDataLogic.service3.id=0;
        PatientDataLogic.patientComment.clear();
     //  DifferentDialog.showPaymentLoading(msg:PatientDataLogic.paymentType=='insurance'? AppStrings.insuranceSuccess:AppStrings.paymentSuccess);

        if (Platform.isIOS) {

          performtrxn(transType: 'applepay',orderId:id );

        }
        else {
          performtrxn(orderId: id);
        }


      } else {


        msg = '${jsonData['message']}';
        buildFailedSnackBar(msg: msg);

      }


      setBusy(false);
    }
    catch(_){
      setBusy(false);
    }

  }
  requestCareGiver(Map <String,String> data)async{




    // try {
    DifferentDialog.showProgressDialog();
    var result=await  _appointmentRepository.makeBookingWithFileDio(data);
    // buildSuccessSnackBar(msg: result);
    Get.back();

    var jsonData = (result);

    var msg='';
    var success = jsonData['success'] as int;


    if (success == 1) {
      msg = '${jsonData!['data']['message']}';

      PatientDataLogic.audioFile=null;
      PatientDataLogic.serviceCode='';
      PatientDataLogic.uploadFiles.clear();
      PatientDataLogic.service2.id=0;
      PatientDataLogic.service3.id=0;
      //   DifferentDialog.showPaymentSuccessDialog2(msg:PatientDataLogic.paymentType=='insurance'? AppStrings.insuranceSuccess:AppStrings.paymentSuccess);
      DifferentDialog.showRequestServiceSuccessDialog(msg: AppStrings.appointmentSendSuccess);


    } else {


      msg = '${jsonData['message']}';
      buildFailedSnackBar(msg: msg);

    }


    // }
    // catch(_){
    // }

  }



  cancelAppointment(String appointmentId,{String route=AppRouteNames.home})async{

    print('cancel  *********************************');
    print('type  *********************************  ${PatientDataLogic.paymentAppointmentType.toString().split('.')[1]}');

    var  data={'appointment_type':PatientDataLogic.paymentAppointmentType.toString().split('.')[1],'appointment_id':appointmentId,'payment_reference':'0'};

    //  DifferentDialog.showProgressDialog();
 var res=   await _appointmentRepository.setPaymentStatus(data);

print('*******************************  data   $res');


    if(route==AppRouteNames.home) {
      Get.offAllNamed(AppRouteNames.home);
    }
    else{
      Get.toNamed(route);

    }

  }





  Future<void> performtrxn( {String transType ='hosted',String orderId='0'}) async {



    queryPhone.text='110000000';
    queryOrderId.text=orderId;
    queryAmt.text='1.00';
    queryAction.text='1';
    queryTokenOperation.text='A';
    querytokentype.text='1';//cust present or not

    querycompanyName.text='globcare';
    queryshipping.text='0.00';
    //queryMerchantIdentifier.text="merchant.urway.technologies.applepay";
    queryMerchantIdentifier.text="060325f6746b4003ab20ef32f06d9fa6ee0b06d92029ddd856dd375c06c2de3a";

    var lastResult ="";
    var act=actionHolder;
    var carOper=cardOperHolder;
    var tokenTy=querytokentype.text;
    print('$act - $carOper - $tokenTy');
    if(transType=="hosted") {

      // on Apple Click call other method  check with if else
      lastResult = await Payment.makepaymentService(context: Get.context!,
          country: 'SA',
          action: act,
          currency: 'SAR',
          //   amt: '100.0',
          amt: PatientDataLogic.price.toString(),
          customerEmail: 'info@glob-care.com',
          trackid: queryOrderId.text,
          udf1: queryudf1.text,
          // udf2: 'https://glob-care.com/',
          udf2: 'https://glob-care.com/test.html',
          udf3: Get.locale.toString(),
          udf4: '',
          udf5: '',
          cardToken: '',
          address: '',
          city: '',
          state: '',
          tokenizationType: tokenTy,
          zipCode: '',
          tokenOperation: carOper,onBack: (){

            DifferentDialog.showBackPaymentDialog(onYes: (){
              cancelAppointment(orderId);
            });

          },title: AppStrings.paymentDetails.tr,ar: Get.locale.toString()=='ar',appBar: Container());


      print('Result in Main is $lastResult');
    }
    else if(transType =="applepay")
    {
      print("In apple pay");
      lastResult = await Payment.makeapplepaypaymentService
        (context: Get.context!,
        country: 'SA',
        action: act,
        currency: 'SAR',
        //   amt: '100.0',
        amt: PatientDataLogic.price.toString(),
        customerEmail: 'info@glob-care.com',
        trackid: queryOrderId.text,
        udf1: queryudf1.text,
        // udf2: 'https://glob-care.com/',
        udf2: 'https://glob-care.com/test.html',
        udf3: Get.locale.toString(),
        udf4: '',
        udf5: '',
        tokenizationType: tokenTy,
        merchantIdentifier:queryMerchantIdentifier.text,
        shippingCharge: queryshipping.text,
        companyName:querycompanyName.text,

      );
      print('Result on Apple Pay in Main is $lastResult');
    }

// if (xyz != null )
//    {h
//      lastResult=xyz;
    Map<String,dynamic> decodedJSON;
    var decodeSucceeded = false;
    try {
      decodedJSON = json.decode(lastResult) as Map<String, dynamic>;
      decodeSucceeded = true;
    } on FormatException catch (e) {
      print('${e.message.toString()} The provided string is not valid JSON');
    }
    if(decodeSucceeded)
    {
      var responseData = json.decode(lastResult);
      print('RESP $responseData');
      var trnsId = responseData["TranId"] as String;
      var respCode = responseData["ResponseCode"] as String ;
      // var result = responseData["result"] as String;
      // var amount = responseData["amount"] as String;
      // var cardToken = responseData["cardToken"] as String;
      // var cardBrand = responseData["cardBrand"] as String;
      // var maskedPanNo = responseData["maskedPanNo"] as String;

//     String trnsid=responseData.TranId;

      var data={'transId':trnsId,'respCode':respCode,'orderId':orderId};
      Get.toNamed(AppRouteNames.receiptPage,arguments: data);

      // Navigator.of(context).push(MaterialPageRoute(builder: (context) => ReceiptPage(trnsid,result,amount,cardToken,respCode)));
    }
    else
    {
      if(lastResult.isNotEmpty) {
        print('Show');
      }
      else
      {
        print('Show Blank Data');
      }
    }
    print('Payment $lastResult');
  }



  String getRandString(int len) {
    var random = Random.secure();
    var values =  random.nextInt(10000000);
    // return base64UrlEncode(values);
    return   values.toString();
  }



}