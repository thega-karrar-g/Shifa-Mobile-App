import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/payment_method.dart';
import 'package:sehati_app/modules/booking_home_modules/payment_methods/widgets/method_item.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import 'payment_methods_logic.dart';

class PaymentMethodsPage extends StatelessWidget {
  final logic = Get.find<PaymentMethodsLogic>();

   PaymentMethodsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(child: SingleChildScrollView(


      child: Wrap(children: [


      myAppBar2(title: AppStrings.paymentOptions),


      Text(AppStrings.choosePayment.tr,style: AppStyles.subTitleStyle(),),

      Container(height: 20,),


      ListView.builder(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: PaymentMethod.methods.length,
        itemBuilder: (bc,index)=>MethodItem(paymentMethod: PaymentMethod.methods[index],),

      ),



      Container(height: 40,),

      DottedBorder(
        borderType: BorderType.RRect,
        strokeCap: StrokeCap.butt,
        radius: Radius.circular(5),
        dashPattern: const [6, 3, 6, 3],

        color: AppColors.primaryColor,
        padding: EdgeInsets.all(10),
        child: ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(12)),
          child: Row(children: [
            Expanded(child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [

                CircleAvatar(backgroundColor: AppColors.primaryColorGreen,

                  child: Icon(Icons.add,color: AppColors.white,),
                ),
                UiHelper.horizontalSpaceSmall,
                Text(AppStrings.addCard.tr,style: AppStyles.primaryStyle(),)

              ],))
          ],),
        ),
      )

,
        Container(height: 40,),



      ],),));
  }
}
