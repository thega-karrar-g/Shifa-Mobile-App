import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'logic.dart';

class LoginScreenPage extends StatelessWidget {
  final logic = Get.put(LoginScreenLogic());

  LoginScreenPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
