import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';

typedef ItemBuilder<T> = Widget Function(T item);

class DynamicGridView<T> extends StatefulWidget {
  final Axis axis;
  final List<T> data;
  final int count;
  final bool scrollable;
  final EdgeInsets padding ;
  final double aspectRatio,crossSpacing,mainSpacing;
  final ItemBuilder<T> itemBuilder;

   DynamicGridView({Key? key,
    required this.data,
    this.axis = Axis.vertical,
    required this.itemBuilder,
    this.scrollable=true,
    this.padding=UiHelper.gridViewPadding,
    this.count = 0,
    this.aspectRatio=1.0,this.crossSpacing=15.0,this.mainSpacing=15.0,
  }) : super(key: key)  ;

  @override
  _DynamicGridViewState createState() => _DynamicGridViewState();
}

class _DynamicGridViewState<T> extends State<DynamicGridView<T>> {
  final delay=0;
  final duration=500;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      key: UniqueKey(),
      physics: widget.scrollable?AlwaysScrollableScrollPhysics():NeverScrollableScrollPhysics(),

      shrinkWrap: !widget.scrollable,
      padding: widget.padding,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: widget.count,
        childAspectRatio: widget.aspectRatio,
crossAxisSpacing: widget.crossSpacing,
mainAxisSpacing: widget.mainSpacing
      ),
      scrollDirection: widget.axis,
      itemCount: widget.data.length,
      itemBuilder: (context, index) {
        return AnimationConfiguration.staggeredList(
          position: index,
        //  width: 200,
        //  height: 200,
          duration: Duration(milliseconds:duration ),
          delay: Duration(milliseconds: delay),


          // color: Colors.blue[index * 100],
          child: SlideAnimation(
            duration: Duration(milliseconds:duration ),
            delay: Duration(milliseconds: delay),

            verticalOffset: 100,

            child: FadeInAnimation(
              duration: Duration(milliseconds:duration ),
              delay: Duration(milliseconds: delay),

              curve: Curves.easeInOut,
              child: widget.itemBuilder(
                widget.data[index],

              ),
            ),
          ),
        );
      },
    );
  }
}

