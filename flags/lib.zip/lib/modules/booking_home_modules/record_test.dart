import 'dart:async';
import 'dart:io';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get_storage/get_storage.dart';
import 'package:just_audio/just_audio.dart' as ap;
import 'package:record/record.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';
import 'package:sehati_app/utils/record/audio_player.dart';
import 'package:showcaseview/showcaseview.dart';


class AudioRecorder extends StatefulWidget {
  final void Function(String path) onStop;

   AudioRecorder({Key? key, required this.onStop}) : super(key: key);

  @override
  _AudioRecorderState createState() => _AudioRecorderState();
}

class _AudioRecorderState extends State<AudioRecorder> {
  bool _isRecording = false;
  bool _isPaused = false;
  int _recordDuration = 0;
  Timer? _timer;
  Timer? _ampTimer;
  final _audioRecorder = Record();

GetStorage box=GetStorage();
  final GlobalKey one = GlobalKey();

  @override
  void initState() {
    _isRecording = false;
    super.initState();

  }

  @override
  void dispose() {
    _timer?.cancel();
    _ampTimer?.cancel();
    _audioRecorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return 
      
      
      ShowCaseWidget(
        builder: Builder( builder: (context){
          if(box.read('hint')==null){


            WidgetsBinding.instance!.addPostFrameCallback((_) =>
                ShowCaseWidget.of(context)!
                    .startShowCase([one]));

            box.write('hint', true);

          }


          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  _buildRecordStopControl(),
                  const SizedBox(width: 20),
                  _buildPauseResumeControl(),
                  const SizedBox(width: 20),
                  Row(
                    children: [
                      _buildText(),
                    ],
                  ),
                ],
              ),
              // if (_amplitude != null) ...[
              //   const SizedBox(height: 40),
              //   Text('Current: ${_amplitude?.current ?? 0.0}'),
              //   Text('Max: ${_amplitude?.max ?? 0.0}'),
              // ],
            ],
          );
        },

      ));
  }

  Widget _buildRecordStopControl() {
    late Widget icon;

    if (_isRecording || _isPaused) {
      icon = Icon(Icons.stop, color: AppColors.primaryColorGreen, size: 30);
      //color = AppColors.primaryColorGreen.withOpacity(0.1);
    } else {
      icon =


          Showcase(
              description: AppStrings.audioHint.tr,
              descTextStyle:AppStyles.primaryStyle(),
              radius: BorderRadius.circular(30),
              overlayPadding: EdgeInsets.all(15),
              key: one,
              contentPadding: EdgeInsets.symmetric(horizontal: 5,vertical: 20),

              child: SvgPicture.asset(AppImages.microphone));




     // color = theme.primaryColor.withOpacity(0.1);
    }

    return ClipOval(
      child: Material(
        color: AppColors.subTitleColor.withOpacity(0),
        child: InkWell(
          child: SizedBox(width: 30, height: 30, child: icon),
          onTap: () {
            _isRecording ? _stop() : _start();
          },
        ),
      ),
    );
  }

  Widget _buildPauseResumeControl() {
    if (!_isRecording && !_isPaused) {
      return const SizedBox.shrink();
    }

    late Icon icon;
    late Color color;

    if (!_isPaused) {
      icon = Icon(Icons.pause, color: AppColors.primaryColorGreen, size: 30);
      color = AppColors.primaryColorGreen.withOpacity(0.1);
    } else {
      //final theme = Theme.of(context);
      icon = Icon(Icons.play_arrow, color: AppColors.primaryColorGreen, size: 30);
      color = AppColors.primaryColorGreen.withOpacity(0.1);
    }

    return ClipOval(
      child: Material(
        color: color,
        child: InkWell(
          child: SizedBox(width: 56, height: 56, child: icon),
          onTap: () {
            _isPaused ? _resume() : _pause();
          },
        ),
      ),
    );
  }

  Widget _buildText() {
    if (_isRecording || _isPaused) {
      return _buildTimer();
    }
    return Text("30",style: AppStyles.primaryStyleGreen(),);
  }

  Widget _buildTimer() {
   // final String minutes = _formatNumber(_recordDuration ~/ 60);
    final String seconds = _formatNumber(_recordDuration % 60);

    if(_recordDuration==10){
      _stop();
    }


    return Text(
      '${30-(int.parse(seconds))}',
      style: TextStyle(color: AppColors.primaryColor),
    );
  }

  String _formatNumber(int number) {
    String numberStr = number.toString();
    if (number < 10) {
      numberStr = '0' + numberStr;
    }

    return numberStr;
  }

  Future<void> _start() async {
    try {
      if (await _audioRecorder.hasPermission()) {
        await _audioRecorder.start();


        bool isRecording = await _audioRecorder.isRecording();
        setState(() {
          _isRecording = isRecording;
          _recordDuration = 0;
        });

        _startTimer();
      }
    } catch (_) {
    }
  }

  Future<void> _stop() async {
    _timer?.cancel();
    _ampTimer?.cancel();
    final path = await _audioRecorder.stop();

    widget.onStop(path!);

    setState(() => _isRecording = false);
  }

  Future<void> _pause() async {
    _timer?.cancel();
    _ampTimer?.cancel();
    await _audioRecorder.pause();

    setState(() => _isPaused = true);
  }

  Future<void> _resume() async {
    _startTimer();
    await _audioRecorder.resume();

    setState(() => _isPaused = false);
  }

  void _startTimer() {
    _timer?.cancel();
    _ampTimer?.cancel();

    _timer = Timer.periodic(const Duration(seconds: 1), (Timer t) {
      setState(() => _recordDuration++);
    });

    _ampTimer =
        Timer.periodic(const Duration(milliseconds: 200), (Timer t) async {
          setState(() {});
        });

    // if(_recordDuration==30){
    //   _audioRecorder.stop();
    // }

  }
}


class RecoredWidget extends StatefulWidget {
  const RecoredWidget({Key? key}) : super(key: key);

  @override
  _RecoredWidgetState createState() => _RecoredWidgetState();
}

class _RecoredWidgetState extends State<RecoredWidget> {
  bool showPlayer = false;
  ap.AudioSource? audioSource;

  @override
  void initState() {
    showPlayer = false;

    if(PatientDataLogic.audioFile!=null){
      audioSource = ap.AudioSource.uri(Uri.parse(PatientDataLogic.audioFile!.path));

    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 60,
      child: PatientDataLogic.audioFile!=null
          ? Padding(
        padding: EdgeInsets.symmetric(horizontal: 5),
        child: AudioPlayer(
          source: audioSource!,

          onDelete: () {
            setState(() {
              PatientDataLogic.audioFile=null;

              showPlayer = false;});

          },


        ),
      )
          : AudioRecorder(
        onStop: (path) {
          setState(() {
            PatientDataLogic.audioFile=File(path);

            audioSource = ap.AudioSource.uri(Uri.parse(PatientDataLogic.audioFile!.path));
            showPlayer = true;

          });
        },
      ),
    );
  }
}