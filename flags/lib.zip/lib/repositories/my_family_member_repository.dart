import 'package:sehati_app/api/my_family_member_api.dart';
import 'package:sehati_app/models/family_member_model.dart';

class MyFamilyMemberRepository {
  final MyFamilyMemberApi _familyMemberApi = MyFamilyMemberApi();

  static final _instance = MyFamilyMemberRepository._internal();

  factory MyFamilyMemberRepository() {
    return _instance;
  }

  MyFamilyMemberRepository._internal();

  Future getFamilyMemberList() async {
    var result = await _familyMemberApi.getMyFamilyMember();

    List<FamilyMember> familyMemberList = [];

    if (result != null && result is List) {
      for (var newData in result) {
        FamilyMember familyMember = FamilyMember.fromJson(newData);
        familyMemberList.add(familyMember);
      }
      return familyMemberList;
    } else {
      return result;
    }
  }
}
