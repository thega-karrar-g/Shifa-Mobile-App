import 'package:flutter/material.dart';
import 'package:flutter_toggle_tab/flutter_toggle_tab.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';

import 'package:reactive_forms/reactive_forms.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/auth_controller.dart';
import 'package:sehati_app/shared_in_ui/form_widgets/reactive_text_form.dart';
import 'package:get/get.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:showcaseview/showcaseview.dart';

class RegisterForm extends StatelessWidget {
  RegisterForm({Key? key, this.controller}) : super(key: key);
  final AuthController? controller;
 final GlobalKey one = GlobalKey();

  final FocusNode _focusNode = FocusNode();

  final double paddingHeight = 25.0;
  final labelStyle = TextStyle(
      color: AppColors.formText, fontWeight: FontWeight.bold, fontSize: 13);
  final OutlineInputBorder outlineInputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.all(
        Radius.circular(25)),
    borderSide: BorderSide(
        color:
        AppColors.registerFiled)
    ,
  );

  FormGroup buildForm() =>
      fb.group(<String, Object>{
        'fname': FormControl<String>(
          validators: [
            Validators.required,
          ],
        ),
        'midname': FormControl<String>(

        ),
        'lastname': FormControl<String>(
          validators: [
            Validators.required,
          ],
        ),
        'login': FormControl<String>(
          validators: [
            Validators.required,
            //  Validators.email
          ],
        ),
        'mobile': FormControl<String>(
          validators: [
            Validators.required,
            Validators.number,
//  Validators.email
          ],
        ),

        'password': FormControl<String>(
          validators: [
            Validators.required,
            Validators.minLength(6),
          ],
        ),

        'location': FormControl<String>(
          value: controller!.addressController.text,
        ),


        'ssn': FormControl<String>(
          validators: [Validators.required, Validators.number],
        ),
        'dob': FormControl<DateTime>(value: null),


        'rememberMe': false,
      });

  final TextStyle style =
  Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.white));

  var requiredFields=' '
      '${AppStrings.firstName.tr} *\n'
      '${AppStrings.lastName.tr} *\n'
      '${AppStrings.dob.tr} *\n'
      '${AppStrings.idNo.tr} * \n '
      '${AppStrings.phoneNum.tr} *\n'
      '${AppStrings.email.tr} *\n'
      '${AppStrings.password.tr} *\n'
      ''
      '';

  @override
  Widget build(BuildContext context) {
    return ShowCaseWidget(

      builder: Builder(builder: (context) => GetBuilder<AuthController>(builder: (logic) {

       // if(logic.introBox!.get('map')==null){
       //  WidgetsBinding.instance!.addPostFrameCallback((_) =>
       //      ShowCaseWidget.of(context)!
       //          .startShowCase([one]));
       //  }

        return Column(
          children: [
            Row(
              children: [


                FlutterToggleTab(
                  width: Get.width * .21,
                  height: 50,
                  borderRadius: 15,

                  selectedTextStyle: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600),
                  unSelectedTextStyle: TextStyle(
                      color: AppColors.primaryColor,
                      fontSize: 13,
                      fontWeight: FontWeight.w400),
                  labels: [AppStrings.firstStep.tr, AppStrings.nextStep.tr],

                  unSelectedBackgroundColors: [
                    AppColors.registerFiled.withOpacity(1)
                  ],
                  selectedBackgroundColors: const [AppColors.primaryColor],
                  selectedLabelIndex: (index) {
                    controller!.updateProfileIndex(index);
                  },
                  selectedIndex: controller!.profileIndex,),
              ],
            ),
            const SizedBox(height: 20.0),


            ReactiveFormBuilder(
              form: buildForm,
              builder: (context, form, child) {


                return Column(
                  children: [




                    Visibility(
                      visible: controller!.profileIndex == 0,
                      child: Column(children: [


                        ReactiveTextForm.reactiveTextFieldAuth(
                            formControlName: 'fname',

                            validationMessage: AppStrings.fNameHint.tr,
                            lable: AppStrings.firstName.tr,
                            lableStyle: labelStyle,

                            outlineInputBorder: outlineInputBorder
                        ),

                        Ui.vSpace10,
                        ReactiveTextForm.reactiveTextFieldAuth(
                            formControlName: 'midname',

                            validationMessage: AppStrings.midNameHint.tr,
                            lable: AppStrings.midName,
                            lableStyle: labelStyle,

                            outlineInputBorder: outlineInputBorder
                        ),

                        Ui.vSpace10,

                        ReactiveTextForm.reactiveTextFieldAuth(
                            formControlName: 'lastname',

                            validationMessage: AppStrings.lastNameHint.tr,
                            lable: AppStrings.lastName,
                            lableStyle: labelStyle,

                            outlineInputBorder: outlineInputBorder
                        ),

                        Ui.vSpace10,

                        Theme(
                          data: ThemeData.light().copyWith(

                              primaryColor: AppColors.primaryColor,
                              colorScheme: ColorScheme.light(
                                  primary: AppColors.primaryColor),
                              textTheme: Get.textTheme

                          ),
                          child: ReactiveDatePicker<DateTime>(
                            formControlName: 'dob',

                            firstDate: DateTime(1920),
                            lastDate: DateTime.now(),

                            builder: (context, picker, child) {
                              return ReactiveTextField(
                                onTap: () {
                                  if (_focusNode.canRequestFocus) {
                                    _focusNode.unfocus();
                                    picker.showPicker();
                                  }
                                },
                                style: labelStyle,
                                valueAccessor: DateTimeValueAccessor(
                                  dateTimeFormat: DateFormat('dd/MM/yyyy'),
                                ),
                                //  focusNode: _focusNode,
                                formControlName: 'dob',
                                readOnly: true,


                                decoration: InputDecoration(
                                  labelText: AppStrings.dob.tr,
                                  labelStyle: labelStyle,
                                  filled: true,
                                  fillColor: AppColors.registerFiled,
                                  contentPadding: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 10),
                                  hintText: '',
                                  errorStyle: TextStyle(
                                      color: Colors.white.withOpacity(0.7)),
                                  errorBorder: outlineInputBorder,
                                  hintStyle: TextStyle(
                                      color: Colors.white.withOpacity(0.7)),
                                  prefixIcon: Icon(Icons.date_range_sharp,
                                      color: AppColors.primaryColor),
                                  border: outlineInputBorder,
                                  focusedBorder: outlineInputBorder,
                                  enabledBorder: outlineInputBorder,

                                ),
                              );
                            },
                          ),
                        ),
                        Ui.vSpace10,


                        Row(children: [
                          Expanded(child:


                          ReactiveTextForm.reactiveTextFieldAuth(
                              formControlName: AppStrings.location.toLowerCase(),

                              validationMessage: AppStrings.locationHint.tr,
                              lable: AppStrings.location.tr,
                              iconData: Icons.location_on,
                              lableStyle: labelStyle,
                              outlineInputBorder: outlineInputBorder,
                              isLocation: true,
                              locationBtn:
                              Showcase(
                                description: AppStrings.openMapMsg.tr,
                                // title: AppStrings.openMap.tr,
                                descTextStyle: labelStyle,
                                key: one,
                                contentPadding: EdgeInsets.symmetric(horizontal: 30,vertical: 20),
                                radius: BorderRadius.circular(20),
                                child: GestureDetector(
                                  onTap: () async {

                                    var resultLocation = await Get.toNamed(AppRouteNames.map, arguments: AppRouteNames.register);

                                    final formControl = form.control('location');
                                    formControl.value = resultLocation;
                                    formControl.markAsTouched(); // if newName is

                                    controller!.updateLocation(resultLocation);



                                    //   controller.getCurrentLocation();


                                    //  form.value[AppStrings.location.toLowerCase()]= controller.addressController.text ;

                                  },

                                  child: Container(
                                    margin: EdgeInsets.symmetric(horizontal: 10),
                                    height: 40,
                                    width: 40,
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                        color: AppColors.primaryColor,
                                        shape: BoxShape.circle
                                    ),

                                    child: Icon(Icons.location_on, color: AppColors.white,size: 25,),


                                  ),
                                ),


                              )


                          ),
                          ),



                        ],),
                        Ui.vSpace10,


                        Row(
                          children: [

                            Expanded(child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 5),
                              child: Text(AppStrings.gender.tr, style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.primaryColor),),
                            )),

                            FlutterToggleTab(
                              width: Get.width / 6,
                              height: 50,
                              borderRadius: 15,

                              selectedTextStyle: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                              unSelectedTextStyle: TextStyle(
                                  color: AppColors.primaryColor,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400),
                              labels: [AppStrings.male.tr, AppStrings.female.tr],
                              icons: const [
                                FontAwesomeIcons.male,
                                FontAwesomeIcons.female
                              ],

                              unSelectedBackgroundColors: [
                                AppColors.registerFiled.withOpacity(1)
                              ],
                              selectedBackgroundColors: const [AppColors.primaryColor],
                              selectedLabelIndex: (index) {
                                controller!.updateGenderIndex(index);
                              },
                              selectedIndex: controller!.genderIndex.value,),
                          ],
                        ),

                        SizedBox(height: 5,),







                      ],),
                    ) ,


                    Visibility(
                      visible: controller!.profileIndex == 1,
                      child: Column(children: [

                        ReactiveTextForm.reactiveTextFieldAuth(
                          formControlName: 'ssn',
                          isNumber: true,
                          validationMessage: AppStrings.ssnHint.tr,
                          lable: AppStrings.idNo,
                          iconData: Icons.contact_page,
                          lableStyle: labelStyle,


                          outlineInputBorder: outlineInputBorder,

                        ),
                        Ui.vSpace10,

                        ReactiveTextForm.reactiveTextFieldAuth(
                            formControlName: 'mobile',
                            isNumber: true,
                            isPhone: true,
                            validationMessage: AppStrings.phoneHint.tr,
                            lable: AppStrings.phoneNum.tr,
                            iconData: Icons.call,
                            lableStyle: labelStyle,

                            outlineInputBorder: outlineInputBorder
                        ),
                        Ui.vSpace10,

                        ReactiveTextForm.reactiveTextFieldAuth(
                            formControlName: 'login',
                            preventSpace: true,
                            validationMessage: AppStrings.emailHint.tr,
                            lable: AppStrings.email.tr,
                            iconData: Icons.email,
                            lableStyle: labelStyle,

                            outlineInputBorder: outlineInputBorder
                        ),
                        Ui.vSpace10,


                        ReactiveTextForm.reactiveTextFieldAuth(
                            formControlName: 'password',
                            preventSpace: true,
                            validationMessage: AppStrings.passwordHint.tr,
                            isPassword: true,

                            lable: AppStrings.password.tr,
                            iconData: Icons.lock,
                            lableStyle: labelStyle,

                            outlineInputBorder: outlineInputBorder
                        ),


                      ],),
                    ),


                    // Row(
                    //   children: [
                    //     Expanded(child: Padding(
                    //       padding: const EdgeInsets.symmetric(horizontal: 20),
                    //       child: Column(
                    //         mainAxisAlignment: MainAxisAlignment.start,
                    //         crossAxisAlignment: CrossAxisAlignment.start,
                    //         children: [
                    //           Text(AppStrings.almostDone.tr,style: Get.textTheme.headline6!.merge(TextStyle(color: AppColors.black)),),
                    //           SizedBox(height: 5,),
                    //           Text(AppStrings.fillRequiredInformation.tr,style: Get.textTheme.subtitle2!.merge(TextStyle(color: AppColors.blackTxt2)),),
                    //         ],
                    //       ),
                    //     )),
                    //   ],
                    // ),
                    // SizedBox(height: 30,),


                    SizedBox(
                      height: 30,
                    ),


                    Ui.primaryButton(title: AppStrings.signUp,marginH: 5, onTab: () {
                      if (form.valid) {
                        controller!.mapUser.addAll(form.value);
                        controller!.mapUser.addAll({'gender':controller!.genderIndex.value==0?'Male':'Female'});

                        controller!.register(controller!.registerMap(controller!.mapUser));

                        //  Get.toNamed(AppRouteNames.completeRegister);
                      }
                      else {
                        controller!.buildFailedSnackBar(msg: AppStrings.fillAllRequiredFields.tr+'\n\n'+requiredFields+'\n'+AppStrings.passwordLengthHint.tr);
                        //controller!.buildFailedSnackBar(msg: form.errors.toString());
                      }
                    }),


                    SizedBox(
                      height: 30,
                    ),
                  ],
                );
              },
            ),
          ],
        );
      })),
      onStart: (index, key) {
        print('onStart: $index, $key');
      },
      onComplete: (index, key) {

        print('onComplete: $index, $key');
      },
      blurValue: 1,
      autoPlay: false,
      autoPlayDelay:Duration(seconds: 3),
      autoPlayLockEnable: false,


      onFinish: (){
        print('finish');
      },

    );
  }
}
