import 'package:get/get.dart';

import 'choose_date_period_logic.dart';

class ChooseDatePeriodBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ChooseDatePeriodLogic());
  }
}
