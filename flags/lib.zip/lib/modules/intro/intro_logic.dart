import 'package:get/get.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';

class IntroController extends GetxController {


  bool  display=true;

  var route=AppRouteNames.firstPage;






  setupDb() async {

  }



}
