import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/nurse_service.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/repositories/service_repository.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';

import '../../../utils/enums.dart';

class NurseServicesLogic extends BaseController {

  final ServiceRepository _serviceRepository=ServiceRepository();

   List<NurseService> selectedItems=[];

  List<NurseService> items=[];


updateItems( NurseService item){


  if(selectedItems.contains(item))
  {
    selectedItems.remove(item);
  }
  else{

    if(selectedItems.isEmpty||selectedItems.length<3) {
      selectedItems.add(item);
    }
    else{
      AppStrings.selectTimeMsg;
      buildFailedSnackBar(msg: AppStrings.maximumServicesMsg.tr);
    }

  }


update();
}

  checkItem(NurseService item){

  return selectedItems.contains(item);

  }



   navToTimeSlots(){


     if(selectedItems.isNotEmpty){
       var services='';
       for (var element in selectedItems) {
         services+='- ${element.name} ';
       }
       BaseController.service+=' '+services;
       PatientDataLogic.serviceId=selectedItems[0].id;
       PatientDataLogic.service=selectedItems[0];
       if(selectedItems.length>1){
         PatientDataLogic.service2=selectedItems[1];

       }

       if(selectedItems.length>2){
         PatientDataLogic.service3=selectedItems[2];

       }
       PatientDataLogic.price=0.0;
       for (var element in selectedItems) {

         PatientDataLogic.price+=double.parse(element.price);


       }
       PatientDataLogic.paymentAppointmentType=PaymentAppointmentTypes.hhc;

       PatientDataLogic.serviceType='N';
       PatientDataLogic.serviceCode='';

       PatientDataLogic.appointmentType='-hhc';
       PatientDataLogic.doctorName='';
       PatientDataLogic.doctor.name='';
       PatientDataLogic.doctor.nameAr='';

       Get.toNamed(AppRouteNames.chooseDatePeriod);

     }else{
       buildFailedSnackBar(msg: AppStrings.selectMsg.tr);
     }


   }
@override
  void onInit() async{
    // TODO: implement onInit
    super.onInit();
    setBusy(true);
  var data=await  _serviceRepository.getServicesList();

  items.addAll(data.where((element) => element.type=='HHC'));


  setBusy(false);
  update();
  }

}
