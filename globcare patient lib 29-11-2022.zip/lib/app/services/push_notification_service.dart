import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:http/http.dart' as http;

import 'local_notification_service.dart';

class PushNotificationService {
  final globcareDoctorServerKey =
      'AAAAxEhFwTs:APA91bEZEBXZwOpgzHXgC1PR12uxxLBUn7UwIc9yaKaQB9Akw0cpWCY00fXiF1sZ_0ktCjONT3FWVE7utFnaRgG732ig_QBCSgiUiMJNqrO79ChxTh8inYUsOsTsbHJBr5AqmuYr1oKp';
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final LocalNotificationService _localNotification =
      LocalNotificationService.instance;
  static bool supportIconBadge = false;

  //static const String currentTopic = '/topics/test3';

  static const String androidTopic = '/topics/android_new_consultation';
  static const String androidTestTopic =
      '/topics/android_new_consultation_test';

  static const String iosTopic = '/topics/ios_new_consultation';
  static const String iosTestTopic = '/topics/ios_new_consultation_test';
  static const String notificationTitle = 'New Consultation';
  static const String notificationBody =
      'A new consultation request is waiting by ';

  // var _lastOnResumeCall = DateTime.now().microsecondsSinceEpoch;

  getToken() async {
    String? fcmToken = await _fcm.getToken();
    print('fcm token is ====>');
    print(fcmToken);
    print('========');
    return fcmToken;
  }

  subscribeToTopic({String topic = 'news'}) async {
     await _fcm.subscribeToTopic(topic);

    print('fcm subscribe done ====>');
  }

  ///topics/mytargettopic

  initialise() async {
    getToken();
    subscribeToTopic();
    // init local
    _localNotification.initializing();
    // await doesPlatformSupportIconBadge();
    NotificationSettings settings = await _fcm.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );
    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');
    } else if (settings.authorizationStatus ==
        AuthorizationStatus.provisional) {
      print('User granted provisional permission');
    } else {
      print('User declined or has not accepted permission');
    }

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true, // Required to display a heads up notification
      badge: true,
      sound: true,
    );
    // resetIconCounter();
    await _fcmConfig();

    // if (hasInternetConnection) {
    //   await subscribeToAllNotification();
    // }
  }

/*  doesPlatformSupportIconBadge() async {
    try {
      bool res = await FlutterAppBadger.isAppBadgeSupported();
      if (res) {
        supportIconBadge = true;
      } else {
        supportIconBadge = false;
      }
    } on PlatformException {
      supportIconBadge = false;
    }
  }*/

/*  resetIconCounter() async {
    if (supportIconBadge) FlutterAppBadger.removeBadge();
  }*/

  _fcmConfig() async {
    //--- 1

    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    //--- 2
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      print('==> Got a message whilst in the foreground! (onMessage)');
      print('Message data: ${message.data}');
      await _localNotification.showNotification(message);
    });
    //3 =>onOpenFromTerminatedState
    onOpenFromTerminatedState();
  }

  // subscribeToAllNotification() async {
  //   await _fcm
  //       .subscribeToTopic('subscribeToAlalamiyaForOudAppAllNotifications');
  // }

  onOpenFromTerminatedState() async {
    // Get any messages which caused the application to open from
    // a terminated state.
    RemoteMessage? initialMessage = await _fcm.getInitialMessage();
    if (initialMessage != null) {
      print('=====> initialMessage');
      print('=====> iniMessage.data ===>  ${initialMessage.data} //end');
      print(
          'initMessage.notification.title ===>  ${initialMessage.notification?.title}');
      print(
          'initMessage.notification.body ===>  ${initialMessage.notification?.body}');

      // If the message also contains a data property with a "type" of "chat",
      // navigate to a chat screen
      // if (initialMessage?.data['type'] == 'chat') {
      //   // Navigator.pushNamed(context, '/chat',
      //   //     arguments: ChatArguments(initialMessage));
      // }
    }

    // Also handle any interaction when the app is in the background via a
    // Stream listener
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('=====> onMessageOpenedApp');
      print('=====> message.data ===>  ${message.data} //end');
      print('message.notification.title ===>  ${message.notification?.title}');
      print('message.notification.body ===>  ${message.notification?.body}');
       _localNotification.showNotification(message);

      // if (message.data['type'] == 'chat') {
      //   Navigator.pushNamed(context, '/chat',
      //       arguments: ChatArguments(message));
      // }
    });
  }

  void sendPushMessage(
      {String body = '',
      String title = '',
      String token = '',
      bool isIos = false}) async {
    try {
      var bodyData = <String, dynamic>{
        'priority': 'high',
        "sound": "notification.caf",
        'data': <String, dynamic>{
          'click_action': 'FLUTTER_NOTIFICATION_CLICK',
          'id': '1',
          'status': 'done',
          "sound": "notification.caf",
          'body': body,
          'title': title,
        },
        "to": token,
      };
      if (isIos) {
        bodyData['notification'] = <String, dynamic>{
          'body': body,
          'title': title,
          "sound": "notification.caf",
          // "android_channel_id": "default_notification_channel_id",
        };
      }

      // print(bodyData);

      await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'key=$globcareDoctorServerKey',
        },
        body: jsonEncode(bodyData),
      );
      print('done **************************************');
    } catch (e) {
      print("error push notification");
    }
  }

// Future<void> sendPushMessage(
//     String toFcmToken, String userName, String clubId) async {
//   final Dio _dio = new Dio();
//
//   String token =
//       'key=AAAA8BtBFGA:APA91bHZtvlGOqmfCokNZCAxtZr0uRXpMlwt1rZ_sggsGH-ODm4O9CULEeK_GsqeQPIVAe7GOScOPlDo-3BMifkEDuYYOHcYDpnXyVsUmNOkkmUVjTVlJxUwyKA4LV2D9IIawpETM4FZ';
//
//   var dataToSend = {
//     "notification": {
//       "title": "New join Request",
//       "body": "$userName request to join your club",
//     },
//     "priority": "high",
//     "data": {
//       "click_action": "FLUTTER_NOTIFICATION_CLICK",
//       "id": "1",
//       "status": "done",
//       "clubId": clubId,
//     },
//     "to": toFcmToken,
//   };
//
//   try {
//     print('////////start send notification data');
//     Response response = await _dio.post("https://fcm.googleapis.com/fcm/send",
//         data: dataToSend,
//         options: Options(
//             contentType: Headers.jsonContentType,
//             headers: {'Authorization': token}));
//
//     print(response.toString());
//
//     if (response.statusCode == 200) {
//       // dynamic data = response.data;
//       // var decodedJsonData = jsonDecode(jsonEncode(data));
//     }
//   } on DioError catch (error) {
//     print('====> catch error in Sending Notification');
//     print(error?.response?.data?.toString());
//     if (error.response.data != null) {
//       return error.response.data;
//     } else {
//       return AppStrings.unexpectedError;
//     }
//   }
// }

}
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  /// If you're going to use other Firebase services in the background, such as Firestore,
  /// make sure you call `initializeApp` before using other Firebase services.
  // await Firebase.initializeApp();
  print("==>Handling a background message.id: ${message.messageId}");
  print("message.data == >: ${message.data}");
  // print("message.notification.title == >: ${message?.notification?.title}");
  // print("message.notification.body == >: ${message?.notification?.body}");
/*  if (true */ /*message.notification == null*/ /*) {
  }*/
  // await PushNotificationService.addIconCounter();
  LocalNotificationService.instance.showNotification(message);
}
