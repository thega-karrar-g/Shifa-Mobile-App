import 'package:get/get.dart';

class NotificationsLogic extends GetxController {

}
