class  ModelHelper{



  checkInt(data,{int defaultVal=0}){

    return    (data is int)?data : defaultVal;


  }
 static checkString(data,{String defaultVal=''}){

   return    ( data !=null&& data is String)?data : defaultVal;


  }
 static checkDouble(data,{String defaultVal=''}){

   return    ( data !=null&& data is double)?'$data' : defaultVal;


  }

 static checkPrice(data,{String defaultVal='0.0'}){

  return    ( data !=null&& data is String)?  data : defaultVal;


  }
 static checkListString(List<String> data,{String defaultVal=''}){
var value='';

     for (var element in data) {

       value+=element;
       if(element!=data.last){
         value+='-';
       }

     }
     return value;





  }









}