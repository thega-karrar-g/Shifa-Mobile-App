import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'telemedicine_logic.dart';

class TelemedicinePage extends StatelessWidget {
  final TelemedicineLogic logic = Get.put(TelemedicineLogic());

   TelemedicinePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
