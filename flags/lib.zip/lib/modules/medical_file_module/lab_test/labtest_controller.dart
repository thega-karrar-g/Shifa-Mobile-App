import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/m_labtest.dart';
import 'package:sehati_app/repositories/labtest_repository.dart';

class LabTestController extends BaseController {

  final LabTestRepository _labTestRepository=LabTestRepository();


  Future<List<LabTest>>  getLabTestList() async {

    return await _labTestRepository.getLabTestList();

  }


}
