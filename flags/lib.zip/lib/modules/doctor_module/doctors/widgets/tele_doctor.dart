import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/models/nurse_service.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import '../doctors_controller.dart';
class TeleDoctorItemList extends StatelessWidget {
   TeleDoctorItemList({Key? key,this.doctor}) : super(key: key);
final Doctor? doctor;

bool ar=Get.locale.toString()=='ar';
  @override
  Widget build(BuildContext context) {
    var isHVD=DoctorsController.doctorType=='HVD';
    return GestureDetector(

      onTap: (){
PatientDataLogic.price=double.parse( isHVD? doctor!.hvdPrice.toString():doctor!.telePrice.toString());
PatientDataLogic.consultancyType=(doctor!.consultancyType.toString());
PatientDataLogic.doctorId =(doctor!.id!);


if(isHVD) {
PatientDataLogic.serviceName=AppStrings.homeVisitDoctor.tr;
PatientDataLogic.service=NurseService(name: AppStrings.homeVisitDoctor,nameAr: 'زيارة طبيب بالمنزل',price: PatientDataLogic.price.toString());


}
else{
  PatientDataLogic.service=NurseService(name: AppStrings.telemedicine,nameAr: 'استشارة طبية فيديو',price: PatientDataLogic.price.toString());

}

//print(PatientDataLogic.service.toJson());
 Get.toNamed(AppRouteNames.doctorSchedule, arguments: doctor);

      },
      child: Container(
      //  height: 90,
        decoration: BoxDecoration(
        ),


        child: Stack(


          children: [
            // Positioned.fill(
            //     bottom: 20,
            //     child: Align(
            //         alignment:ar?Alignment.bottomRight: Alignment.bottomLeft,
            //         child: Container(
            //           margin: EdgeInsets.symmetric(horizontal: 20),
            //           width: Get.width*.4,
            //           height: 5,
            //           decoration: BoxDecoration(
            //               color: AppColors.primaryColor,
            //             borderRadius: BorderRadius.circular(15)
            //           ),
            //         )
            //     )),

            Row(
              children: [


Column(children: [

Expanded(child:

Container(
      child:    Ui.circluarImgRadiusBase64(url: doctor!.image,margin: 0,errorImg: AppImages.doctor,rTL: ar?0:20,rTR: ar?20:0,size: 0,h: 120,w: 90),

  decoration: BoxDecoration(
      borderRadius: BorderRadius.only(
        topRight: Radius.circular(ar?20: 0),
        topLeft: Radius.circular(ar?0:20),
        bottomRight: Radius.circular(20),
        bottomLeft: Radius.circular(20),
      ),

  ),

),



),




],),
                Expanded(
                  child: IntrinsicHeight(
                    child: Column(children: [

                      Container(
                        margin: EdgeInsets.zero,
                        padding: EdgeInsets.symmetric(vertical: 5),
                        decoration: BoxDecoration(
                          color: AppColors.primaryColorOpacity,
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(ar?0:15),
                              bottomRight: Radius.circular(ar?0:15),


                              topLeft: Radius.circular(ar?15:0),
                              bottomLeft: Radius.circular(ar?15:0),

                          )
                        ),

                        child: Row(children: [

                          Expanded(child: Container(
                       //     height: 75,
                            padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 0),
                            child: Column(

                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [

                              Row(
                                children: [
                                  Expanded(child: Text(ar?doctor!.nameAr!:doctor!.name!,maxLines: 2,overflow: TextOverflow.ellipsis,style: AppStyles.primaryStyle(bold: true,size: 12),)),
                                ],
                              ),
                              UiHelper.verticalSpace(7),
                                Row(
                                  children: [
                                    Expanded(child: Text(  ' ${ar? doctor!.jobTitleAr! :  doctor!.jobTitle!} ',maxLines: 3,overflow: TextOverflow.ellipsis,style: AppStyles.subTitleStyle(bold: true,size: 11),)),
                                  ],
                                ),
                                UiHelper.verticalSpace(7),

                                Row(
                                  children: [
                                    Expanded(child: Text(  ar? doctor!.specialityAr!:  doctor!.speciality!,maxLines: 2,overflow: TextOverflow.ellipsis,style: AppStyles.subTitleStyle(bold: true,size: 10),)),
                                  ],
                                ),
                                UiHelper.verticalSpace(5),
                                Row(
                                  children: [
                                    Expanded(child: Text('${ar?doctor!.employerAr :  doctor!.employer!}   '  ,maxLines: 1,overflow: TextOverflow.ellipsis,style: AppStyles.primaryStyle(bold: false,size: 10),)),
                                  ],
                                ),


                              ],),
                          )),
                          UiHelper.horizontalSpace(5),

                          Container(
                            padding: EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                            decoration: BoxDecoration(color: AppColors.primaryColorGreen,

                            borderRadius: BorderRadius.only(

                                topLeft: Radius.circular(ar?0:5),
                                bottomLeft: Radius.circular(ar?0:5),


                                bottomRight: Radius.circular(ar?5:0),
                                topRight: Radius.circular(ar?5:0),



                            )
                            ),
                            child: Text( (isHVD?doctor!.hvdPrice! :doctor!.telePrice!) +' '+AppStrings.currency.tr,style: AppStyles.whiteStyle(bold: true,size: 12),),

                          )


                        ],),
                      ),

                    ],),
                  ),
                ),
              ],
            ),
          ],
        ),

      ),
    );
  }
}
