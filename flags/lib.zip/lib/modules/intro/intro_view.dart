import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'intro_logic.dart';


class IntroView extends GetView<IntroController> {

  @override
  final controller = Get.put(IntroController());

  IntroView({Key? key}) : super(key: key);





  var pages = [



  ];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
Container()
    );


  }


}


