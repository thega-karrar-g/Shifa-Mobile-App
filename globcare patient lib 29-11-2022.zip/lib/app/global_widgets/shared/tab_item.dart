import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../core/theme_helper/app_colors.dart';
import '../../core/theme_helper/app_styles.dart';

class TabItem extends StatelessWidget {
  const TabItem(
      {Key? key,
      required this.name,
      required this.onTab,
      this.selected = false,
      this.fontSize = 16.0})
      : super(key: key);
  final String name;
  final bool selected;
  final Function onTab;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          onTab();
        },
        behavior: HitTestBehavior.translucent,
        child: IntrinsicWidth(
          child: Container(
            // color: AppColors.green,
            padding: EdgeInsets.symmetric(vertical: 0, horizontal: 15.w),
            child: Column(
              children: [
                Text(name.tr,
                    style: AppStyles.primaryStyle(
                        bold: true,
                        size: fontSize,
                        color: selected
                            ? AppColors.primaryColor
                            : AppColors.subTitleColor)),
                if (selected)
                  Row(
                    children: [
                      Expanded(
                          child: Container(
                        margin: EdgeInsets.only(
                          top: 5.h,
                          bottom: 5.h,
                        ),
                        height: 5.h,
                        decoration: BoxDecoration(
                            color: AppColors.primaryColorGreen,
                            borderRadius: BorderRadius.circular(5.h)),
                      ))
                    ],
                  )
                else
                  Row(
                    children: [
                      Expanded(
                          child: Container(
                        margin: EdgeInsets.only(
                          top: 5.h,
                          bottom: 5.h,
                        ),
                        height: 3.h,
                        decoration: BoxDecoration(
                            color: AppColors.subTitleColor.withOpacity(.5),
                            borderRadius: BorderRadius.circular(5.h)),
                      ))
                    ],
                  )
              ],
            ),
          ),
        ));
  }
}
