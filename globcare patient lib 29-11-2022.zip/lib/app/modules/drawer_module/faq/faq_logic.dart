import '../../../base_controller/base_controller.dart';

class FAQLogic extends BaseController {}
