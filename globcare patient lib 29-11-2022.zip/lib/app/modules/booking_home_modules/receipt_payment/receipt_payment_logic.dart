import 'package:get/get.dart';

import '../../../base_controller/base_controller.dart';
import '../../../data/enums.dart';
import '../../../data/repositories/appointment_repository.dart';
import '../../../routes/app_route_names.dart';
import '../../../utils/constants/api_keys.dart';
import '../../../utils/constants/app_urls.dart';
import '../../../utils/constants/booking_vars.dart';
import '../../my_profile_module/requested_payment/requested_payment_logic.dart';
import '../instant_consultation_module/instant_consultation_states/instant_consultation_states_logic.dart';

class ReceiptPaymentLogic extends BaseController {
  late final String transId, responseCode, appointmentId;
  late final String result;
  final String amount = '';

  final String cardToken = '';
  final String cardBrand = '';
  final String maskedPan = '';
  String failRoute = AppRouteNames.invoicePage;

  final AppointmentRepository _appointmentRepository = AppointmentRepository();

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    appointmentId = Get.arguments['orderId'];
    responseCode = Get.arguments['respCode'];
    transId = Get.arguments['transId'];
    failRoute = Get.arguments['failRoute'] ?? AppRouteNames.invoicePage;

    payment();
    _visibleTokenDetails();
  }

  payment() async {
    var data = {
      ApiKeys.appointmentType:
          BookingVars.paymentAppointmentType.toString().split('.')[1],
      BookingVars.paymentFromInstantCons
          ? ApiKeys.consultationId
          : ApiKeys.appointmentId: appointmentId,
      ApiKeys.paymentReference: transId,
      'consultancy_price': BookingVars.price.toString(),

    };

    if (responseCode != '000') {
      data = {
        ApiKeys.appointmentType:
            BookingVars.paymentAppointmentType.toString().split('.')[1],
        ApiKeys.appointmentId: appointmentId,
        ApiKeys.paymentReference: '0',
        'consultancy_price': '0',

      };
    }
    setBusy(true);

    //  DifferentDialog.showProgressDialog();

    if (failRoute == AppRouteNames.requestedPaymentDetails) {
      var paymentReference = responseCode == '000' ? transId : '';

      RequestedPaymentLogic()
          .setRequestedPaymentStatus(paymentReference: paymentReference);
    } else {
       await _appointmentRepository.setPaymentStatus(data,
          url: BookingVars.paymentFromInstantCons
              ? AppUrls.setPaymentStatusInstantCons
              : AppUrls.setPaymentStatus);

      if (BookingVars.paymentFromInstantCons) {
        if (responseCode == '000') {
          InstantConsultationStatesLogic.instantConsultationStatus =
              InstantConsultationStatus.startMeeting;
        }
        Get.offNamedUntil(AppRouteNames.instantConsultation,
            (route) => route.settings.name == AppRouteNames.home);
      }
    }

    //    if(res['success']==1){
    //
    //   buildSuccessSnackBar(msg: res['msg']);
    // }
    //    else{
    //      buildFailedSnackBar(msg: res['msg']);
    //
    //    }

    setBusy(false);
    // Get.back();
  }

  bool visibilityToken = false;

  void _visibleTokenDetails() {
    var tok = cardToken;
    if (tok == "" || tok == "null") {
      visibilityToken = false;
    } else {
      print('Token else$tok');
      visibilityToken = true;
    }

    update();
  }
}
