import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/m_labtest.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

class LabTestDetails extends StatelessWidget {
   LabTestDetails({this.labTest, Key? key}) : super(key: key);
  final LabTest? labTest;
bool ar=Get.locale.toString()=='ar';

   @override
   Widget build(BuildContext context) {
     return Ui.myScaffold(child: Column(
       children: [
         myAppBar2(title: AppStrings.labTestDetails.tr),

         // Row(children: [
         //
         //   SizedBox(width: 20,),
         //   headerItem(AppStrings.test),
         //   headerItem(AppStrings.result),
         //   headerItem(AppStrings.normalRange),
         //   headerItem(AppStrings.unit),
         //   SizedBox(width: 20,),
         //
         // ],),

         // SizedBox(height: 30,),

         Expanded(child: Container(
           //    padding: EdgeInsets.only(right: 0,left: 0,bottom: 100),

           decoration: BoxDecoration(
             // color: AppColors.primaryColor.withOpacity(.1),
             // borderRadius: BorderRadius.only(
             //     topLeft: Radius.circular(70),
             //     topRight: Radius.circular(70),
             // )
           ),
           child: ListView.builder(

               padding: EdgeInsets.only(right: 10,left: 10,bottom: 20),



               itemCount: labTest!.labTestCriteria!.length,

               itemBuilder: (bc,index) {



                 return cardItem(labTest!.labTestCriteria![index],primary: index%2==1);




               }

           ),

         ))





       ],
     ));
  }



  cardItem(LabTestCriteria labTestCriteria,{bool primary=false } ){

    return Container(


      margin: EdgeInsets.symmetric(horizontal: 0,vertical: 20),

      child: Column(children: [
        lineItem(title: AppStrings.test,data: labTestCriteria.name!,primary: primary,withArrow: true),
        lineItem(title: AppStrings.result,data: labTestCriteria.result!,primary: primary),
        lineItem(title: AppStrings.normalRange,data: labTestCriteria.normalRange!+'   '+labTestCriteria.unit!,primary: primary),



      ],),


    );


  }
  lineItem({String data='',String title='',bool primary =false,bool withArrow=false}){

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(

          padding: EdgeInsets.only(left: Get.locale.toString()=='ar'? 0:15,top: 20,bottom: 20,right: Get.locale.toString()=='ar'? 15:0),
            margin: EdgeInsets.symmetric(horizontal: 0,vertical: 5),

          decoration: BoxDecoration(
              color: primary?AppColors.primaryColorOpacity:AppColors.primaryGreenOpacityColor,

              borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            children: [
              SizedBox(width: 85,),
              Expanded(child: Text(data,overflow: TextOverflow.ellipsis,maxLines: 1,style: TextStyle(fontSize: 14,color: primary? AppColors.primaryColor:AppColors.primaryColorGreen,fontWeight: FontWeight.bold),)),
            ],
          ),

        ),
        Positioned.fill(
          bottom: 5,
          child: Align(
            alignment: ar?Alignment.centerRight:Alignment.centerLeft,
            child: Container(width: 80,

              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(

                  topRight: Radius.circular(ar?0:20),
                  topLeft: Radius.circular(ar?20:0),
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),


                ),


                  color:primary? AppColors.primaryColor:AppColors.primaryColorGreen
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Text(
                        title.tr,textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 13,color: AppColors.white),
                      ),
                    ),
                  ),
                ],
              ),

            ),
          ),


        ),
        if(withArrow)

          Positioned.fill(
            right:ar?0: 45,
            left:ar?45: 0,
            top: 2,
            child: Align(
              alignment:  ar? Alignment.topLeft :Alignment.topRight,
              child: Container(
                width: 80,
                height: 5,
                padding: EdgeInsets.symmetric(horizontal: 5,vertical: 10),
                decoration: BoxDecoration(
                    color: primary ?AppColors.primaryColor:AppColors.primaryColorGreen,
                    borderRadius: BorderRadius.circular(10)

                ),

              ),
            ),
          ),

      ],
    );


  }
  headerItem( String title ){

    return Expanded(
      child: Container(
        height: 70,
padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
margin: EdgeInsets.all(10),
        alignment: Alignment.center,
        decoration:  BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          color: AppColors.primaryColor,
          boxShadow: [
            BoxShadow(
              offset: Offset(0,2),
              color: AppColors.primaryColor.withOpacity(.5),spreadRadius: 1,blurRadius: 3
            )
          ]
        ),

child: Text(title,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 13,color: AppColors.white),),

      ),
    );

  }
  bodyItem( String title,{double topRadius=0,double bottomRadius=0} ){

    return Expanded(
      child: Container(
padding: EdgeInsets.only(left: 10,right: 10,top: 10,bottom: bottomRadius>0?20:5),
margin: EdgeInsets.symmetric(horizontal: 10),
        alignment: Alignment.center,
        decoration:  BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(topRadius),
            topRight: Radius.circular(topRadius),
            bottomRight: Radius.circular(bottomRadius),
            bottomLeft: Radius.circular(bottomRadius),

          ),
            boxShadow: [


          if(bottomRadius>0)    BoxShadow(
                  offset: Offset(0,2),
                  color: AppColors.primaryColor.withOpacity(.2),spreadRadius: 1,blurRadius: 3
              )
            ],

          color: AppColors.white
        ),

child: Column(
  children: [

    Text(title,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 13,color: AppColors.black),),

   Spacer(),
   Container(height: 1,color: AppColors.dividerColor,width: Get.width/6,)
   // Divider()
  ],
),

      ),
    );

  }



  Widget text(BuildContext context, String title, {int flex = 1}) {
    return Expanded(
        flex: flex,
        child: Text(
          title,
          style: Theme.of(context).textTheme.bodyText1,
        ));
  }
}
