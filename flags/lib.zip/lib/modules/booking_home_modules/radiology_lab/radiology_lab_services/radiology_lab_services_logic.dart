
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/models/nurse_service.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/repositories/service_repository.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/enums.dart';



class RadiologyLabServicesLogic extends BaseController {

final  ServiceRepository _serviceRepository=ServiceRepository();
  int index=0;
  String code='R';

  GlobalKey? key=GlobalKey();
  final finalKey=GlobalKey();
  List<NurseService> _services=[],currentServices=[],selectedItems=[];


  updateIndex(int i){
    index=i;

    switch(i){
      case 0:{code='L';}break;
      case 1:{code='LP';}break;

    }
    currentServices.clear();
    currentServices.addAll(_services.where((element) => element.code==code));
    key=null;

    update();
  }


updateItems( NurseService item){
  key=finalKey;

  if(selectedItems.contains(item))
  {
    selectedItems.remove(item);
  }
  else{
selectedItems.clear();
      selectedItems.add(item);


  }

  update();
}
checkItem(NurseService item){

  return selectedItems.contains(item);

}


updateItemsAdd( NurseService item){
  key=finalKey;

  if(item.quantity<5) {
    currentServices[ currentServices.indexOf(item)].quantity++;
  }
  update();
}

updateItemsSub( NurseService item){
  key=finalKey;

  if(item.quantity>1) {
    currentServices[ currentServices.indexOf(item)].quantity--;
  }
  update();
}



navToTimeSlots(){


  if(selectedItems.isNotEmpty){


    if(homeService.code=='R'){
      PatientDataLogic.appointmentType='-hhc';

    }
    else if(homeService.code=='PCR'){
      PatientDataLogic.appointmentType='-hhc';

    }
    else{
      PatientDataLogic.appointmentType='-hhc';


    }


    PatientDataLogic.serviceId=selectedItems[0].id;
    PatientDataLogic.service=selectedItems[0];

    PatientDataLogic.price=double.parse(selectedItems[0].price);

    PatientDataLogic.serviceType='N';
    PatientDataLogic.serviceCode='';

    PatientDataLogic.doctorName='';
    PatientDataLogic.doctor.name='';
    PatientDataLogic.doctor.nameAr='';
    PatientDataLogic.paymentAppointmentType=PaymentAppointmentTypes.hhc;

    Get.toNamed(AppRouteNames.chooseDatePeriod);

  }else{
    buildFailedSnackBar(msg: AppStrings.selectMsg.tr);
  }


}
HomeService homeService=Get.arguments;


@override
  void onInit() async{
    // TODO: implement onInit
    super.onInit();

    setBusy(true);
    _services=await _serviceRepository.getServicesList();
    currentServices.addAll(_services.where((element) => element.code==homeService.code));
    setBusy(false);
    update();

  }
}
