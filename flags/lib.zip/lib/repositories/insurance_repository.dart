import 'dart:convert';

import 'package:sehati_app/api/insurance_api.dart';
import 'package:sehati_app/models/insurance.dart';

class InsuranceRepository {
  static final _insuranceRepository = InsuranceRepository._internal();

  factory InsuranceRepository() {
    return _insuranceRepository;
  }

  InsuranceRepository._internal();

  final InsuranceApi _insuranceApi = InsuranceApi();

  Future<List<Insurance>> getInsuranceList() async {
    var response = await _insuranceApi.getInsuranceCompanies();


   try{


    var jsonData=json.decode(response!.body.toString());

    var d = jsonData['data'] as List;


    return d.map((dr) {

        return Insurance.fromJson((dr));

    }).toList();




    }catch(_){
      return [];
    }

  }

}
