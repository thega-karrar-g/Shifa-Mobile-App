import 'package:auto_direction/auto_direction.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AutoDirectionText extends StatefulWidget {
  final String text;
  final TextStyle? style;
  final AlignmentGeometry? alignment;
  final int? maxLines;
  final double? minFontSize;
  final TextAlign? textAlign;
  final TextOverflow? textOverflow;

  // final Function  onReadMore;

  const AutoDirectionText(
    this.text, {
    Key? key,
    this.style,
    this.alignment,
    this.maxLines,
    this.textAlign,
    this.minFontSize,
    this.textOverflow,
  }) : super(key: key);

  @override
  _InputTextFieldWidgetState createState() => _InputTextFieldWidgetState();
}

class _InputTextFieldWidgetState extends State<AutoDirectionText> {
  late String text;
  bool isRTL = false;
  late String tempText;

  @override
  void initState() {
    super.initState();
    text = widget.text;
  }

  @override
  void didUpdateWidget(covariant AutoDirectionText oldWidget) {
    if (oldWidget.text != widget.text) {
      setState(() {
        text = widget.text;
      });
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return AutoDirection(
      text: text,
      child: Align(
        alignment: widget.alignment ?? AlignmentDirectional.centerStart,
        child: Text(widget.text,
            overflow: widget.textOverflow,
            maxLines: widget.maxLines,
            // minFontSize: minFontSize(),
            textAlign: widget.textAlign,
            style: widget.style ?? Get.textTheme.subtitle2),
      ),
    );
  }

  double minFontSize() {
    if (widget.minFontSize != null) {
      widget.minFontSize;
    }
    return widget.style?.fontSize ?? Get.textTheme.subtitle2!.fontSize ?? 12;
  }
}
