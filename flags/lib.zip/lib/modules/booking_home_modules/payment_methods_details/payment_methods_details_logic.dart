import 'package:flutter/material.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/modules/booking_home_modules/appointment_base_controllers/appointment_base_controller.dart';

class PaymentMethodDetailsLogic extends BaseController {


  TextEditingController cardNumberController=TextEditingController(text: '');
  TextEditingController cvcController=TextEditingController(text: '');
  TextEditingController expDteController=TextEditingController(text: '');
  bool isValid(){


    if(cardNumberController.text.length==19&&cvcController.text.length==3&&expDteController.text.length==5) {
      return true;
    }

    return false;
  }
  setCvc(String txt){

    cvcController.text=txt;
    update();
  }
  setCardNumber(String txt){

    cardNumberController.text=txt;
    update();
  }
  setExpDate(String txt){

    expDteController.text=txt;
    update();
  }



  makeBooking()async{

  final  AppointmentBaseController appointmentBaseController=AppointmentBaseController();


  appointmentBaseController.makeBookingWithFileDio();


  }


}
