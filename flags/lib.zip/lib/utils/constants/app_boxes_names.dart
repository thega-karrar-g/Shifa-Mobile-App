class AppBoxesNames {
  static const String themeBoxMode = 'themeBoxMode';
  static const String themeBoxName = 'themeBox';
  static const String currThemeKey = 'currentTheme';
  static const String userBoxName = 'userBox';
  static const String appLangBoxName = 'appLanguageBox';
  static const String stepsBoxName = 'steps';
  static const String introBoxName = 'intro';
}
