import 'package:flutter/material.dart';
import 'package:sehati_app/models/m_prescription.dart';
import 'package:sehati_app/modules/medical_file_module/prescriptions/widgets/prescription_item2.dart';
import 'package:sehati_app/shared_in_ui/shared/no_data.dart';
  class PrescriptionList extends StatelessWidget {
    const PrescriptionList({this.prescriptions,Key? key}) : super(key: key);

  final  List<Prescription>? prescriptions;


    @override
    Widget build(BuildContext context) {

      return prescriptions!.isNotEmpty? ListView.builder(
        //padding: EdgeInsets.zero,
          itemCount: prescriptions?.length,
          itemBuilder: (bc,index)=>PrescriptionItem2(prescription: prescriptions?[index],)):NoDataFound();
    }
  }
