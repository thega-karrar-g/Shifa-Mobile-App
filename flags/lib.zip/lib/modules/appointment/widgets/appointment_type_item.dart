import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_styles.dart';

import '../../../language_and_localization/app_strings.dart';

class AppointmentTypeItem extends StatelessWidget {
   AppointmentTypeItem({Key? key,this.homeService}) : super(key: key);

 final HomeService? homeService;
final double h=80;
 final ar =Get.locale.toString()=='ar';
  @override
  Widget build(BuildContext context) {

    return GestureDetector(

      onTap: (){
if (homeService!.next.isNotEmpty) {
  Get.toNamed(homeService!.next,arguments: homeService);

}
else{
  BaseController().soonMessage();
}

      },

      child: Container(
        height: h,
        margin: EdgeInsets.symmetric(vertical: 5),
        decoration: BoxDecoration(
          color: AppColors.primaryColorOpacity,
          borderRadius: BorderRadius.circular(10)
        ),

child: Row(children: [

  UiHelper.horizontalSpaceMedium,


  Image.asset(homeService!.icon,height: h,width: 60,
   // color: AppColors.primaryColorGreen,
  ),
  UiHelper.horizontalSpaceMedium,


  Expanded(child: Column(children: [
      UiHelper.verticalSpaceMedium,

      Row(
        children: [
          Expanded(child: Text(homeService!.name.tr,style: AppStyles.primaryStyle(bold: true,size: 13),)),
        ],
      ),
      UiHelper.verticalSpaceSmall,
    Row(
      children: [

        Expanded(child: Text(AppStrings.show.tr +' '+homeService!.description.tr,maxLines: 2,style: AppStyles.primaryStyle(bold: false,size: 10,opacity: .7),)),
      ],
    ),

  ],)),
  UiHelper.horizontalSpaceSmall,

  Container(
      alignment: Alignment.center,
      width: 30,
      height: h,
  decoration: BoxDecoration(
      color: AppColors.primaryColor,
      borderRadius: BorderRadius.only(
        topRight: Radius.circular(ar?0:10),
        bottomRight: Radius.circular(ar?0:10),
        topLeft: Radius.circular(ar?10:0),
        bottomLeft: Radius.circular(ar?10:0),
      )
  ),
      child: CircleAvatar(radius: 10,
          backgroundColor: AppColors.white,
        child: Icon(Icons.arrow_forward_ios_rounded,size: 15,color: AppColors.primaryColor,),
          ) ,

  )




],),

      ),
    );
  }
}
