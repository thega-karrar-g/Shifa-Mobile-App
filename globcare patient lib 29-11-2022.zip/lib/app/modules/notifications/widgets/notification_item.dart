import 'package:flutter/material.dart';

import '../../../core/theme_helper/app_colors.dart';
import '../../../core/theme_helper/app_styles.dart';
import '../../../data/models/notification_model.dart';
import '../../../global_widgets/shared/ui_helpers.dart';
import '../../../global_widgets/ui.dart';

class Notificationitem extends StatelessWidget {
  const Notificationitem({Key? key, this.notificationModel}) : super(key: key);
  final NotificationModel? notificationModel;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5),
      child: Column(
        children: [
          IntrinsicHeight(
            child: Row(
              children: [
                Column(
                  children: [Ui.circularImg(url: '', margin: 0), Spacer()],
                ),
                UiHelper.horizontalSpaceMedium,
                Expanded(
                  child: Column(
                    children: [
                      Text.rich(
                        TextSpan(
                            text: notificationModel!.name,
                            style: AppStyles.primaryStyle(bold: true, size: 14),
                            children: [
                              TextSpan(text: '\t'),
                              TextSpan(
                                  text: notificationModel!.description,
                                  style: AppStyles.subTitleStyle())
                            ]),
                      ),
                      UiHelper.verticalSpaceSmall,
                      Row(
                        children: [
                          Text(
                            notificationModel!.date,
                            style: AppStyles.subTitleStyle(bold: true),
                          ),
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
          UiHelper.verticalSpaceSmall,
          Divider(
            color: notificationModel!.readed
                ? AppColors.subTitleColor
                : AppColors.primaryColorGreen,
            thickness: 2,
          )
        ],
      ),
    );
  }
}
