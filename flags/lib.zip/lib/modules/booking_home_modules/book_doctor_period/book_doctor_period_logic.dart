import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/m_doctors.dart';
import 'package:sehati_app/models/period.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/repositories/appointment_repository.dart';
import 'package:sehati_app/utils/constants/app_route_names.dart';
import 'package:sehati_app/utils/time_helper.dart';

class BookDoctorPeriodLogic extends BaseController {


  int  infoIndex=0;
final AppointmentRepository _appointmentRepository=AppointmentRepository();

  changeInfoIndex(int index){


    infoIndex=index;
    update();
  }

  DateTime selectedDay=DateTime.now().add(Duration(days: 1));
  var weekDays = List<DateTime>.generate(7, (i) =>
      DateTime.now().add(Duration(days: 1)).add(Duration(days: i)));

changeDay(DateTime dateTime){
  selectedDay=dateTime;
  updateAppointmentDate();

  updatePeriods( dateTime);
  update();
}

List<Period>  periods2=[];

@override
  void onInit()async {
    // TODO: implement onInit
    super.onInit();
     periods2=await _appointmentRepository.getPeriodList();


   //  weekDays=periods2.map((e) =>  DateTime.parse(e.date)).toSet().toList();




    selectedDay=weekDays[0];
    changeDay(selectedDay);
    var d=DateTime(selectedDay.year,selectedDay.month,selectedDay.day,0,0,0);

    PatientDataLogic.appointmentDate=DateFormat('yyyy-M-d').format(d);

  }
  List<String> doctorSlots=[];
  List<String> periods=['Morning','Afternoon','Evening'];

String selectedTime='';
String selectedPeriod='';



updatePeriods(DateTime dateTime){

  periods.clear();

  for (var element in periods2) {

    if((element.date)==dateTime){

      periods.add(element.period);


    }

  }
  update();


}


selectPeriod({String p=''}){
  selectedPeriod=p;
  PatientDataLogic.period=p;

  update();



}




  updateSlots({String day=''}){
    var doctor=Get.arguments as Doctor;
    doctorSlots.clear();
    for (var element in doctor.availableLines!) {
      if(day==element.day) {
        DateTime start = DateFormat("HH:mm").parse(element.startTime!);
        DateTime end = DateFormat("HH:mm").parse(element.endTime!);

        TimeOfDay startTimeOfDay = TimeOfDay.fromDateTime(start);

        TimeOfDay endTimeOfDay = TimeOfDay.fromDateTime(end);

        doctorSlots.addAll(
          TimeHelper.  getSlots(start: startTimeOfDay.hour, end: endTimeOfDay.hour-1));
      }
    }

    update();
  }


updateAppointmentDate(){



  var appointmentDate=DateTime(selectedDay.year,selectedDay.month,
      selectedDay.day
      ,
      0,
      0,
      0

  );

   selectedTime=DateFormat('yyyy-M-d').format(appointmentDate);
  PatientDataLogic.appointmentDate=selectedTime;

update();
}

checkTime(String time){
  DateTime end = DateFormat("HH:mm a").parse(time);



  var appointmentDate=DateTime(selectedDay.year,selectedDay.month,
      selectedDay.day
      ,
      end.hour,
      end.minute,
      0

  );

 return DateFormat('yyyy-M-d HH:mm:ss').format(appointmentDate);
}



navToPatientData() {

  if(selectedPeriod.isNotEmpty) {
    PatientDataLogic.period = selectedPeriod;
    PatientDataLogic.appointmentDate = selectedTime;

    Get.toNamed(AppRouteNames.patientData);
  }
  else{
    buildFailedSnackBar(msg: 'please select correct period');
  }
}
}
