import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/modules/auth/auth_controller.dart';
import 'package:sehati_app/shared_in_ui/shared/different_dialogs.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';


class SuccessRegister extends GetView<AuthController> {

  SuccessRegister({Key? key} ):super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryColor,


      body: Container(
        height: Get.height,
        width: Get.width,

        decoration: BoxDecoration(
          gradient: LinearGradient(colors:const [AppColors.primaryColorDark,AppColors.primaryColor]
          ,
            begin: Alignment.topRight,
            end: Alignment.bottomLeft
          )
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,

          children: [


            Container(
              height: Get.width / 1.5, width: Get.width / 1.5,

padding: EdgeInsets.all(10),
margin: EdgeInsets.symmetric(vertical: 20),
decoration: BoxDecoration(
    shape: BoxShape.circle,
 // color: AppColors.white

),
              child: GestureDetector(
                onTap: (){

                  DifferentDialog.showRegisterSuccessDialog();

               //   Get.offAllNamed(AppRouteNames.login);

                },
                child: SvgPicture.asset(AppImages.registerSuccess,

                ),
              )


              ,),

Text(AppStrings.accountCreated.tr,style: TextStyle(color: AppColors.white,fontSize: 25,fontWeight: FontWeight.bold),),
Container(height: 20,),

Text(AppStrings.successfully.tr,style: TextStyle(color: AppColors.white,fontSize: 25,fontWeight: FontWeight.bold),),

            // Container(height: 50,),
            //
            // Icon(Icons.arrow_forward,color: AppColors.white,size: 35,)



          ],
        ),
      ),
    );
  }

  textItem(String title, String hint, IconData iconData) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 30),
      child: Column(
        children: [
          Row(
            children: [
              Text(title,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.normal),),
            ],
          ),
          SizedBox(height: 20,),

          TextFormField(
            decoration: InputDecoration(
                suffixIcon: Icon(
                  iconData, color: AppColors.primaryColor, size: 20,),
                hintText: hint,
                hintStyle: TextStyle(
                    fontSize: 15, color: AppColors.black.withOpacity(.6))
            ),
          ),
        ],
      ),
    );
  }

}

