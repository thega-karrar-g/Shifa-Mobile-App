import 'package:flutter/material.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/models/home_service.dart';
import 'package:sehati_app/modules/appointment/widgets/appointment_type_item.dart';
import 'package:sehati_app/shared_in_ui/shared/dynamic_column.dart';
import 'package:sehati_app/shared_in_ui/shared/my_appbar.dart';
import 'package:sehati_app/shared_in_ui/shared/ui_helpers.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';

class RadiologyLabTypesPage extends StatelessWidget {
   RadiologyLabTypesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Ui.myScaffold(
      child: Column(
        children: [
          myAppBar2(title: AppStrings.laboratoryRadiology,h: 20),


          UiHelper.verticalSpaceSmall,


          Expanded(child: SingleChildScrollView(child: DynamicColumn(children: HomeService.labTypes.map((e) => AppointmentTypeItem(homeService: e,)).toList(),)))

        ],
      ),
    );
  }
}
