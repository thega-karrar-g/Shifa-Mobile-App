import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_multi_formatter/flutter_multi_formatter.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:sehati_app/language_and_localization/app_strings.dart';
import 'package:sehati_app/shared_in_ui/ui.dart';
import 'package:sehati_app/utils/constants/app_anim.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/helpers/theme_helper/app_colors.dart';

import '../payment_controller.dart';

class PaymentPage extends GetView<PaymentController> {
  @override
  final PaymentController controller = Get.put(PaymentController());

   PaymentPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appointmentBG,

      // appBar: AppBar(),
      body: GetBuilder<PaymentController>(builder: (logic) {
  return SingleChildScrollView(
        child: Wrap(
          children: [

            Stack(
              children: [

                Container(height: Get.height*.24,
                  alignment: Alignment.topCenter,
                  padding: EdgeInsets.only(top: Get.height*.08),
                  decoration: BoxDecoration(
                      color: AppColors.filedBg,
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      )
                  ),

                  child: Row(
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 20,vertical: 0),
                        child:                   GestureDetector(
                            onTap: (){
                              Get.back();
                            },
                            child: Icon(Icons.arrow_back_ios_outlined,color: AppColors.white,))
                        ,
                      ),

                      SizedBox(width: Get.width/4.3,),
                      Container(

                        padding: EdgeInsets.symmetric(horizontal: 1,vertical: 0),
                        child:
                        Text(AppStrings.payment,style: Get.textTheme.headline6!.merge(TextStyle(fontSize: 18,color: AppColors.white)),)
                        ,
                      ),
                    ],
                  ),

                ),

                Container(
                  margin: EdgeInsets.only(top: Get.height*.18,bottom: 50,right: 20,left: 20),

                  child: Row(
                    children: [

                      Spacer(),

                      Container(
                        //height: 100,
                        padding: EdgeInsets.symmetric(vertical: 30,horizontal: Get.width/6),
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [BoxShadow(color:AppColors.primaryColor .withOpacity(.3), blurRadius: 3)],
                        ),

                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [

                            SvgPicture.asset(AppImages.wallet,width: 30,height: 30,),
                            SizedBox(height: 20,),

                            Text('Total Amount',style: Get.textTheme.subtitle1!.merge(TextStyle(color: AppColors.black,fontWeight: FontWeight.normal,fontSize: 18)),),

                            SizedBox(height: 20,),

                            Text('SR 200',style: Get.textTheme.bodyText2!.merge(TextStyle(color: AppColors.primaryColor,fontSize: 25,fontWeight: FontWeight.bold)),),
                          ],
                        ),
                      ),
                      Spacer(),

                    ],
                  ),
                )
,

                if(controller.isLoad)
                  Positioned.fill(

                      child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Lottie.asset(AppAnim.lottieLoading3,width: Get.width/2,height: 120)))


              ],
            ),


            textItem('Card Number', '0000-1111-2222-3333', Icons.credit_card,cardType: CardType.card,),

            Container(height: 50,),

            Row(children: [
              Expanded(child: textItem('Cvc', '123', FontAwesomeIcons.eyeSlash,maxLength: 3,cardType: CardType.cvc),),
              Expanded(child: textItem('Date', '01 \\ 22', FontAwesomeIcons.calendarAlt,maxLength: 5,cardType: CardType.date),),

            ],),
            Container(height: 35,),


            


            Ui.primaryButton(title: AppStrings.finish.tr,color: logic.isValid() ? AppColors
                .primaryColor : AppColors.extraGrey,
            onTab: (){

              if(logic.isValid()) {

                logic.makeBooking();
              }

              else{

                // logic.buildFailedSnackBar(msg: AppStrings.fillAllField.tr);
              }

            }
            )






          ],
        ),
      );
}),
    );
  }

  textItem(String title,String hint,IconData iconData,{maxLength=19, CardType cardType=CardType.card,TextEditingController? textEditingController}){

    return             Container(
      margin: EdgeInsets.symmetric(horizontal: 30),
      child: Column(
        children: [
          Row(
            children: [
              Text(title,style: TextStyle(fontSize: 18,fontWeight: FontWeight.normal),),
            ],
          ),
          SizedBox(height: 20,),

          TextFormField(
onChanged: (txt){

  if(cardType==CardType.card){
    controller.setCardNumber(txt);
  }

  else if(cardType==CardType.cvc){
    controller.setCvc(txt);
  }
  else if(cardType==CardType.date){
    controller.setExpDate(txt);
  }

},



            decoration: InputDecoration(
                suffixIcon: Icon(iconData,color: AppColors.primaryColor,size: 20,),
                hintText: hint,hintStyle: TextStyle(fontSize: 15,color: AppColors.black.withOpacity(.6))
            ),
            style: TextStyle(color: AppColors.blackTxt),
            keyboardType: TextInputType.number,
            maxLength: maxLength,
            inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
              if(cardType==CardType.card)
                // CreditCardNumberInputFormatter()
    MaskedInputFormatter(
    "####-####-####-####",
    allowedCharMatcher: RegExp(r'[0-9]+'),


    )
else  if(cardType==CardType.date)
                CreditCardExpirationDateFormatter()
              else
                CreditCardCvcInputFormatter()



            ],

          ),
        ],
      ),
    );

  }

}

enum CardType{
  card,date,cvc


}
