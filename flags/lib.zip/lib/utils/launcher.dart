

import 'dart:io';

import 'package:url_launcher/url_launcher.dart';

class Launcher{




 static phoneCall(String phone)async{
  //  var url='tel:$phone';
   String url = Platform.isIOS ? 'tel://$phone' : 'tel:$phone';
    //controller.saveProfileForm(_profileForm);
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }


  }


 static openEmail(String email,{String subject='',String body=''})async{


   String? encodeQueryParameters(Map<String, String> params) {
     return params.entries
         .map((e) => '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
         .join('&');
   }
   final Uri emailLaunchUri = Uri(
     scheme: 'mailto',
     path: email,
     query: encodeQueryParameters(<String, String>{
       'subject': subject,
       'body': body,
     }),
   );

   launch(emailLaunchUri.toString());
   try {
      await launch(emailLaunchUri.toString(), forceSafariVC: false);


   } catch (e) {
     await launch(emailLaunchUri.toString(), forceSafariVC: false);
   }


  }




 static Future<void> launchInBrowser(String url) async {

   if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false,
        forceWebView: false,
        // headers: <String, String>{'my_header_key': 'my_header_value'},
      );
    } else {

      throw 'Could not launch $url';
    }
  }

  static openWhatsApp(String phone)async{

    var url='';
    if (Platform.isAndroid) {
      // add the [https]
      url= "https://wa.me/$phone/?text="; // new line
    } else {
      // add the [https]
     // url= "https://api.whatsapp.com/send?phone=$phone=${Uri.parse('')}"; // new line
      url= "https://wa.me/$phone"; // new line
    }


    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }


  }

static openFacebook()async{
  String fbPageId='105313478699877',fbPageName='Globcare-105313478699877';


  String fbProtocolUrl='';
  if (Platform.isIOS) {
    fbProtocolUrl = 'fb://profile/$fbPageId';
  } else {
    fbProtocolUrl = 'fb://page/$fbPageId';
  }

  String fallbackUrl = 'https://www.facebook.com/$fbPageName';

  try {
    bool launched = await launch(fbProtocolUrl, forceSafariVC: false);

    if (!launched) {
      await launch(fallbackUrl, forceSafariVC: false);
    }
  } catch (e) {
    await launch(fallbackUrl, forceSafariVC: false);
  }
}


static openInstagram()async{

  var url = 'https://www.instagram.com/glob_care';

  if (await canLaunch(url)) {
    await launch(
      url,
      universalLinksOnly: true,
    );
  } else {
    throw 'There was a problem to open the url: $url';
  }
}


static openTwitter()async{

  var url = 'https://twitter.com/glob_care';

  if (await canLaunch(url)) {
    await launch(
      url,
      universalLinksOnly: true,
    );
  } else {
    throw 'There was a problem to open the url: $url';
  }
}



}