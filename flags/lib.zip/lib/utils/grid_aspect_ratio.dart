import 'package:get/get.dart';
class GridAspectRatio{


 static double aspectRatio({int count=2,double height=120}){


    var _crossAxisSpacing = 8;
    var _width = ( Get.width - ((count - 1) * _crossAxisSpacing)) / count;
    var _aspectRatio = _width /height;


    return _aspectRatio;


  }





}