import 'package:get/get.dart';
import 'package:sehati_app/base_controller/base_controller.dart';
import 'package:sehati_app/models/nurse_service.dart';
import 'package:sehati_app/modules/booking_home_modules/patient_data/patient_data_logic.dart';
import 'package:sehati_app/repositories/service_repository.dart';
import 'package:sehati_app/utils/constants/app_images.dart';
import 'package:sehati_app/utils/enums.dart';

import '../../../utils/constants/app_route_names.dart';

class ServiceDetailsLogic extends BaseController {

  static String serviceCode='MH';
  static String icon=AppImages.homeVisitDoctor;

 final ServiceRepository _serviceRepository=ServiceRepository();

  List<NurseService> services=[];

  NurseService? nurseService;

@override
  void onInit() async{
    // TODO: implement onInit
    super.onInit();
    PatientDataLogic.showFiles=true;
    PatientDataLogic.service2 = NurseService();
    PatientDataLogic.service3 = NurseService();


    setBusy(true);
    services=await _serviceRepository.getServicesList();
    PatientDataLogic.doctorName='';
    PatientDataLogic.paymentAppointmentType=PaymentAppointmentTypes.hhc;

    for (var element in services) {
if(element.type==serviceCode){
  nurseService=element;
  break;
}

    }
    setBusy(false);

update();
  }

   navToNext() {
     final ar =Get.locale.toString()=='ar';

     PatientDataLogic.price= double.parse( nurseService!.price);
     PatientDataLogic.serviceId=nurseService!.id;
     PatientDataLogic.serviceName= ar? nurseService!.nameAr:nurseService!.name;
     PatientDataLogic.appointmentType='-hhc';
     PatientDataLogic.serviceCode='';
     PatientDataLogic.doctor.name='';
     PatientDataLogic.doctor.nameAr='';
     PatientDataLogic.service=nurseService!;


     if (nurseService!.code=='IVT') {
       PatientDataLogic.serviceCode='IVT';

     }

if(nurseService!.code=='SM'){
  Get.toNamed(AppRouteNames.patientData, arguments: nurseService!.code);

}
else if(nurseService!.code=='Car'){
  Get.toNamed(AppRouteNames.patientData, arguments: nurseService!.code);

}
else {
  Get.toNamed(AppRouteNames.chooseDatePeriod, arguments: nurseService!.code);
}
   }


  bool showPrice(){
  var t=['SM','Car'];
  var s= !t.contains ( nurseService!.code);

return s;
   }

}
