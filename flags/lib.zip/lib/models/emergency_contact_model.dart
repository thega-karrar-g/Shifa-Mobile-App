class EmergencyContact {
  String name;
  String phoneNum;
  String address;
  String relation;

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'phoneNum': phoneNum,
      'address': address,
      'relation': relation,
    };
  }

  factory EmergencyContact.fromMap(Map<String, dynamic> map) {
    return EmergencyContact(
      name: map['name'] as String,
      phoneNum: map['phoneNum'] as String,
      address: map['address'] as String,
      relation: map['relation'] as String,
    );
  }

  EmergencyContact({
    required this.name,
    required this.phoneNum,
    required this.relation,
    required this.address,
  });

 static List<EmergencyContact> contacts=[
    EmergencyContact(name: 'salah Muhammed', phoneNum: '7777 8855 5', relation: 'Father', address: 'Sanaa'),
    EmergencyContact(name: 'Ahmed salah', phoneNum: '7777 8855 5', relation: 'Brother', address: 'Sanaa'),
    EmergencyContact(name: 'Sami Ali salah', phoneNum: '7777 8855 5', relation: 'Son', address: 'Sanaa'),

  ];


}
